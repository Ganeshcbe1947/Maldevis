<?php 
    include "includes/header.php"; 
    
    if(isset($_POST['Reset']))
    {
        $employee_email = $_POST['employee_email'];
        
        $query = "select employee_id,employee_name,employee_email,employee_password,employee_status from fn_employee where employee_email = '$employee_email' and employee_status = 1";
        $exe_query = mysqli_query($db_connection,$query);
        $row = mysqli_fetch_array($exe_query);
    	$employee_id = $row ['employee_id'];
    	$employee_name = $row ['employee_name'];
    	$employee_email = $row ['employee_email'];
    	$employee_password = $row ['employee_password'];
        
        if($employee_email != "")
        {
        $to = $employee_email;        
        $subject = "Forget Password";
        // Additional headers
        //$headers .= 'From: Maldives Careers' . "\r\n";
        $headers  = "From: " . strip_tags($company_email) . "\r\n";
        $headers .= "Reply-To: " . strip_tags($company_email) . "\r\n";
        $headers .= "MIME-Version: 1.0\r\n";
        $headers .= "Content-Type: text/html; charset=UTF-8\r\n";
        
        
        $message  = '
        <html>
        <head>
            <title>Welcome to Maldives Careers</title>
        </head>
        <body>
            <h1>Thanks you for joining with us!</h1>
            <table cellspacing="0" style="border: 2px dashed #FB4314; width: 600px; height: 200px;">
                <tr>
                    <th>Your Password:</th><td>"'.$employee_password.'"</td>
                </tr>                          
            </table>
        </body>
        </html>';        

        // Send email
        if(mail($to,$subject,$message,$headers))
        {
            echo "<script>window.location = 'index.php'</script>";
        } 
        else {
            $msg = 'Email sending fail.';
        }
        } else {
            $msg = "Invalid Email";
        }
    }
?>
<section class="page-title title-bg14">
    <div class="d-table">
        <div class="d-table-cell">
            <h2>Reset Password</h2>
            <ul>
                <li>
                    <a href="index.php">Home</a>
                </li>
                <li>Reset Password</li>
            </ul>
        </div>
    </div>
</section>
<!-- Page Title End -->

<!-- Reset Password Section Start -->
<div class="reset-password ptb-100">
    <div class="container">
        <div class="row">
            <div class="col-lg-6 col-md-8 offset-md-2 offset-lg-3">
                
                <form class="reset-form" name="FormName" action="<?PHP $PHP_SELF ?>" method="post" enctype="multipart/form-data" >
                    <h2>Reset Password</h2>
                <p>Enter the email of your account to reset password. Then you will receive a link to email to reset the password.If you have any issue about reset password</p>
                <hr>
                    <span style="color:red;text-align: center"><?php echo $msg; ?></span>
                    <div class="form-group">
                        <label>Enter Email</label>
                        <input type="email" name="employee_email" class="form-control" placeholder="Enter Your Email" required>
                    </div>

                    <div class="reset-btn text-center">
                        <button type="submit" name="Reset">Reset Password</button>
                    </div>
                </form>
            </div>  
        </div>
    </div>
</div>
<!-- Reset Password Section End -->

<!-- Subscribe Section Start -->
<section class="subscribe-section">
    <div class="container">
        <div class="row align-items-center">
            <div class="col-md-6">
                <div class="section-title">
                    <h2>Get New Job Notifications</h2>
                    <p>Subscribe & get all related jobs notification</p>
                </div>
            </div>

            <div class="col-md-6">
                <form class="newsletter-form" data-toggle="validator">
                    <input type="email" class="form-control" placeholder="Enter your email" name="EMAIL" required autocomplete="off">

                    <button class="default-btn sub-btn" type="submit">
                        Subscribe
                    </button>

                    <div id="validator-newsletter" class="form-result"></div>
                </form>
            </div>
        </div>
    </div>
</section>
<!-- Subscribe Section End -->
<?php include "includes/footer.php"; ?>