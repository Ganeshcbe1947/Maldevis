<?php 
    include "includes/header.php"; 
    
    if (isset($_GET['logout']) && $_GET['logout'] == "true") {
		session_destroy();
		header('location:index.php');
	}
    
    if(isset($_POST['Submit']))
    {
        $employee_email = $_POST['employee_email'];
        $employee_password = $_POST['employee_password'];
        
        $query = "select employee_id,employee_name,employee_email,employee_password,employee_status from fn_employee where employee_email = '$employee_email' and employee_password = '$employee_password' and employee_status = 1";
        $exe_query = mysqli_query($db_connection,$query);
        $row = mysqli_fetch_array($exe_query);
    	$employee_id = $row ['employee_id'];
    	$employee_name = $row ['employee_name'];
    	$employee_email = $row ['employee_email'];
        if($row == true)
        {
            $_SESSION['employee_id'] = $employee_id;
            $_SESSION['employee_name'] = $employee_name;
            $_SESSION['employee_email'] = $employee_email;
            echo "<script>window.location = 'employee-dashboard.php'</script>";
            //header('location:employee-dashboard.php');
        } else {
            $msg = "Failed, Try Again";
        }
    }
?>
<section class="page-title title-bg12">
    <div class="d-table">
        <div class="d-table-cell">
            <h2>Sign In</h2>
            <ul>
                <li>
                    <a href="index.php">Home</a>
                </li>
                <li>Sign In</li>
            </ul>
        </div>
    </div>  
</section>
<!-- Page Title End -->

<!-- Sign In Section Start -->
<div class="signin-section ptb-100">
    <div class="container">
        <div class="row">
            <div class="col-lg-6 col-md-8 offset-md-2 offset-lg-3">
                <span style="color:red;text-align: center"><?php echo $msg; ?></span>
                <form class="signin-form" name="FormName" action="<?PHP $PHP_SELF ?>" method="post" enctype="multipart/form-data" >
                    <div class="form-group">
                      <label>Enter Email</label>
                      <input type="email" name="employee_email" value="" class="form-control" placeholder="Enter Email" required />
                    </div>

                    <div class="form-group">
                        <label>Enter Password</label>
                        <input type="password" name="employee_password" value="" class="form-control" placeholder="Enter Password" required 
                    </div>

                    <div class="signin-btn text-center">
                        <button type="submit" name="Submit">Sign In</button>
                        <a href="reset-password.php" class="default-btn">Forget Password</a>
                    </div>

                    <div class="create-btn text-center">
                        <p>Not have an account?
                            <a href="employee-sign-up.php">
                                Create an account
                                <i class='bx bx-chevrons-right bx-fade-right'></i>
                            </a>
                        </p>
                    </div>
                </form>
            </div>  
        </div>
    </div>
</div>
<!-- Sign In Section End -->

<?php include "includes/footer.php"; ?>