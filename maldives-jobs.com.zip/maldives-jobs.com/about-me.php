<?php 
    include "includes/header.php"; 
    $employee_id = $_SESSION['employee_id'];
    
    $employee_query = "select employee_id,employee_title,employee_about,employee_status from  fn_employee where employee_id ='$employee_id'";
    $employee_equery = mysqli_query($db_connection,$employee_query);			
    $fet_employee = mysqli_fetch_array($employee_equery);
    $employee_id = $fet_employee[0];
    $employee_title = $fet_employee[1];
    $employee_about = $fet_employee[2];
    
    
    if(isset($_POST['About'])) {
        $employee_title = $_POST['employee_title'];
        $employee_about = $_POST['employee_about'];
        
        
        $update_query = "update fn_employee set employee_title = '$employee_title',employee_about = '$employee_about', updatedatetime = current_timestamp() where employee_id = $employee_id";
	$update_result = mysqli_query($db_connection,$update_query);	
        if($update_result == TRUE)
        {
            $update_message = "Your profile updated successfully";
        } else {
            $update_message = "Try later";
        }
	//header("location:employee-dashboard.php");
    }
    
?>
  <script type="text/javascript" src="//js.nicedit.com/nicEdit-latest.js"></script> 
  <script type="text/javascript">
 
        bkLib.onDomLoaded(function() { nicEditors.allTextAreas() });
  </script>
<section class="page-title title-bg10">
    <div class="d-table">
        <div class="d-table-cell">
            <h2>About Me</h2>
            <ul>
                <li>
                    <a href="index.php">Home</a>
                </li>
                <li>About Me</li>
            </ul>
        </div>
    </div>   
</section>
<!-- Page Title End -->

<section class="account-section ptb-100">
    <div class="container">
        <div class="row">
            <?php include "includes/employee-sidebar.php"; ?>
            <div class="col-md-8">
                        <div class="account-details">
                            <h3>Basic Information</h3>
                            <h5 style="color:red;text-align: center"><?php echo $update_message; ?></h5>
                            <form class="basic-info" name="FormName" action="<?PHP $PHP_SELF ?>" method="post" enctype="multipart/form-data" >
                        <div class="row">
                            <div class="col-md-8">
                                <div class="form-group">
                                    <label>Title</label>
                                    <input type="text" name="employee_title" class="form-control" placeholder="Your Title" value="<?php echo $employee_title; ?>">
                                </div>
                            </div>

                          <div class="col-md-6">
                                <div class="form-group">
                                    <label>About us</label>
                                    
                                    <textarea id="area1" name="employee_about" rows="10" cols="60"><?php echo $employee_about; ?></textarea>
                                </div>
                            </div>
                            
                           
                            <div class="col-md-12">
                                <button type="submit" name="About" class="account-btn">Update</button>
                            </div>
                        </div>
                    </form>  

                        </div>
                <div class="candidate-info-text candidate-skill">
                            <h3>Skills</h3>
                            
                            <ul>
                                <?php
                                $skills_query = "select skills_id,skills_title,skills_experience,skills_status from employee_skills where employee_id ='$employee_id'";
                                $skills_equery = mysqli_query($db_connection,$skills_query);			
                                while($fet_skills = mysqli_fetch_array($skills_equery))
                                {
                                $skills_title = $fet_skills[1];
                                ?>
                                <li><?php echo $skills_title; ?></li>
                                <?php } ?>
                            </ul>
                        </div>
                    </div>
            
            
        </div>
    </div>
</section>


<?php include "includes/footer.php"; ?>