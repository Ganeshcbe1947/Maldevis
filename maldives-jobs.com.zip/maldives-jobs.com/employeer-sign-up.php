<?php 
    include "includes/header.php"; 
    
    if(isset($_POST['Submit']))
    {
        $employeers_name = $_POST['employeers_name'];
        $employeers_email = $_POST['employeers_email'];
        $employeers_password = $_POST['employeers_password'];
        $employeers_key = md5($employeers_email);
        
        $to = $employeers_email;        
        $subject = "Confirm your email address to activate your account";
        // Additional headers
       // $headers .= 'From: Maldives Careers' . "\r\n";
        
        $headers  = "From: " . strip_tags($company_email) . "\r\n";
        $headers .= "Reply-To: " . strip_tags($company_email) . "\r\n";
        $headers .= "MIME-Version: 1.0\r\n";
        $headers .= "Content-Type: text/html; charset=UTF-8\r\n";
        
        
        
        $message  = '
        <html>
        <head>
            <title>Welcome to Maldives Careers</title>
        </head>
        <body>
            <h1>Thanks you for joining with us!</h1>
            <table cellspacing="0" style="border: 2px dashed #FB4314; width: 600px; height: 200px;">
                <tr>
                    <th>Name:</th><td>"'.$employeers_name.'"</td>
                </tr>
                <tr>
                    <th>Email:</th><td>"'.$employeers_email.'"</td>
                </tr>
                <tr>
                    <th>Password:</th><td>"'.$employeers_password.'"</td>
                </tr>            
                <tr>
                    <th>Activate:</th><td>"'.$link.'success.php?empkey='.$employeers_key.'"</td>
                </tr>            
            </table>
        </body>
        </html>';        

        // Send email
        if(mail($to,$subject,$message,$headers))
        {
            $insert_employeers = "insert into fn_employeers(employeers_name,employeers_email,employeers_password,employeers_key,employeers_status,createdatetime) "
                . "value('$employeers_name','$employeers_email','$employeers_password','$employeers_key','0',current_timestamp())";
        $exe_query = mysqli_query($db_connection,$insert_employeers);
        if($exe_query == true)
        {
            echo "<script>window.location = 'employeer-sign-in.php'</script>";
            //header('location:employeer-sign-in.php');
        }
               
        }
        else {
            echo $errorMsg = 'Email sending fail.';
        }

           
        
         
    }
?>
<section class="page-title title-bg13">
    <div class="d-table">
        <div class="d-table-cell">
            <h2>Sign Up</h2>
            <ul>
                <li>
                    <a href="index.php">Home</a>
                </li>
                <li>Sign Up</li>
            </ul>
        </div>
    </div>  
</section>
<!-- Page Title End -->

<!-- Sign up Section Start -->
<div class="signup-section ptb-100">
    <div class="container">
        <div class="row">
            <div class="col-lg-6 col-md-8 offset-md-2 offset-lg-3">
                <form class="signup-form" name="FormName" action="<?PHP $PHP_SELF ?>" method="post" enctype="multipart/form-data" >
                    <div class="form-group">
                        <label>Enter Name</label>
                        <input type="text" name="employeers_name" value="" class="form-control" placeholder="Enter Name" required />
                    </div>

                    <div class="form-group">
                      <label>Enter Email</label>
                      <input type="email" name="employeers_email" value="" class="form-control" placeholder="Enter Email" required />
                    </div>

                    <div class="form-group">
                        <label>Enter Password</label>
                        <input type="password" name="employeers_password" value="" class="form-control" placeholder="Enter Password" required 
                    </div>

                    <div class="signup-btn text-center">
                        <button type="submit" name="Submit">Sign Up</button>
                    </div>

                    <div class="create-btn text-center">
                        <p>
                            Have an Account?
                            <a href="employeer-sign-in.php">
                                Sign In
                                <i class='bx bx-chevrons-right bx-fade-right'></i>
                            </a>
                        </p>
                    </div>
                </form>
            </div>  
        </div>
    </div>
</div>
<!-- Sign Up Section End -->
<?php include "includes/footer.php"; ?>