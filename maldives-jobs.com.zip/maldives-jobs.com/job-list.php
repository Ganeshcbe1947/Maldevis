<?php 
    include "includes/header.php"; 
    $employeers_id = $_SESSION['employeers_id'];
?>
<section class="page-title title-bg4">
    <div class="d-table">
        <div class="d-table-cell">
            <h2>Job List</h2>
            <ul>
                <li>
                    <a href="index.php">Home</a>
                </li>
                <li>Job List</li>
            </ul>
        </div>
    </div>
</section>
<section class="job-style-two job-list-section pt-100 pb-70">
    <div class="container">
        <div class="row">
            <?php include "includes/employeers-sidebar.php"; ?>
            <div class="col-md-8">
                <div class="account-details">
                    <div class="section-title text-center">
            <h2>Jobs You May Be Interested In</h2>
             </div>
                <?php
                $jobs_query = "select j.jobs_id,j.jobs_name,j.jobs_location,j.jobs_salary,t.jobs_type_name,j.createdatetime from fn_jobs as j left outer join fn_jobs_type as t on t.jobs_type_id = j.jobs_type_id where j.jobs_employeers = 4 and j.jobs_status = 1 order by j.jobs_id desc";
                $jobs_equery = mysqli_query($db_connection,$jobs_query);			
                while($fet_jobs = mysqli_fetch_array($jobs_equery)) {
                    $jobs_id = $fet_jobs[0];
                    $jobs_name = $fet_jobs[1];
                    $jobs_location = $fet_jobs[2];
                    $jobs_salary = $fet_jobs[3];
                    $jobs_type = $fet_jobs[4];
                    $jobs_date = $fet_jobs[5];
                    $now = time();
                    $your_date = strtotime($jobs_date);
                    $datediff = $now - $your_date;
                    $days = round($datediff / (60 * 60 * 24));
                ?>
                    <div class="job-card-two">
                    <div class="row align-items-center">
                        <div class="col-md-12">
                            <div class="job-info">
                                <h3>
                                    <a href="job-details.php?jobs=<?php echo $jobs_id; ?>"><?php echo $jobs_name; ?></a>
                                </h3>
                                <ul>                                          
                                    <li>
                                        <i class='bx bx-briefcase' ></i>
                                        <?php echo "Location : ".$jobs_location; ?>
                                    </li>
                                    <li>
                                        <i class='bx bx-briefcase' ></i>
                                        <?php echo "Salary : ".$jobs_salary; ?>
                                    </li>
                                   <li>
                                        <i class='bx bx-stopwatch' ></i>
                                        <?php if($days == 0) { echo "Today"; } else { echo "Posted on ".$days." days ago"; } ?>
                                    </li>
                                </ul>

                                <span><?php echo $jobs_type; ?></span>
                                <span><a href="job-details.php?jobs=<?php echo $jobs_id; ?>">
                                    Browse Job
                                </a></span>
                            </div>
                        </div>
                      
                    </div>
                </div>   
                <?php } ?>
                </div>
            </div>
        </div>
    </div>
</section>
 
<?php include "includes/footer.php"; ?>