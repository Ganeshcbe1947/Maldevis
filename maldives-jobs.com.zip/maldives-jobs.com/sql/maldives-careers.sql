-- phpMyAdmin SQL Dump
-- version 5.1.0
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: Feb 28, 2023 at 11:36 AM
-- Server version: 10.4.18-MariaDB
-- PHP Version: 8.0.3

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `maldives-careers`
--

-- --------------------------------------------------------

--
-- Table structure for table `company_information`
--

CREATE TABLE `company_information` (
  `company_id` int(11) NOT NULL,
  `company_name` varchar(255) NOT NULL,
  `company_firstname` varchar(255) NOT NULL,
  `company_lastname` varchar(255) NOT NULL,
  `company_addr` varchar(255) NOT NULL,
  `company_addr1` blob NOT NULL,
  `company_pincode` varchar(255) NOT NULL,
  `company_contact` varchar(255) NOT NULL,
  `company_mobile` varchar(255) NOT NULL,
  `company_email` varchar(255) NOT NULL,
  `company_facebook` varchar(255) NOT NULL,
  `company_twitter` varchar(255) NOT NULL,
  `company_youtube` varchar(255) NOT NULL,
  `company_status` int(11) NOT NULL,
  `createdatetime` varchar(255) NOT NULL,
  `updatedatetime` varchar(255) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `company_information`
--

INSERT INTO `company_information` (`company_id`, `company_name`, `company_firstname`, `company_lastname`, `company_addr`, `company_addr1`, `company_pincode`, `company_contact`, `company_mobile`, `company_email`, `company_facebook`, `company_twitter`, `company_youtube`, `company_status`, `createdatetime`, `updatedatetime`) VALUES
(1, 'Ganesh', 'Ganesh', '', 'Maldvies', '', '', '+91 9940846004', '+91 9940846004', 'contact@techbuddy.in', '', '', '', 1, '1484887745', '2022-08-07 23:42:53');

-- --------------------------------------------------------

--
-- Table structure for table `employee_education`
--

CREATE TABLE `employee_education` (
  `education_id` int(11) NOT NULL,
  `employee_id` int(11) NOT NULL,
  `education_title` varchar(255) NOT NULL,
  `education_course` varchar(255) NOT NULL,
  `education_specialization` varchar(255) NOT NULL,
  `education_university` varchar(255) NOT NULL,
  `education_type` varchar(255) NOT NULL,
  `education_passed` varchar(255) NOT NULL,
  `education_status` int(11) NOT NULL,
  `createdatetime` date NOT NULL,
  `updatedatetime` date NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `employee_education`
--

INSERT INTO `employee_education` (`education_id`, `employee_id`, `education_title`, `education_course`, `education_specialization`, `education_university`, `education_type`, `education_passed`, `education_status`, `createdatetime`, `updatedatetime`) VALUES
(1, 4, '10th', 'Tamil nadu', '10th', 'Board', 'Full time', '2000', 1, '2022-08-06', '0000-00-00'),
(2, 4, '10th', 'Tamil nadu', '10th', 'Board', 'Full time', '2000', 1, '2022-08-06', '0000-00-00'),
(3, 4, '10th', 'Tamil nadu', '10th', 'Board', 'Full time', '2000', 1, '2022-08-06', '0000-00-00'),
(7, 4, 'Master/Post-Graduation', 'MCA', 'Master of Computer Application', 'S.N.R', 'Full Time', '2007', 1, '2022-08-07', '0000-00-00');

-- --------------------------------------------------------

--
-- Table structure for table `employee_experience`
--

CREATE TABLE `employee_experience` (
  `experience_id` int(11) NOT NULL,
  `employee_id` int(11) NOT NULL,
  `employee_type` varchar(255) NOT NULL,
  `employee_company` varchar(255) NOT NULL,
  `employee_designation` varchar(255) NOT NULL,
  `employee_joining` varchar(255) NOT NULL,
  `employee_salary` varchar(255) NOT NULL,
  `employee_profile` varchar(255) NOT NULL,
  `employee_notice` varchar(255) NOT NULL,
  `employee_status` int(11) NOT NULL,
  `createdatetime` date NOT NULL,
  `updatedatetime` date NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `employee_experience`
--

INSERT INTO `employee_experience` (`experience_id`, `employee_id`, `employee_type`, `employee_company`, `employee_designation`, `employee_joining`, `employee_salary`, `employee_profile`, `employee_notice`, `employee_status`, `createdatetime`, `updatedatetime`) VALUES
(1, 4, 'Full Time', 'Techbuddy', 'Project Lead', '2012', '150000', 'Project Lead', 'Immediately', 1, '2022-08-06', '0000-00-00');

-- --------------------------------------------------------

--
-- Table structure for table `employee_skills`
--

CREATE TABLE `employee_skills` (
  `skills_id` int(11) NOT NULL,
  `employee_id` int(11) NOT NULL,
  `skills_title` varchar(255) NOT NULL,
  `skills_experience` varchar(255) NOT NULL,
  `skills_status` int(11) NOT NULL,
  `createdatetime` date NOT NULL,
  `updatedatetime` date NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `employee_skills`
--

INSERT INTO `employee_skills` (`skills_id`, `employee_id`, `skills_title`, `skills_experience`, `skills_status`, `createdatetime`, `updatedatetime`) VALUES
(1, 4, 'Php', '15', 1, '2022-08-06', '0000-00-00'),
(2, 4, 'Mysql', '15', 1, '2022-08-06', '0000-00-00'),
(3, 4, 'Codeigniter', '6', 1, '2022-08-06', '0000-00-00'),
(4, 4, 'Wordpress', '12', 1, '2022-08-06', '0000-00-00'),
(5, 4, 'Drupal', '3', 1, '2022-08-07', '0000-00-00'),
(6, 4, 'Drupal', '3', 1, '2022-08-07', '0000-00-00');

-- --------------------------------------------------------

--
-- Table structure for table `enquiry_information`
--

CREATE TABLE `enquiry_information` (
  `enquiry_id` int(11) NOT NULL,
  `enquiry_firstname` varchar(255) NOT NULL,
  `enquiry_email` varchar(255) NOT NULL,
  `enquiry_contact` varchar(255) NOT NULL,
  `enquiry_subject` varchar(255) NOT NULL,
  `enquiry_services` varchar(255) NOT NULL,
  `enquiry_msg` longblob NOT NULL,
  `enquiry_status` int(11) NOT NULL,
  `createdatetime` varchar(255) NOT NULL,
  `updatedatetime` varchar(255) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Table structure for table `fn_category`
--

CREATE TABLE `fn_category` (
  `category_id` int(11) NOT NULL,
  `category_name` varchar(255) NOT NULL,
  `category_icon` varchar(255) NOT NULL,
  `category_status` int(11) NOT NULL,
  `createdatetime` varchar(255) NOT NULL,
  `updatedatetime` varchar(255) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `fn_category`
--

INSERT INTO `fn_category` (`category_id`, `category_name`, `category_icon`, `category_status`, `createdatetime`, `updatedatetime`) VALUES
(1, 'Accountancy', 'flaticon-accounting', 1, '2022-07-14 15:34:20', '2022-08-06 15:36:48'),
(2, 'Education', 'flaticon-graduation-cap', 1, '2022-07-14 15:34:55', ''),
(3, 'Automotive Jobs', 'flaticon-wrench-and-screwdriver-in-cross', 1, '2022-07-14 15:35:05', ''),
(4, 'Business', 'flaticon-consultation', 1, '2022-07-14 15:35:17', ''),
(5, 'Health Care', 'flaticon-heart', 1, '2022-07-14 15:36:48', ''),
(6, 'IT & Agency', 'flaticon-computer', 1, '2022-07-14 15:37:00', ''),
(7, 'Engineering', 'flaticon-worker', 1, '2022-07-14 15:37:19', ''),
(8, 'Legal', 'flaticon-auction', 1, '2022-07-14 15:37:31', '');

-- --------------------------------------------------------

--
-- Table structure for table `fn_client`
--

CREATE TABLE `fn_client` (
  `client_id` int(11) NOT NULL,
  `client_name` varchar(255) NOT NULL,
  `client_photo` varchar(255) NOT NULL,
  `client_status` int(11) NOT NULL,
  `createdatetime` varchar(255) NOT NULL,
  `updatedatetime` varchar(255) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `fn_client`
--

INSERT INTO `fn_client` (`client_id`, `client_name`, `client_photo`, `client_status`, `createdatetime`, `updatedatetime`) VALUES
(1, 'Infosys', 'images/client/client_1.png', 1, '2023-02-13 15:16:37', ''),
(2, 'cognizant', 'images/client/client_2.png', 1, '2023-02-13 15:17:43', ''),
(3, 'wipro', 'images/client/client_3.png', 1, '2023-02-13 15:18:24', '2023-02-13 15:22:07');

-- --------------------------------------------------------

--
-- Table structure for table `fn_education`
--

CREATE TABLE `fn_education` (
  `education_id` int(11) NOT NULL,
  `education_name` varchar(255) NOT NULL,
  `education_level` varchar(255) NOT NULL,
  `education_duration` varchar(255) NOT NULL,
  `education_location` varchar(255) NOT NULL,
  `education_desc` longtext NOT NULL,
  `education_fee` varchar(255) NOT NULL,
  `education_seats` varchar(255) NOT NULL,
  `education_requirements` varchar(255) NOT NULL,
  `education_type` varchar(255) NOT NULL,
  `education_start` varchar(255) NOT NULL,
  `education_expiry` varchar(255) NOT NULL,
  `education_photo` varchar(255) NOT NULL,
  `education_status` int(11) NOT NULL,
  `createdatetime` datetime NOT NULL,
  `updatedatetime` datetime NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `fn_education`
--

INSERT INTO `fn_education` (`education_id`, `education_name`, `education_level`, `education_duration`, `education_location`, `education_desc`, `education_fee`, `education_seats`, `education_requirements`, `education_type`, `education_start`, `education_expiry`, `education_photo`, `education_status`, `createdatetime`, `updatedatetime`) VALUES
(1, 'Apprenticeship Opportunity - National Certificate 3 in Mason', 'Ordinary Level (OLevel) ', '6 Months', 'Maldives', '<p>This particular skill set is growing in demand in the employment market of Maldives. In this program apprentices will learn to laying bricks and blocks, chimney building and repairs. The apprentices who complete this program can find opportunities in this field.</p><p><strong>Eligibility:</strong></p><p>&nbsp;&nbsp;&nbsp; The World Bank COVID-19 Income Support Project was initiated to assist individuals whose employment was impacted by the pandemic.<br>&nbsp;&nbsp;&nbsp; As per the project requirements, individuals without a job or working less than 20 hours per week (at the time of application) are eligible for this assistance (please refer to the Apprenticeship Program Usoolu for more information).<br>&nbsp;&nbsp;&nbsp; &nbsp;<br><strong>Funding:</strong></p><p>&nbsp;&nbsp;&nbsp; 100% Government Funded<br><strong>Allowance:</strong></p><p>&nbsp;&nbsp;&nbsp; A stipend of MVR 6,000 will be paid monthly for the entire duration of the apprenticeship program.</p><p><br></p>', 'Unspecified', '10', '<p><strong>Student Requirements</strong><br></p><ul><li>Completion of Grade 10 and/or MQA level 2 qualification</li><li>Candidates should be within the age group of 16-35 years.</li></ul>', 'Full Time', '05-08-2022', '20-08-2022', 'images/education/education_1.png', 1, '2022-08-02 14:15:17', '2022-08-02 14:20:38'),
(2, 'PADI Open Water Diver Course to PADI Dive Master Course - Batch 2', 'Entry', '2 months', 'Ocean Junkies', '<dl class=\"section-item row mb-gutter\"><dd class=\"col-md-8 col-lg-9\">PADI Open Water Diver Course to PADI Dive Master Course. <br></dd><dd class=\"col-md-8 col-lg-9\"><br></dd><dd class=\"col-md-8 col-lg-9\"><b>Eligibility:</b><br>&nbsp;&nbsp;&nbsp;\r\n The World Bank COVID-19 Income Support Project was initiated to assist \r\nindividuals whose employment was impacted by the pandemic. <br>&nbsp;&nbsp;&nbsp; As \r\nper the project requirements, individuals without a job or working less \r\nthan 20 hours per week (at the time of application) are eligible for \r\nthis assistance (please refer to the Training Program Usoolu for more \r\ninformation).<br></dd><dd class=\"col-md-8 col-lg-9\"><b>Funding:</b><br>&nbsp;&nbsp;&nbsp; 100% Government Funded<br></dd><dd class=\"col-md-8 col-lg-9\"><br></dd><dd class=\"col-md-8 col-lg-9\"><b>Allowance:</b><br>&nbsp;&nbsp;&nbsp; Monthly MVR 5,000 will be paid as a stipend subject to attendance.<br><br><br></dd></dl>', 'Unspecified', '', '<dl class=\"section-item row mb-gutter\"><dt class=\"col-md-4 col-lg-3 text-dark mb-2\">Student Requirements\r\n    </dt><dd class=\"col-md-8 col-lg-9\">\r\n        <ul class=\"list-bulleted\"><li>Able to swim, medically fit for diving, comfortable in the water</li><', 'Full-Time', '21-07-2022', '06-08-2022', 'images/education/education_2.jpg', 1, '2022-08-02 14:27:52', '2022-08-07 14:12:01');

-- --------------------------------------------------------

--
-- Table structure for table `fn_employee`
--

CREATE TABLE `fn_employee` (
  `employee_id` int(11) NOT NULL,
  `employee_name` varchar(255) NOT NULL,
  `employee_email` varchar(255) NOT NULL,
  `employee_password` varchar(255) NOT NULL,
  `employee_title` varchar(255) NOT NULL,
  `employee_about` blob NOT NULL,
  `employee_cv` varchar(255) NOT NULL,
  `employee_videocv` varchar(255) NOT NULL,
  `employee_youtube` varchar(255) NOT NULL,
  `employee_facebook` varchar(255) NOT NULL,
  `employee_linkedin` varchar(255) NOT NULL,
  `employee_twitter` varchar(255) NOT NULL,
  `employee_contact` varchar(255) NOT NULL,
  `employee_address` varchar(255) NOT NULL,
  `employee_pincode` varchar(255) NOT NULL,
  `employee_photo` varchar(255) NOT NULL,
  `employee_key` varchar(255) NOT NULL,
  `employee_status` int(11) NOT NULL,
  `createdatetime` datetime NOT NULL,
  `updatedatetime` datetime NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `fn_employee`
--

INSERT INTO `fn_employee` (`employee_id`, `employee_name`, `employee_email`, `employee_password`, `employee_title`, `employee_about`, `employee_cv`, `employee_videocv`, `employee_youtube`, `employee_facebook`, `employee_linkedin`, `employee_twitter`, `employee_contact`, `employee_address`, `employee_pincode`, `employee_photo`, `employee_key`, `employee_status`, `createdatetime`, `updatedatetime`) VALUES
(1, 'Anand', 'Anand@techbuddy.in', '', '', '', '', '', '', '', '', '', '9080041940', 'Erode', '638001', 'images/employee/employee_1.jpg', '', 1, '2022-08-02 12:28:07', '0000-00-00 00:00:00'),
(2, 'Ganesh', 'ganesh@gmail.com', '', '', '', '', '', '', '', '', '', '9940846004', 'Coimbatore', '610014', 'images/employee/employee_2.jpg', '', 1, '2022-08-02 12:31:08', '0000-00-00 00:00:00'),
(4, 'Vijay', 'Anand@ananthan.in', 'admin', 'Web developer', 0x4c6f72656d20497073756d2069732073696d706c792064756d6d792074657874206f6620746865207072696e74696e6720616e64207479706573657474696e67200d0a696e6475737472792e204c6f72656d20497073756d20686173206265656e20746865203c666f6e7420636f6c6f723d2223434330303030223e696e647573747279207374616e646172642064756d6d79203c2f666f6e743e746578742065766572200d0a73696e6365207468652031353030732c207768656e20616e20756e6b6e6f776e207072696e74657220746f6f6b20612067616c6c6579206f66207479706520616e64200d0a736372616d626c656420697420746f206d616b65206120747970652073706563696d656e20626f6f6b2e20497420686173207375727669766564206e6f74206f6e6c7920666976650d0a2063656e7475726965732c2062757420616c736f20746865206c65617020696e746f20656c656374726f6e6963207479706573657474696e672c2072656d61696e696e67200d0a657373656e7469616c6c7920756e6368616e6765642e, 'images/employeecv/employee_4.doc', 'images/employeevideocv/employee_4.mp4', 'https://www.youtube.com', 'https://www.facebook.com', 'https://www.linkedin.in', 'https://www.twitter.com', '9551759062', 'Chennai', '600017', 'images/employee/employee_4.jpg', '', 1, '2022-08-06 16:29:35', '2022-08-08 19:04:42');

-- --------------------------------------------------------

--
-- Table structure for table `fn_employeers`
--

CREATE TABLE `fn_employeers` (
  `employeers_id` int(11) NOT NULL,
  `employeers_name` varchar(255) NOT NULL,
  `employeers_company` varchar(255) NOT NULL,
  `employeers_email` varchar(255) NOT NULL,
  `employeers_password` varchar(255) NOT NULL,
  `employeers_contact` varchar(255) NOT NULL,
  `employeers_address` varchar(255) NOT NULL,
  `employeers_pincode` varchar(255) NOT NULL,
  `employeers_photo` varchar(255) NOT NULL,
  `employeers_key` varchar(255) NOT NULL,
  `employeers_status` int(11) NOT NULL,
  `createdatetime` datetime NOT NULL,
  `updatedatetime` datetime NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `fn_employeers`
--

INSERT INTO `fn_employeers` (`employeers_id`, `employeers_name`, `employeers_company`, `employeers_email`, `employeers_password`, `employeers_contact`, `employeers_address`, `employeers_pincode`, `employeers_photo`, `employeers_key`, `employeers_status`, `createdatetime`, `updatedatetime`) VALUES
(1, 'Anand', 'Techbuddy', 'Anand@techbuddy.in', '', '9080041940', 'Erode', '638001', 'images/employeers/employeers_0.jpg', '', 1, '2022-08-02 12:31:51', '0000-00-00 00:00:00'),
(2, 'Ganesh', 'Career', 'ganesh@gmail.com', '', '9940846004', 'Coimbatore', '641014', 'images/employeers/employeers_2.jpg', '', 1, '2022-08-02 12:35:31', '0000-00-00 00:00:00'),
(4, 'Anand', 'Techbuddy', 'Anand@techbuddy.in', 'Anand', '+919080041940', 'Brough road,Erode', '638001', 'images/employeers/employeers_4.jpg', '', 1, '2022-12-15 23:44:51', '2022-08-08 18:57:26');

-- --------------------------------------------------------

--
-- Table structure for table `fn_emp_subscription`
--

CREATE TABLE `fn_emp_subscription` (
  `subscription_emp_id` int(11) NOT NULL,
  `subscribition_id` int(11) NOT NULL,
  `employeers_id` int(11) NOT NULL,
  `subscription_status` int(11) NOT NULL,
  `createdatetime` int(11) NOT NULL,
  `updatedatetime` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `fn_emp_subscription`
--

INSERT INTO `fn_emp_subscription` (`subscription_emp_id`, `subscribition_id`, `employeers_id`, `subscription_status`, `createdatetime`, `updatedatetime`) VALUES
(1, 2, 4, 1, 2147483647, 2147483647);

-- --------------------------------------------------------

--
-- Table structure for table `fn_home`
--

CREATE TABLE `fn_home` (
  `home_id` int(11) NOT NULL,
  `home_name` varchar(255) NOT NULL,
  `home_desc` longtext NOT NULL,
  `home_status` int(11) NOT NULL,
  `createdatetime` datetime NOT NULL,
  `updatedatetime` datetime NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `fn_home`
--

INSERT INTO `fn_home` (`home_id`, `home_name`, `home_desc`, `home_status`, `createdatetime`, `updatedatetime`) VALUES
(1, 'Home', 'Experience the best staying experience with Kerala biggest private \r\nholiday home,resorts, Star category Hotels,villas,cottages, Forest \r\nAmbience Resort, network - We blend in the luxury and comfort of mother \r\nnature in all&nbsp; holiday Destinations in South India. Located in the local\r\n neighborhoods, we treat our guests in touch wood ways, and we take \r\nspecial precautions during pandemics to make the travel and staying \r\nexperience safe and comfortable for travelers.<br>', 1, '0000-00-00 00:00:00', '2021-12-04 12:11:33');

-- --------------------------------------------------------

--
-- Table structure for table `fn_jobs`
--

CREATE TABLE `fn_jobs` (
  `jobs_id` int(11) NOT NULL,
  `jobs_name` varchar(255) NOT NULL,
  `category_id` int(11) NOT NULL,
  `jobs_employeers` varchar(255) NOT NULL,
  `jobs_email` varchar(255) NOT NULL,
  `jobs_location` varchar(255) NOT NULL,
  `jobs_type_id` int(11) NOT NULL,
  `jobs_experience` varchar(255) NOT NULL,
  `jobs_description` longtext NOT NULL,
  `jobs_pdf` varchar(255) NOT NULL,
  `jobs_salary` varchar(255) NOT NULL,
  `jobs_status` int(11) NOT NULL,
  `createdatetime` datetime NOT NULL,
  `updatedatetime` datetime NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `fn_jobs`
--

INSERT INTO `fn_jobs` (`jobs_id`, `jobs_name`, `category_id`, `jobs_employeers`, `jobs_email`, `jobs_location`, `jobs_type_id`, `jobs_experience`, `jobs_description`, `jobs_pdf`, `jobs_salary`, `jobs_status`, `createdatetime`, `updatedatetime`) VALUES
(1, 'Sales Marketing Officer', 4, '4', 'Anand@techbuddy.in', 'Chennai', 1, '2', '<dl class=\"section-item row mb-gutter\"><dd class=\"col-md-8 col-lg-9\">\r\n        <ul><li>Conduct market research to find answers about consumer requirements, habits and trends</li><li>Assist in outbound or inbound marketing activities by demonstrating \r\nexpertise in various areas (content development and optimization, \r\nadvertising, events planning etc.)</li><li>Liaise with external vendors to execute promotional events and campaigns</li><li>Collaborate with marketing and other professionals to coordinate brand awareness and marketing efforts</li><li>Plan and execute initiatives to reach the target audience through appropriate channels (social media, e-mail, TV etc.)</li><li>Assist in analyzing marketing data (campaign results, conversion rates, traffic etc.) to help shape future marketing strategies</li><li>Coordinate and supervise all marketing related work</li><li>Worked on BID &amp; Bid related things is an added advantage.</li></ul>\r\n    </dd></dl>', '', '8000-10000', 1, '2023-01-31 15:44:52', '2022-08-02 16:02:54'),
(2, 'Technician Mechanical', 3, '4', 'ganesh@gmail.com', 'Coimbatore', 1, '3', 'WE ARE SEEKING OPEN-MINDED, ENERGETIC, GENUINE, AND ENTHUSIASTIC INDIVIDUALS TO JOIN OUR TEAM.<br><br>', '', '12000', 1, '2022-08-02 13:11:57', '2022-08-06 15:11:09'),
(5, 'Php Developer', 6, '2', 'Anand@techbuddy.in', 'Bangalore', 1, '12', 'Conduct market research to find answers about consumer requirements, habits and trends\r\nAssist in outbound or inbound marketing activities by demonstrating expertise in various areas (content development and optimization, advertising, events planning etc.)', 'images/jobs/jobs_5.pdf', '7500', 1, '2022-08-06 14:44:28', '2022-08-07 12:33:47'),
(6, 'Wordpress Developer', 6, '4', 'Anand@techbuddy.in', 'Bangalore', 1, '5', 'Demo content for wordpress developer', '', '50000', 1, '2022-08-07 10:29:18', '2022-08-07 10:30:09'),
(7, 'Drupal Developer', 6, '4', 'Anand@techbuddy.in', 'Pune', 1, '1', 'Test content', 'images/jobs/jobs_7.pdf', '15000', 1, '2022-08-07 12:44:40', '2022-08-07 12:50:44'),
(8, 'Drupal', 6, '4', 'Anand@techbuddy.in', 'Bangalore', 1, '2', 'Drupal developer', '', '25000', 1, '2023-02-13 16:11:13', '2023-02-13 16:13:16'),
(9, 'Drupal', 6, '4', 'Anand@techbuddy.in', 'Coimbatore', 1, '2', 'Drupal developer', '', '25000', 1, '2023-02-13 16:12:27', '2023-02-13 16:13:25');

-- --------------------------------------------------------

--
-- Table structure for table `fn_jobs_type`
--

CREATE TABLE `fn_jobs_type` (
  `jobs_type_id` int(11) NOT NULL,
  `jobs_type_name` varchar(255) NOT NULL,
  `jobs_type_status` int(11) NOT NULL,
  `createdatetime` varchar(255) NOT NULL,
  `updatedatetime` varchar(255) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `fn_jobs_type`
--

INSERT INTO `fn_jobs_type` (`jobs_type_id`, `jobs_type_name`, `jobs_type_status`, `createdatetime`, `updatedatetime`) VALUES
(1, 'Full Time', 1, '2022-07-18 17:42:03', ''),
(2, 'Part Time', 1, '2022-07-18 17:42:07', ''),
(3, 'Freelancer', 1, '2022-07-18 17:42:14', '');

-- --------------------------------------------------------

--
-- Table structure for table `fn_login`
--

CREATE TABLE `fn_login` (
  `id` int(11) NOT NULL,
  `loginid` varchar(255) NOT NULL,
  `loginpassword` varchar(255) NOT NULL,
  `loginname` varchar(255) NOT NULL,
  `loginemail` varchar(255) NOT NULL,
  `loginurl` varchar(255) NOT NULL,
  `previouslogintime` datetime NOT NULL,
  `currentlogintime` datetime NOT NULL,
  `loginstatus` int(11) NOT NULL,
  `createdby` int(11) NOT NULL,
  `createddatetime` varchar(255) NOT NULL,
  `updatedby` int(11) NOT NULL,
  `updateddatetime` varchar(255) NOT NULL
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

--
-- Dumping data for table `fn_login`
--

INSERT INTO `fn_login` (`id`, `loginid`, `loginpassword`, `loginname`, `loginemail`, `loginurl`, `previouslogintime`, `currentlogintime`, `loginstatus`, `createdby`, `createddatetime`, `updatedby`, `updateddatetime`) VALUES
(1, 'admin', '21232f297a57a5a743894a0e4a801fc3', 'admin', 'support@techbuddy.in', 'www.techbuddy.in', '2023-02-16 12:28:05', '2023-02-28 13:58:23', 1, 1, '2017-01-01 13:08:12', 0, '0000-00-00 00:00:00');

-- --------------------------------------------------------

--
-- Table structure for table `fn_subscribition`
--

CREATE TABLE `fn_subscribition` (
  `subscribition_id` int(11) NOT NULL,
  `subscribition_name` varchar(255) NOT NULL,
  `subscribition_limit` varchar(255) NOT NULL,
  `subscribition_price` varchar(255) NOT NULL,
  `subscribition_status` int(11) NOT NULL,
  `createdatetime` varchar(255) NOT NULL,
  `updatedatetime` varchar(255) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `fn_subscribition`
--

INSERT INTO `fn_subscribition` (`subscribition_id`, `subscribition_name`, `subscribition_limit`, `subscribition_price`, `subscribition_status`, `createdatetime`, `updatedatetime`) VALUES
(1, '3 month', '20', '100 MVR', 1, '2023-02-13 16:02:40', '2023-02-16 12:38:22'),
(2, '6 month', '30', '150 MVR', 1, '2023-02-13 16:02:50', '2023-02-16 12:39:38'),
(3, '9 month', '40', '200 MVR', 1, '2023-02-13 16:02:57', '2023-02-16 12:39:53'),
(4, '12 month', 'Unlimited', '500 MVR', 1, '2023-02-13 16:03:06', '2023-02-16 12:45:43');

-- --------------------------------------------------------

--
-- Table structure for table `fn_testimonial`
--

CREATE TABLE `fn_testimonial` (
  `testimonial_id` int(11) NOT NULL,
  `testimonial_name` varchar(255) NOT NULL,
  `testimonial_desc` text NOT NULL,
  `testimonial_photo` varchar(255) NOT NULL,
  `testimonial_status` int(11) NOT NULL,
  `createdatetime` varchar(255) NOT NULL,
  `updatedatetime` varchar(255) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Table structure for table `frontslider`
--

CREATE TABLE `frontslider` (
  `frontslider_id` int(11) NOT NULL,
  `frontslider_name` varchar(255) NOT NULL,
  `frontslider_photo` varchar(255) NOT NULL,
  `thumbfrontslideophoto` varchar(255) NOT NULL,
  `originalfrontslideophoto` varchar(255) NOT NULL,
  `frontslider_status` int(11) NOT NULL,
  `createdatetime` varchar(255) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `frontslider`
--

INSERT INTO `frontslider` (`frontslider_id`, `frontslider_name`, `frontslider_photo`, `thumbfrontslideophoto`, `originalfrontslideophoto`, `frontslider_status`, `createdatetime`) VALUES
(1, 'Slide', 'images/frontslider/frontslide_1.jpg', 'images/frontslider/thumbnail/thumbnail_1.jpg', 'images/frontslider/original/original_1.jpg', 1, '2022-07-14 15:07:54');

-- --------------------------------------------------------

--
-- Table structure for table `jobs_applied`
--

CREATE TABLE `jobs_applied` (
  `applied_id` int(11) NOT NULL,
  `employee_id` int(11) NOT NULL,
  `employeers_id` int(11) NOT NULL,
  `jobs_id` int(11) NOT NULL,
  `applied_status` int(11) NOT NULL,
  `createdatetime` date NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `jobs_applied`
--

INSERT INTO `jobs_applied` (`applied_id`, `employee_id`, `employeers_id`, `jobs_id`, `applied_status`, `createdatetime`) VALUES
(1, 4, 4, 5, 1, '2022-08-07'),
(3, 4, 2, 7, 1, '2022-08-07');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `company_information`
--
ALTER TABLE `company_information`
  ADD PRIMARY KEY (`company_id`);

--
-- Indexes for table `employee_education`
--
ALTER TABLE `employee_education`
  ADD PRIMARY KEY (`education_id`);

--
-- Indexes for table `employee_experience`
--
ALTER TABLE `employee_experience`
  ADD PRIMARY KEY (`experience_id`);

--
-- Indexes for table `employee_skills`
--
ALTER TABLE `employee_skills`
  ADD PRIMARY KEY (`skills_id`);

--
-- Indexes for table `enquiry_information`
--
ALTER TABLE `enquiry_information`
  ADD PRIMARY KEY (`enquiry_id`);

--
-- Indexes for table `fn_category`
--
ALTER TABLE `fn_category`
  ADD PRIMARY KEY (`category_id`);

--
-- Indexes for table `fn_client`
--
ALTER TABLE `fn_client`
  ADD PRIMARY KEY (`client_id`);

--
-- Indexes for table `fn_education`
--
ALTER TABLE `fn_education`
  ADD PRIMARY KEY (`education_id`);

--
-- Indexes for table `fn_employee`
--
ALTER TABLE `fn_employee`
  ADD PRIMARY KEY (`employee_id`);

--
-- Indexes for table `fn_employeers`
--
ALTER TABLE `fn_employeers`
  ADD PRIMARY KEY (`employeers_id`);

--
-- Indexes for table `fn_emp_subscription`
--
ALTER TABLE `fn_emp_subscription`
  ADD PRIMARY KEY (`subscription_emp_id`);

--
-- Indexes for table `fn_home`
--
ALTER TABLE `fn_home`
  ADD PRIMARY KEY (`home_id`);

--
-- Indexes for table `fn_jobs`
--
ALTER TABLE `fn_jobs`
  ADD PRIMARY KEY (`jobs_id`);

--
-- Indexes for table `fn_jobs_type`
--
ALTER TABLE `fn_jobs_type`
  ADD PRIMARY KEY (`jobs_type_id`);

--
-- Indexes for table `fn_login`
--
ALTER TABLE `fn_login`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `fn_subscribition`
--
ALTER TABLE `fn_subscribition`
  ADD PRIMARY KEY (`subscribition_id`);

--
-- Indexes for table `fn_testimonial`
--
ALTER TABLE `fn_testimonial`
  ADD PRIMARY KEY (`testimonial_id`);

--
-- Indexes for table `frontslider`
--
ALTER TABLE `frontslider`
  ADD PRIMARY KEY (`frontslider_id`);

--
-- Indexes for table `jobs_applied`
--
ALTER TABLE `jobs_applied`
  ADD PRIMARY KEY (`applied_id`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `company_information`
--
ALTER TABLE `company_information`
  MODIFY `company_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;

--
-- AUTO_INCREMENT for table `employee_education`
--
ALTER TABLE `employee_education`
  MODIFY `education_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=8;

--
-- AUTO_INCREMENT for table `employee_experience`
--
ALTER TABLE `employee_experience`
  MODIFY `experience_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;

--
-- AUTO_INCREMENT for table `employee_skills`
--
ALTER TABLE `employee_skills`
  MODIFY `skills_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=7;

--
-- AUTO_INCREMENT for table `enquiry_information`
--
ALTER TABLE `enquiry_information`
  MODIFY `enquiry_id` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `fn_category`
--
ALTER TABLE `fn_category`
  MODIFY `category_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=9;

--
-- AUTO_INCREMENT for table `fn_client`
--
ALTER TABLE `fn_client`
  MODIFY `client_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=4;

--
-- AUTO_INCREMENT for table `fn_education`
--
ALTER TABLE `fn_education`
  MODIFY `education_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=3;

--
-- AUTO_INCREMENT for table `fn_employee`
--
ALTER TABLE `fn_employee`
  MODIFY `employee_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=5;

--
-- AUTO_INCREMENT for table `fn_employeers`
--
ALTER TABLE `fn_employeers`
  MODIFY `employeers_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=6;

--
-- AUTO_INCREMENT for table `fn_emp_subscription`
--
ALTER TABLE `fn_emp_subscription`
  MODIFY `subscription_emp_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;

--
-- AUTO_INCREMENT for table `fn_home`
--
ALTER TABLE `fn_home`
  MODIFY `home_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;

--
-- AUTO_INCREMENT for table `fn_jobs`
--
ALTER TABLE `fn_jobs`
  MODIFY `jobs_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=10;

--
-- AUTO_INCREMENT for table `fn_jobs_type`
--
ALTER TABLE `fn_jobs_type`
  MODIFY `jobs_type_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=4;

--
-- AUTO_INCREMENT for table `fn_subscribition`
--
ALTER TABLE `fn_subscribition`
  MODIFY `subscribition_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=5;

--
-- AUTO_INCREMENT for table `fn_testimonial`
--
ALTER TABLE `fn_testimonial`
  MODIFY `testimonial_id` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `frontslider`
--
ALTER TABLE `frontslider`
  MODIFY `frontslider_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;

--
-- AUTO_INCREMENT for table `jobs_applied`
--
ALTER TABLE `jobs_applied`
  MODIFY `applied_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=4;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
