<?php 
    include "includes/header.php"; 
    $employeers_id = $_SESSION['employeers_id'];
    $employeers_name = $_SESSION['employeers_name'];
    $employeers_email = $_SESSION['employeers_email'];
   
    $jobs_name = $_POST['jobs_name'];
    $category_id = $_POST['category_id'];	
    $jobs_employeers = $employeers_id;
    $jobs_email = $employeers_email;
    $jobs_location = $_POST['jobs_location'];
    $jobs_type_id = $_POST['jobs_type_id'];
    $jobs_experience = $_POST['jobs_experience'];
    $jobs_description = $_POST['jobs_description'];
    $jobs_pdf = $_POST['jobs_pdf'];
    $jobs_salary = $_POST['jobs_salary'];
    $jobs_status = "0";


    if(isset($_POST['submit'])) {

            if($_GET['id'] == "" ) 
            { $query = "insert into fn_jobs (jobs_name,category_id,jobs_employeers,jobs_email,jobs_location,jobs_type_id,jobs_experience,jobs_description,jobs_salary,jobs_status,createdatetime) "
                    . "values('$jobs_name','$category_id','$jobs_employeers','$jobs_email','$jobs_location','$jobs_type_id','$jobs_experience','$jobs_description','$jobs_salary','$jobs_status', current_timestamp())";	
            }       $result = mysqli_query($db_connection,$query);
                   
                    if ($result == true) {
                            $jobsimagedirectory = "images/jobs";
                            if(is_dir($jobsimagedirectory) == false){ mkdir($jobsimagedirectory, 0777, true); }
			$filename = $_FILES['jobs_pdf']['name'];
			if ($filename != "") {
				if ($_GET['id'] == "") {
					$jobs_query = "select max(jobs_id) from fn_jobs";
					$jobs_equery = mysqli_query($db_connection,$jobs_query);
					$fetchrow = mysqli_fetch_row($jobs_equery);
					$jobs_id = $fetchrow[0];
				}

				else { $jobs_id = $_GET['id']; }


				$fileextension = substr($filename, strlen($filename)-4, 4);
				$jobsimagepath = $jobsimagedirectory."/jobs_".$jobs_id.$fileextension;
				if (move_uploaded_file($_FILES['jobs_pdf']['tmp_name'], $jobsimagepath)){
					chmod($jobsimagepath,0777);	

					$jobsimagepath = str_replace("../", "", $jobsimagepath);					

					$query = "update fn_jobs set jobs_pdf = '".$jobsimagepath."' where (jobs_id = ".$jobs_id.")";			
					$result = mysqli_query($db_connection,$query) or die(mysqli_error());
				
				}
			}
                        $job_msg = "Your posting will approved within 24 hours";
			} else {
                            $job_msg = "Error";
                    }
                    //header("location:jobs-view.php");
            }
?>
<section class="page-title title-bg3">
    <div class="d-table">
        <div class="d-table-cell">
            <h2>Post a Job</h2>
            <ul>
                <li>
                    <a href="index.php">Home</a>
                </li>
                <li>Post a Job</li>
            </ul>
        </div>
    </div>
</section>
<!-- Page Title End -->
<section class="account-section ptb-100">
    <div class="container">
        <div class="row">
            <?php include "includes/employeers-sidebar.php"; ?>
            <div class="col-md-8">
                
    <div class="container">
        <form class="job-post-from" id="FormHome" name="FormName" action="<?PHP $PHP_SELF ?>" method="post" enctype="multipart/form-data" >
            <h2>Fill Up Your Job information</h2>
            <span style="color:red;text-align: center"><?php echo $job_msg; ?></span>
            <div class="row">
                <div class="col-md-6">
                    <div class="form-group">
                        <label>Job Title</label>
                        <input type="text" name="jobs_name" class="form-control" id="exampleInput1" placeholder="Job Title" value="" required>
                    </div>
                </div>

                <div class="col-md-6">
                    <div class="form-group">
                        <label>Job Category</label>
                        <select id="category_id" name="category_id" class="category">
					<option value="" selected="selected">--- Select ---</option>
					<?php
					$query = "select category_id,category_name from fn_category where category_status = '1' order by category_id asc";
					$equery = mysqli_query($db_connection,$query);
                                         while($fetcharray = mysqli_fetch_array($equery)) {
					if($category_id == $fetcharray[0]) {
					echo "<option value='".$fetcharray[0]."' selected='selected'>".$fetcharray[1]."</option>";
					}
					else {
					echo "<option value='".$fetcharray[0]."'>".$fetcharray[1]."</option>";
					}
					}
					?>
				</select>
                    </div>
                </div>


                <div class="col-md-6">
                    <div class="form-group">
                        <label>Location</label>
                        <input type="text" name="jobs_location" class="form-control" id="exampleInput5" placeholder="e.g. London" value="" >
                    </div>
                </div>

                <div class="col-md-6">
                    <div class="form-group">
                        <label>Job Type</label>
                        <select class="category" id="job_type_id" name="jobs_type_id" class="form-control">
                                <option value="" selected="selected">--- Select ---</option>
                                <?php
                                $type_query = "select jobs_type_id,jobs_type_name from fn_jobs_type where jobs_type_status = '1' order by jobs_type_id asc";
                                $type_equery = mysqli_query($db_connection,$type_query);
                                 while($type_fetcharray = mysqli_fetch_array($type_equery)) {
                                if($jobs_type_id == $type_fetcharray[0]) {
                                echo "<option value='".$type_fetcharray[0]."' selected='selected'>".$type_fetcharray[1]."</option>";
                                }
                                else {
                                echo "<option value='".$type_fetcharray[0]."'>".$type_fetcharray[1]."</option>";
                                }
                                }
                                ?>
                        </select>
                    </div>
                </div>
                
                <div class="col-md-6">
                    <div class="form-group">
                        <label>Experience</label>
                        <input type="text" name="jobs_experience" value="" class="form-control" id="exampleInput8" placeholder="e.g. 1 year" required>
                    </div>
                </div>
              
                <div class="col-md-6">
                    <div class="form-group">
                        <label>Salary (Optional)</label>
                        <input type="text" name="jobs_salary" value="" class="form-control" id="exampleInput7" placeholder="e.g. $20,000">
                    </div>
                </div>

                

                <div class="col-md-12">
                    <div class="form-group">
                        <label for="exampleFormControlTextarea1">Job Description</label>
                        <textarea name="jobs_description" class="form-control description-area" id="exampleFormControlTextarea1" rows="6" placeholder="Job Description" required></textarea>
                    </div>
                </div>
                <div class="form-group">
                  <label>Pdf : </label>
                    <?php if($_GET['id'] != "") { ?>
                    <input type="file" id="exampleInputFile" name="jobs_pdf" value="<?php echo $jobs_pdf; ?>"  >
                    <a href="<?php echo $jobs_pdf; ?>" target="_blank">Download Pdf<a>
                    <?php } else { ?>
                     <input type="file" id="exampleInputFile" name="jobs_pdf" >	
                         <?php } ?>
              </div>

                <div class="col-md-12 text-center">
                    <button type="submit" name="submit" value="Submit" class="post-btn">
                        Post A Job
                    </button>
                </div>
            </div>
        </form>
    </div>
</div>
        </div>
    </div>
</section>
<?php include "includes/footer.php"; ?>