<?php 
    include "includes/header.php"; 
    $employee_id = $_SESSION['employee_id'];
    
    
    
    if(isset($_POST['Education'])) {
        $education_title = $_POST['education_title'];
        $education_course = $_POST['education_course'];
        $education_specialization = $_POST['education_specialization'];
        $education_university = $_POST['education_university'];
        $education_type = $_POST['education_type'];
        $education_passed = $_POST['education_passed'];
        
        
        $query = "insert into employee_education (employee_id,education_title,education_course,education_specialization,education_university,education_type,education_passed,education_status,createdatetime) "
                    . "values('$employee_id','$education_title','$education_course','$education_specialization','$education_university','$education_type','$education_passed','1', current_timestamp())";	
        $result = mysqli_query($db_connection,$query);	
      
        if($result == TRUE)
        {
            $update_message = "Your profile updated successfully";
        } else {
            $update_message = "Try later";
        }
        echo "<script>window.location = 'employee-education-view.php'</script>";
	//header("location:employee-education-view.php");
    }
    
    
?>
 
<section class="page-title title-bg10">
    <div class="d-table">
        <div class="d-table-cell">
            <h2>Add Education</h2>
            <ul>
                <li>
                    <a href="index.php">Home</a>
                </li>
                <li>Add Education</li>
            </ul>
        </div>
    </div>   
</section>
<!-- Page Title End -->
<section class="account-section ptb-100">
    <div class="container">
        <div class="row">
            <?php include "includes/employee-sidebar.php"; ?>
            <div class="col-md-8">
                        <div class="account-details">
                            <h3>Add Education</h3>
                            <h5 style="color:red;text-align: center"><?php echo $update_message; ?></h5>
                            <form class="basic-info" name="FormName" action="<?PHP $PHP_SELF ?>" method="post" enctype="multipart/form-data" >
                        <div class="row">
                            <div class="col-md-8">
                                <div class="form-group">
                                    <label>Education</label><br>
                                    <select name="education_title" class="category">
                                        <option value="Board">Board</option>
                                        <option value="Graduation/Diploma">Graduation/Diploma</option>
                                        <option value="Master/Post-Graduation">Master/Post-Graduation</option>
                                        <option value="Doctorate/PhD">Doctorate/PhD</option>
                                      </select>
                                </div>
                            </div>
                            <div class="col-md-8">
                                <div class="form-group">
                                    <label>Course</label>
                                    <input type="text" name="education_course" class="form-control" placeholder="Your Course" value="<?php echo $education_course; ?>">
                                </div>
                            </div>
                            <div class="col-md-8">
                                <div class="form-group">
                                    <label>Specialization</label>
                                    <input type="text" name="education_specialization" class="form-control" placeholder="Your Specialization" value="<?php echo $education_specialization; ?>">
                                </div>
                            </div>
                            <div class="col-md-8">
                                <div class="form-group">
                                    <label>University/Institute</label>
                                    <input type="text" name="education_university" class="form-control" placeholder="University/Institute" value="<?php echo $education_university; ?>">
                                </div>
                            </div>
                            <div class="col-md-8">
                                <div class="form-group">
                                    <label>Course Type</label><br>
                                    <select name="education_type" class="category">
                                        <option value="Full Time">Full Time</option>
                                        <option value="Part Time">Part Time</option>
                                        <option value="Correspondence/Distance learning">Correspondence/Distance learning</option>
                                      </select>
                                </div>
                            </div>
                            <div class="col-md-8">
                                <div class="form-group">
                                    <label>Passing Out Year</label>
                                    <input type="text" name="education_passed" class="form-control" placeholder="Passing Out Year" value="<?php echo $education_passed; ?>">
                                </div>
                            </div>  
                            <div class="col-md-12">
                                <button type="submit" name="Education" class="account-btn">Add Education</button>
                            </div>
                        </div>
                    </form>  

                        </div>
                    </div>
            
        </div>
    </div>
</section>

<?php include "includes/footer.php"; ?>