<?php 
    include "includes/header.php"; 
    
    if (isset($_GET['logout']) && $_GET['logout'] == "true") {
		session_destroy();
		header('location:index.php');
	}
    
    if(isset($_POST['Submit']))
    {
        $employeers_email = $_POST['employeers_email'];
        $employeers_password = $_POST['employeers_password'];
        
        $query = "select employeers_id,employeers_name,employeers_email,employeers_password,employeers_status from fn_employeers where employeers_email = '$employeers_email' and employeers_password = '$employeers_password' and employeers_status = 1";
        $exe_query = mysqli_query($db_connection,$query);
        $row = mysqli_fetch_array($exe_query);
    	$employeers_id = $row ['employeers_id'];
    	$employeers_name = $row ['employeers_name'];
    	$employeers_email = $row ['employeers_email'];
        if($row == true)
        {
            $_SESSION['employeers_id'] = $employeers_id;
            $_SESSION['employeers_name'] = $employeers_name;
            $_SESSION['employeers_email'] = $employeers_email;
            echo "<script>window.location = 'employeer-dashboard.php'</script>";
            //header('location:employeer-dashboard.php');
        } else {
            $msg = "Failed, Try Again";
        }
    }
?>
<section class="page-title title-bg12">
    <div class="d-table">
        <div class="d-table-cell">
            <h2>Sign In</h2>
            <ul>
                <li>
                    <a href="index.php">Home</a>
                </li>
                <li>Sign In</li>
            </ul>
        </div>
    </div>  
</section>
<!-- Page Title End -->

<!-- Sign In Section Start -->
<div class="signin-section ptb-100">
    <div class="container">
        <div class="row">
            <div class="col-lg-6 col-md-8 offset-md-2 offset-lg-3">
                <span style="color:red;text-align: center"><?php echo $msg; ?></span>
                <form class="signin-form" name="FormName" action="<?PHP $PHP_SELF ?>" method="post" enctype="multipart/form-data" >
                    <div class="form-group">
                      <label>Enter Email</label>
                      <input type="email" name="employeers_email" value="" class="form-control" placeholder="Enter Email" required />
                    </div>

                    <div class="form-group">
                        <label>Enter Password</label>
                        <input type="password" name="employeers_password" value="" class="form-control" placeholder="Enter Password" required 
                    </div>

                    <div class="signin-btn text-center">
                        <button type="submit" name="Submit">Sign In</button>
                        <a href="forget-password.php" class="default-btn">Forget Password</a>
                    </div>

                    <div class="create-btn text-center">
                        <p>Not have an account?
                            <a href="employeer-sign-up.php">
                                Create an account
                                <i class='bx bx-chevrons-right bx-fade-right'></i>
                            </a>
                        </p>
                    </div>
                </form>
            </div>  
        </div>
    </div>
</div>
<!-- Sign In Section End -->

<?php include "includes/footer.php"; ?>