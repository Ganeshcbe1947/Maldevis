<?php 
    include "includes/header.php"; 
    $employee_id = $_SESSION['employee_id'];
        
?>
 
<section class="page-title title-bg10">
    <div class="d-table">
        <div class="d-table-cell">
            <h2>Applied Jobs</h2>
            <ul>
                <li>
                    <a href="index.php">Home</a>
                </li>
                <li>Applied Jobs</li>
            </ul>
        </div>
    </div>   
</section>
<!-- Page Title End -->

<section class="account-section ptb-100">
    <div class="container">
        <div class="row">
            <?php include "includes/employee-sidebar.php"; ?>
            <div class="col-md-8">
                        <div class="resume-content employee-text">
                                <h2>Applied Jobs</h2><hr>
                                <?php
                                $jobs_query = "select a.applied_id,a.jobs_id,j.jobs_name,j.jobs_salary,j.jobs_location,a.applied_status from jobs_applied as a "
                                        . "left outer join fn_jobs as j on j.jobs_id = a.jobs_id where a.employee_id ='$employee_id' order by jobs_id desc";
                                $jobs_equery = mysqli_query($db_connection,$jobs_query);			
                                while($fet_jobs = mysqli_fetch_array($jobs_equery))
                                {
                                $applied_id = $fet_jobs[0];
                                $jobs_id = $fet_jobs[1];
                                $jobs_name = $fet_jobs[2];
                                $jobs_salary = $fet_jobs[3];
                                $jobs_location = $fet_jobs[4];
                                ?>
                               <div class="col-lg-12">
                <div class="job-card-two">
                    <div class="row align-items-center">
                        <div class="col-md-8">
                            <div class="job-info">
                                <h3>
                                    <a href="job-details.php?jobs=<?php echo $jobs_id; ?>"><?php echo $jobs_name; ?></a>
                                </h3>
                                <ul>                                          
                                    <li>
                                        <i class='bx bx-briefcase' ></i>
                                        <?php echo $jobs_salary; ?>
                                    </li>
                                    <li>
                                        <i class='bx bx-briefcase' ></i>
                                        <?php echo $jobs_location; ?>
                                    </li>
                                   
                            </div>
                        </div>
                        <div class="col-md-3">
                            <div class="theme-btn text-end">
                                <a href="job-details.php?jobs=<?php echo $jobs_id; ?>" class="default-btn">
                                    Browse Job
                                </a>
                            </div>
                        </div>
                    </div>
                </div>
                               </div><hr>
                                <?php } ?>
                               
                   
                        </div>
                    </div>
            
        </div>
    </div>
</section>


<?php include "includes/footer.php"; ?>