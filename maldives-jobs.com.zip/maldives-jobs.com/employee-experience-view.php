<?php 
    include "includes/header.php"; 
    $employee_id = $_SESSION['employee_id'];
        
?>
 
<section class="page-title title-bg10">
    <div class="d-table">
        <div class="d-table-cell">
            <h2>Experience Background</h2>
            <ul>
                <li>
                    <a href="index.php">Home</a>
                </li>
                <li>Experience Background</li>
            </ul>
        </div>
    </div>   
</section>
<!-- Page Title End -->

<section class="account-section ptb-100">
    <div class="container">
        <div class="row">
            <?php include "includes/employee-sidebar.php"; ?>
            <div class="col-md-8">
                        <div class="resume-content employee-text">
                                <h3>
                                    <i class='bx bx-book-reader'></i>
                                    Experience Background - <a href="employee-experience.php">Add Experience</a>
                                </h3><hr>
                                <?php
                                $employee_query = "select employee_id,employee_profile,employee_company,employee_designation,employee_joining,employee_profile,employee_notice,employee_status from employee_experience where employee_id ='$employee_id' order by experience_id desc";
                                $employee_equery = mysqli_query($db_connection,$employee_query);			
                                while($fet_employee = mysqli_fetch_array($employee_equery))
                                {
                                $employee_id = $fet_employee[0];
                                $employee_profile = $fet_employee[1];
                                $employee_company = $fet_employee[2];
                                $employee_designation = $fet_employee[3];
                                $employee_joining = $fet_employee[4];
                                $employee_profile = $fet_employee[5];
                                $employee_notice = $fet_employee[6];
                                ?>
                                <div class="employee-info">
                                            <h5><?php echo $employee_profile." - ".$employee_designation; ?></h5>
                                            <h4><?php echo $employee_joining; ?></h4>
                                            <?php echo $employee_profile." - ".$employee_notice; ?><hr>
                                </div>
                                <?php } ?>
                               
                   
                        </div>
                    </div>
            
        </div>
    </div>
</section>


<?php include "includes/footer.php"; ?>