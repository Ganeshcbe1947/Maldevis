<?php 
    include "includes/header.php"; 
    $employee_id = $_SESSION['employee_id'];
    
    
    
    if(isset($_POST['Experience'])) {
        $employee_type = $_POST['employee_type'];
        $employee_company = $_POST['employee_company'];
        $employee_designation = $_POST['employee_designation'];
        $employee_joining = $_POST['employee_joining'];
        $employee_salary = $_POST['employee_salary'];
        $employee_profile = $_POST['employee_profile'];
        $employee_notice = $_POST['employee_notice'];
        
        
        $query = "insert into employee_experience (employee_id,employee_type,employee_company,employee_designation,employee_joining,employee_salary,employee_profile,employee_notice,employee_status,createdatetime) "
                    . "values('$employee_id','$employee_type','$employee_company','$employee_designation','$employee_joining','$employee_salary','$employee_profile','$employee_notice','1', current_timestamp())";	
        $result = mysqli_query($db_connection,$query);	
      
        if($result == TRUE)
        {
            $update_message = "Your profile updated successfully";
            echo "<script>window.location = 'employee-experience-view.php'</script>";
            //header("location:employee-experience-view.php");
        } else {
            $update_message = "Try later";
        }
	
    }
    
    
?>
 
<section class="page-title title-bg10">
    <div class="d-table">
        <div class="d-table-cell">
            <h2>Add Experience</h2>
            <ul>
                <li>
                    <a href="index.php">Home</a>
                </li>
                <li>Add Experience</li>
            </ul>
        </div>
    </div>   
</section>
<!-- Page Title End -->
<section class="account-section ptb-100">
    <div class="container">
        <div class="row">
            <?php include "includes/employee-sidebar.php"; ?>
            <div class="col-md-8">
                        <div class="account-details">
                            <h3>Add Experience</h3>
                            <h5 style="color:red;text-align: center"><?php echo $update_message; ?></h5>
                            <form class="basic-info" name="FormName" action="<?PHP $PHP_SELF ?>" method="post" enctype="multipart/form-data" >
                        <div class="row">
                            <div class="col-md-8">
                                <div class="form-group">
                                    <label>Experience Type</label><br>
                                    <select name="employee_type" class="category" placeholder="Experience Type">
                                        <option value="Full Time">Full Time</option>
                                        <option value="Part Time">Part Time</option>
                                        <option value="Internship">Internship</option>
                                      </select>
                                </div>
                            </div>
                            <div class="col-md-8">
                                <div class="form-group">
                                    <label>Company Name</label>
                                    <input type="text" name="employee_company" class="form-control" placeholder="Company Name" value="<?php echo $employee_company; ?>">
                                </div>
                            </div>
                            <div class="col-md-8">
                                <div class="form-group">
                                    <label>Designation</label>
                                    <input type="text" name="employee_designation" class="form-control" placeholder="Your Designation" value="<?php echo $employee_designation; ?>">
                                </div>
                            </div>
                            <div class="col-md-8">
                                <div class="form-group">
                                    <label>Joining Date</label>
                                    <input type="date" name="employee_joining" class="form-control" placeholder="Joining Date" value="<?php echo $employee_joining; ?>">
                                </div>
                            </div>
                            <div class="col-md-8">
                                <div class="form-group">
                                    <label>Annual Salary</label>
                                    <input type="text" name="employee_salary" class="form-control" placeholder="Annual Salary" value="<?php echo $employee_salary; ?>">
                                </div>
                            </div>
                            <div class="col-md-8">
                                <div class="form-group">
                                    <label>Job Profile</label>
                                    <input type="text" name="employee_profile" class="form-control" placeholder="Job Profile" value="<?php echo $employee_profile; ?>">
                                </div>
                            </div>  
                            <div class="col-md-8">
                                <div class="form-group">
                                    <label>Notice Period</label><br>
                                    <select name="employee_notice" class="category">
                                        <option value="15 Days or less">15 Days or less</option>
                                        <option value="1 Month">1 Month</option>
                                        <option value="2 Months">2 Months</option>
                                        <option value="3 Months">3 Months</option>
                                        <option value="More than 3 Months">More than 3 Months</option>
                                        <option value="Immediately">Immediately</option>
                                      </select>
                                </div>
                            </div>  

                          
                            
                           
                            <div class="col-md-12">
                                <button type="submit" name="Experience" class="account-btn">Add Experience</button>
                            </div>
                        </div>
                    </form>  

                        </div>
                    </div>
            
        </div>
    </div>
</section>

<?php include "includes/footer.php"; ?>