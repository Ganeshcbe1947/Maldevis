<?php include "includes/header.php"; ?>
<section class="page-title title-bg41">
    <div class="d-table">
        <div class="d-table-cell">
            <h2><?php echo "Education and Training"; ?></h2>
            <ul>
                <li>
                    <a href="index.php">Home</a>
                </li>
                <li><?php echo "Education and Training"; ?></li>
            </ul>
        </div>
    </div>    
</section>

<section class="job-style-two job-list-section pt-100 pb-70">
    <div class="container">
        
        <div class="row">
            <?php
                $current_date = date('d-m-Y');
                $query = "select education_id,education_name,education_level,education_duration,education_location,education_desc,education_fee,education_seats,education_requirements,education_type,education_start,education_expiry,education_photo,education_status from  fn_education where education_status = 1 order by education_id asc ";
                $equery = mysqli_query($db_connection,$query);			
                while($fet_education = mysqli_fetch_array($equery)) {			
                $education_id = $fet_education[0];
                $education_name = $fet_education[1];
                $education_level = $fet_education[2];
                $education_duration = $fet_education[3];
                $education_location = $fet_education[4];
                $education_desc = $fet_education[5];
                $education_fee = $fet_education[6];
                $education_seats = $fet_education[7];
                $education_requirements = $fet_education[8];
                $education_type = $fet_education[9];
                $education_start = $fet_education[10];
                $education_expiry = $fet_education[11];
                $education_photo = $fet_education[12];
                if($education_expiry >= $current_date)
                {
            ?>
            <div class="col-lg-12">
                <div class="job-card-two">
                    <div class="row align-items-center">
                        <div class="col-md-1">
                                    <div class="company-logo">
                                        <a href="courses-details.php?courses=<?php echo $education_id; ?>"></a>
                                        <img src="<?php echo $education_photo; ?>" alt="logo">
                                    </div>
                                </div>
                        <div class="col-md-8">
                            <div class="job-info">
                                <h3>
                                    <a href="courses-details.php?courses=<?php echo $education_id; ?>"><?php echo $education_name; ?></a>
                                </h3>
                                <ul>                                          
                                   <li>
                                        <i class='bx bx-briefcase' ></i>
                                        <?php echo $education_location; ?>
                                    </li>
                                    <li>
                                        <i class='bx bx-location-plus'></i>
                                        <?php echo $education_duration; ?>
                                    </li>
                                    <li>
                                        <i class='bx bx-stopwatch' ></i>
                                        Start on : <?php echo $education_start; ?> 
                                    </li>
                                    <li>
                                        <i class='bx bx-stopwatch' ></i>
                                        End on : <?php echo $education_expiry; ?> 
                                    </li>
                                </ul>
                                <span><?php echo $education_type; ?></span>
                            </div>
                        </div>
                        <div class="col-md-3">
                            <div class="theme-btn text-end">
                                <a href="courses-details.php?courses=<?php echo $education_id; ?>" class="default-btn">
                                    Browse Courses
                                </a>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
                <?php } } ?>
            
            
        </div>

        
    </div>
</section>
        
<section class="subscribe-section">
    <div class="container">
        <div class="row align-items-center">
            <div class="col-md-6">
                <div class="section-title">
                    <h2>Get New Job Notifications</h2>
                    <p>Subscribe & get all related jobs notification</p>
                </div>
            </div>

            <div class="col-md-6">
                <form class="newsletter-form" data-toggle="validator">
                    <input type="email" class="form-control" placeholder="Enter your email" name="EMAIL" required autocomplete="off">

                    <button class="default-btn sub-btn" type="submit">
                        Subscribe
                    </button>

                    <div id="validator-newsletter" class="form-result"></div>
                </form>
            </div>
        </div>
    </div>
</section>
<?php include "includes/footer.php"; ?>