<?php 
    include "includes/header.php"; 
    
    $id = $_GET['cat_id'];
    $cat_query = "select category_id,category_name, category_status from fn_category where category_id = $id";
    $cat_equery = mysqli_query($db_connection,$cat_query);
    $cat_fetchrow = mysqli_fetch_array($cat_equery);
    $category_name = $cat_fetchrow[1];
?>
<section class="page-title title-bg4">
    <div class="d-table">
        <div class="d-table-cell">
            <h2><?php echo $category_name," Jobs"; ?></h2>
            <ul>
                <li>
                    <a href="index.php">Home</a>
                </li>
                <li><?php echo $category_name; ?></li>
            </ul>
        </div>
    </div>    
</section>

<section class="job-style-two job-list-section pt-100 pb-70">
    <div class="container">
        <div class="section-title text-center">
            <h2>Jobs You May Be Interested In</h2>
        </div>

        <div class="row">
            <?php
                $jobs_query = "select j.jobs_id,j.jobs_name,j.jobs_location,j.jobs_salary,t.jobs_type_name,j.createdatetime from  fn_jobs as j "
                        . "left outer join fn_jobs_type as t on t.jobs_type_id = j.jobs_type_id where j.category_id ='$id' and jobs_status = 1";
                $jobs_equery = mysqli_query($db_connection,$jobs_query);			
                while($fet_jobs = mysqli_fetch_array($jobs_equery)) {
                    $jobs_id = $fet_jobs[0];
                    $jobs_name = $fet_jobs[1];
                    $jobs_location = $fet_jobs[2];
                    $jobs_salary = $fet_jobs[3];
                    $jobs_type = $fet_jobs[4];
                    $jobs_date = $fet_jobs[5];
                    $now = time();
                    $your_date = strtotime($jobs_date);
                    $datediff = $now - $your_date;
                    $days = round($datediff / (60 * 60 * 24));
            ?>
            <div class="col-lg-12">
                <div class="job-card-two">
                    <div class="row align-items-center">
                        <div class="col-md-8">
                            <div class="job-info">
                                <h3>
                                    <a href="job-details.php?jobs=<?php echo $jobs_id; ?>"><?php echo $jobs_name; ?></a>
                                </h3>
                                <ul>                                          
                                    <li>
                                        <i class='bx bx-briefcase' ></i>
                                        <?php echo $category_name; ?>
                                    </li>
                                    <li>
                                        <i class='bx bx-briefcase' ></i>
                                        <?php echo $jobs_salary; ?>
                                    </li>
                                    <li>
                                        <i class='bx bx-location-plus'></i>
                                        <?php echo $jobs_location; ?>
                                    </li>
                                    <li>
                                        <i class='bx bx-stopwatch' ></i>
                                        <?php if($days == 0) { echo "Today"; } else { echo $days." days ago"; } ?>
                                    </li>
                                </ul>
                                <span><?php echo $jobs_type; ?></span>
                            </div>
                        </div>
                        <div class="col-md-3">
                            <div class="theme-btn text-end">
                                <a href="job-details.php?jobs=<?php echo $jobs_id; ?>" class="default-btn">
                                    Browse Job
                                </a>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
            <?php } ?>
            
            
        </div>

        
    </div>
</section>
        
<section class="subscribe-section">
    <div class="container">
        <div class="row align-items-center">
            <div class="col-md-6">
                <div class="section-title">
                    <h2>Get New Job Notifications</h2>
                    <p>Subscribe & get all related jobs notification</p>
                </div>
            </div>

            <div class="col-md-6">
                <form class="newsletter-form" data-toggle="validator">
                    <input type="email" class="form-control" placeholder="Enter your email" name="EMAIL" required autocomplete="off">

                    <button class="default-btn sub-btn" type="submit">
                        Subscribe
                    </button>

                    <div id="validator-newsletter" class="form-result"></div>
                </form>
            </div>
        </div>
    </div>
</section>
<?php include "includes/footer.php"; ?>