<?php 
    include "includes/header.php"; 
    
    $key = $_GET['key'];
    $empkey = $_GET['empkey'];
    
    if($key != "")
    {
        $key_query = "select employee_id,employee_name,employee_key,employee_status from fn_employee where employee_key = '$_GET[key]'";
        $key_equery = mysqli_query($db_connection,$key_query);
        $fetchrow = mysqli_fetch_array($key_equery);
        if($_GET['key'] == $fetchrow[2])
        { 
            $update_query = "update fn_employee set employee_status = 1 where employee_key = '$fetchrow[2]'";
            $upadate_equery = mysqli_query($db_connection,$update_query);
            if($upadate_equery == true)
            {
                $msg = "Account Activated";
                echo "<script>window.location = 'index.php'</script>";
            }
        }
    } 
    
    if($empkey != "")
    {
        $empkey_query = "select employeers_id,employeers_name,employeers_key,employeers_status from fn_employeers where employeers_key = '$_GET[empkey]'";
        $empkey_equery = mysqli_query($db_connection,$empkey_query);
        $empfetchrow = mysqli_fetch_array($empkey_equery);
        if($_GET['empkey'] == $empfetchrow[2])
        { 
            $empupdate_query = "update fn_employeers set employeers_status = 1 where employeers_key = '$empfetchrow[2]'";
            $empupadate_equery = mysqli_query($db_connection,$empupdate_query);
            if($empupadate_equery == true)
            {
                $msg = "Account Activated";
                echo "<script>window.location = 'index.php'</script>";
            }
        }
    } 
?>
<section class="page-title title-bg12">
    <div class="d-table">
        <div class="d-table-cell">
            <h2>Success</h2>
            <ul>
                <li>
                    <a href="index.php">Home</a>
                </li>
                <li>Success</li>
            </ul>
        </div>
    </div>  
</section>
<!-- Page Title End -->

<!-- Sign In Section Start -->
<div class="signin-section ptb-100">
    <div class="container">
        <div class="row">
            <div class="col-lg-6 col-md-8 offset-md-2 offset-lg-3">
                <span style="color:red;text-align: center"><?php echo $msg; ?></span>                
            </div>  
        </div>
    </div>
</div>
<!-- Sign In Section End -->

<?php include "includes/footer.php"; ?>