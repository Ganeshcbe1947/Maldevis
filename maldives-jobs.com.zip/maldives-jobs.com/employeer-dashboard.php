<?php 
    include "includes/header.php"; 
    $employeers_id = $_SESSION['employeers_id'];
    
    $employeers_query = "select employeers_id,employeers_name,employeers_company,employeers_email,employeers_contact,employeers_address,employeers_pincode,employeers_photo,employeers_status from  fn_employeers where employeers_id ='$employeers_id'";
    $employeers_equery = mysqli_query($db_connection,$employeers_query);			
    $fet_employeers = mysqli_fetch_array($employeers_equery);
    $employeers_id = $fet_employeers[0];
    $employeers_name = $fet_employeers[1];
    $employeers_company = $fet_employeers[2];
    $employeers_email = $fet_employeers[3];
    $employeers_contact = $fet_employeers[4];
    $employeers_address = $fet_employeers[5];
    $employeers_pincode = $fet_employeers[6];
    $employeers_photo = $fet_employeers[7];
    
    $employeersimagedirectory = "images/employeers";
    if(is_dir($employeersimagedirectory) == false){ mkdir($employeersimagedirectory, 0777, true); }
    
    if(isset($_POST['Update'])) {
        $employeers_name = $_POST['employeers_name'];
        $employeers_company = $_POST['employeers_company'];
        $employeers_contact = $_POST['employeers_contact'];
        $employeers_address = $_POST['employeers_address'];
        $employeers_pincode = $_POST['employeers_pincode'];
        $employeers_photo = $_POST['employeers_photo'];
        
        $update_query = "update fn_employeers set employeers_name = '$employeers_name',employeers_company = '$employeers_company',employeers_contact = '$employeers_contact',employeers_address = '$employeers_address',employeers_pincode = '$employeers_pincode', updatedatetime = current_timestamp() where employeers_id = $employeers_id";
	//echo $update_query; exit;
	$update_result = mysqli_query($db_connection,$update_query);	
        if($update_result == TRUE)
        {
            $filename = $_FILES['employeers_photo']['name'];
			if ($filename != "") {
				if ($_GET['id'] == "") {
					$query = "select max(employeers_id) from fn_employeers";
					$equery = mysqli_query($db_connection,$query);
					$fetchrow = mysqli_fetch_row($equery);
					$employeers_id = $fetchrow[0];
				}

				else { $employeers_id = $_GET['id']; }


				$fileextension = substr($filename, strlen($filename)-4, 4);
				$employeersimagepath = $employeersimagedirectory."/employeers_".$employeers_id.$fileextension;
				if (move_uploaded_file($_FILES['employeers_photo']['tmp_name'], $employeersimagepath)){
					chmod($employeersimagepath,0777);	

					$employeersimagepath = str_replace("../", "", $employeersimagepath);					

					$query = "update fn_employeers set employeers_photo = '".$employeersimagepath."' where (employeers_id = ".$employeers_id.")";			
					$result = mysqli_query($db_connection,$query) or die(mysqli_error());
                                        $update_message = "Your profile updated successfully";
				}
			}
            
        }
	//header("location:employeers-dashboard.php");
    }
    
?>
<section class="page-title title-bg10">
    <div class="d-table">
        <div class="d-table-cell">
            <h2>Dashboard</h2>
            <ul>
                <li>
                    <a href="index.php">Home</a>
                </li>
                <li>Dashboard</li>
            </ul>
        </div>
    </div>   
</section>
<!-- Page Title End -->

<section class="account-section ptb-100">
    <div class="container">
        <div class="row">
            <?php include "includes/employeers-sidebar.php"; ?>
            <div class="col-md-8">
                <div class="account-details">
                    <h3>Basic Information</h3>
                    <h5 style="color:red;text-align: center"><?php echo $update_message; ?></h5>
                    <form class="signin-form" name="FormName" action="<?PHP $PHP_SELF ?>" method="post" enctype="multipart/form-data" >
                        <div class="row">
                            <div class="col-md-6">
                                <div class="form-group">
                                    <label>Name</label>
                                    <input type="text" name="employeers_name" class="form-control" placeholder="Your Name" value="<?php echo $employeers_name; ?>">
                                </div>
                            </div>

                            <div class="col-md-6">
                                <div class="form-group">
                                    <label>Company</label>
                                    <input type="text" name="employeers_company" class="form-control" placeholder="Your Company" value="<?php echo $employeers_company; ?>">
                                </div>
                            </div>

                            <div class="col-md-6">
                                <div class="form-group">
                                    <label>Address</label>
                                    <input type="text" name="employeers_address" class="form-control" placeholder="Your Address" value="<?php echo $employeers_address; ?>">
                                </div>
                            </div>
                            <div class="col-md-6">
                                <div class="form-group">
                                    <label>Pincode</label>
                                    <input type="text" name="employeers_pincode" class="form-control" placeholder="Your Pincode" value="<?php echo $employeers_pincode; ?>">
                                </div>
                            </div>
                            <div class="col-md-6">
                                <div class="form-group">
                                    <label>Contact</label>
                                    <input type="text" name="employeers_contact" class="form-control" placeholder="Your Phone" value="<?php echo $employeers_contact; ?>">
                                </div>
                            </div>
                            <div class="col-md-12">
                                <div class="form-group">
                                    <label>Photo</label><br>
                                    <?php if($_GET['id'] != "") { ?>
                  <input type="file" id="exampleInputFile" name="employeers_photo" value="<?php echo $employeers_photo; ?>"  >	
				   <img src="<?php echo $employeers_photo; ?>" style="height:150px;width:150px;"	>
				   <?php } else { ?>
				    <input type="file" id="exampleInputFile" name="employeers_photo" >	
					<?php } ?>
                                </div>
                            </div>
                            
                           
                            <div class="col-md-12">
                                <button type="submit" name="Update" class="account-btn">Update</button>
                            </div>
                        </div>
                    </form>                    
                </div>
            </div>
        </div>
    </div>
</section>


<?php include "includes/footer.php"; ?>