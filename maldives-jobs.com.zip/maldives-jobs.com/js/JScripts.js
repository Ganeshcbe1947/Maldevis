// Roshan's Ajax dropdown code with php
// This notice must stay intact for legal use
// Copyright reserved to Roshan Bhattarai - nepaliboy007@yahoo.com
// If you have any problem contact me at http://roshanbh.com.np
function getXMLHTTP() { //fuction to return the xml http object
	var xmlhttp=false;	
	try{
		xmlhttp=new XMLHttpRequest();
	}
	catch(e)	{		
		try{			
			xmlhttp= new ActiveXObject("Microsoft.XMLHTTP");
		}
		catch(e){
			try{
			xmlhttp = new ActiveXObject("Msxml2.XMLHTTP");
			}
			catch(e1){
				xmlhttp=false;
			}
		}
	}
		
	return xmlhttp;
}

function buttonClicked()
{
alert('button click called');
}



function DeleteConfirmation(URL, Record) {
	var DeleteRecord = "";
	if (Record != undefined) { DeleteRecord = ' "' + Record + '"' }
	if (confirm('Are you sure you want to delete this record' + DeleteRecord + '?') == true) {
		window.location.href = URL;
		return true;
	}
	return false;
}

function LTrim(str) {
        var whitespace = new String(" \t\n\r "); 
        // last space character is not a space, but alt+0160, another invisible char. 
        var s = new String(str);
        if (whitespace.indexOf(s.charAt(0)) != -1) {
            // We have a string with leading blank(s)...
            var j=0, i = s.length;
            // Iterate from the far left of string until we don't have any more whitespace...
            while (j < i && whitespace.indexOf(s.charAt(j)) != -1)
                j++;
            // Get the substring from the first non-whitespace character to the end of the string...
            s = s.substring(j, i);
        }
        return s;
}
// Trims all spaces to the right of a specific string
function RTrim(str)
{
        // We don't want to trip JUST spaces, but also tabs, line feeds, etc.  Add anything else you want to "trim" here in whitespace
        var whitespace = new String(" \t\n\r "); 
        // last space character is not a space, but alt+0160, another invisible char. 
        var s = new String(str);
        if (whitespace.indexOf(s.charAt(s.length-1)) != -1) {
            // We have a string with trailing blank(s)...
            var i = s.length - 1;       // Get length of string
            // Iterate from the far right of string until we don't have any more whitespace...
            while (i >= 0 && whitespace.indexOf(s.charAt(i)) != -1)
                i--;
            // Get the substring from the front of the string to where the last non-whitespace character is...
            s = s.substring(0, i+1);
        }
        return s;
}

// Trims all spaces to the left and right of a specific string by calling RTim and LTrim
function trim(Control) {
	Control.value = RTrim(LTrim(Control.value))
	return Control.value;
}


//IsNumeric function for check the entered value is numeric only
function isNumeric(expression) {
	var nums = "0123456789";
	if (expression.length==0)return(false);
	for (var n=0; n < expression.length; n++){
		if(nums.indexOf(expression.charAt(n))==-1)return(false);
	}
	
	return(true);
}

//isAlpha function for check the entered value is alpha only
function isAlpha(expression){  
	var regEx = /^[a-zA-Z.,\s\-]+$/;
	if(expression.match(regEx) == null) { return false; } else { return true; }
}

//isAlphaNumeric function for check the entered value is alphanumeric only
function isAlphaNumeric(expression){  
	var regEx = /^[a-zA-Z0-9.,\s\-]+$/;  
	if(expression.match(regEx) == null) { return false; } else { return true; }
}

function isEmail(expression) {
	var regEx = 	/^.+\@.+\..+$/;
	return regEx.test(expression);
}

function showwindow(url)
{
    var surl = url.split('.');
    var winname = surl[0];
	        
    var width=650;
    var height=550;
    var top=gettop(height);
    var left=getleft(width);
     
    var win=window.open(url,winname,'toolbar=no,location=no,top='+top+',left='+left+',width='+width+',height='+height+',menubar=no,scrollbars=yes,status=yes,resizable=yes');
    if (win==null) {
		alert("Please disable your popup blocker");
	}
	else {
		win = top;
		win.opener = top; 
	}
}

function gettop(height){
    var wheight = getViewportHeight();
    return (wheight/2)-(height/2);
}
function getleft(width){
    var wwidth = getViewportWidth();
    return (wwidth/2)-(width/2);
}
function getViewportHeight() {
	if (window.innerHeight!=window.undefined) return window.innerHeight;
	if (document.compatMode=='CSS1Compat') return document.documentElement.clientHeight;
	if (document.body) return document.body.clientHeight; 

	return window.undefined; 
}
function getViewportWidth() {
	var offset = 17;
	var width = null;
	if (window.innerWidth!=window.undefined) return window.innerWidth; 
	if (document.compatMode=='CSS1Compat') return document.documentElement.clientWidth; 
	if (document.body) return document.body.clientWidth; 
}
function checkPw(form) {
			var vpassword=document.getElementById('password').value;
			var vpasswordconfirmation=document.getElementById('passwordconfirmation').value;
			password = form.password.value;
			passwordconfirmation = form.passwordconfirmation.value;

			if (vpassword != vpasswordconfirmation) {
				alert ("\nPlease re-enter your password.");
				return false;
			}
			
}
function Validate_String(string, return_invalid_chars)
         {
         valid_chars = '1234567890-_.^~abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ';
         invalid_chars = '';
         
         if(string == null || string == '')
            return(true);
         
         //For every character on the string.   
         for(index = 0; index < string.length; index++)
            {
            char = string.substr(index, 1);                        
            
            //Is it a valid character?
            if(valid_chars.indexOf(char) == -1)
              {
              //If not, is it already on the list of invalid characters?
              if(invalid_chars.indexOf(char) == -1)
                {
                //If it's not, add it.
                if(invalid_chars == '')
                   invalid_chars += char;
                else
                   invalid_chars += ', ' + char;
                }
              }
            }                     
            
         //If the string does not contain invalid characters, the function will return true.
         //If it does, it will either return false or a list of the invalid characters used
         //in the string, depending on the value of the second parameter.
         if(return_invalid_chars == true && invalid_chars != '')
           {
           last_comma = invalid_chars.lastIndexOf(',');
           
           if(last_comma != -1)
              invalid_chars = invalid_chars.substr(0, $last_comma) + 
              ' and ' + invalid_chars.substr(last_comma + 1, invalid_chars.length);
                      
           return(invalid_chars);
           }
         else
           return(invalid_chars == ''); 
         }


function Validate_Email_Address(email_address)
         {
         //Assumes that valid email addresses consist of user_name@domain.tld
         at = email_address.indexOf('@');
         dot = email_address.indexOf('.');
         
         if(at == -1 || 
            dot == -1 || 
            dot <= at + 1 ||
            dot == 0 || 
            dot == email_address.length - 1)
            return(false);
            
         user_name = email_address.substr(0, at);
         domain_name = email_address.substr(at + 1, email_address.length);                  
         
         if(Validate_String(user_name) === false || 
            Validate_String(domain_name) === false)
            return(false);                     
         
         return(true);
         }
