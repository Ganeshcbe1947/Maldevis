<?php 
    include "includes/header.php"; 
    $employee_id = $_SESSION['employee_id'];
    
    $employee_query = "select employee_id,employee_youtube,employee_facebook,employee_linkedin,employee_twitter,employee_status from  fn_employee where employee_id ='$employee_id'";
    $employee_equery = mysqli_query($db_connection,$employee_query);			
    $fet_employee = mysqli_fetch_array($employee_equery);
    $employee_id = $fet_employee[0];
    $employee_youtube = $fet_employee[1];
    $employee_facebook = $fet_employee[2];
    $employee_linkedin = $fet_employee[3];
    $employee_twitter = $fet_employee[4];
    
    if(isset($_POST['Social'])) {
        $employee_youtube = $_POST['employee_youtube'];
        $employee_facebook = $_POST['employee_facebook'];
        $employee_linkedin = $_POST['employee_linkedin'];
        $employee_twitter = $_POST['employee_twitter'];
        
        $update_query = "update fn_employee set employee_youtube = '$employee_youtube',employee_facebook = '$employee_facebook',employee_linkedin = '$employee_linkedin',employee_twitter = '$employee_twitter', updatedatetime = current_timestamp() where employee_id = $employee_id";
	//echo $update_query; exit;
	$update_result = mysqli_query($db_connection,$update_query);	
        if($update_result == TRUE)
        {
            $update_message = "Your profile updated successfully";
        }
	//header("location:employee-dashboard.php");
    }
    
?>
<section class="page-title title-bg10">
    <div class="d-table">
        <div class="d-table-cell">
            <h2>Social Links</h2>
            <ul>
                <li>
                    <a href="index.php">Home</a>
                </li>
                <li>Social Links</li>
            </ul>
        </div>
    </div>   
</section>
<!-- Page Title End -->

<section class="account-section ptb-100">
    <div class="container">
        <div class="row">
            <?php include "includes/employee-sidebar.php"; ?>
            <div class="col-md-8">
                        <div class="account-details">
                            <h3>Social Links</h3>
                            <h5 style="color:red;text-align: center"><?php echo $update_message; ?></h5>
                            <form class="basic-info" name="FormName" action="<?PHP $PHP_SELF ?>" method="post" enctype="multipart/form-data" >
                        <div class="row">
                            <div class="col-md-6">
                                <div class="form-group">
                                    <label>Youtube</label>
                                    <input type="text" name="employee_youtube" class="form-control" placeholder="Your Youtube" value="<?php echo $employee_youtube; ?>">
                                </div>
                            </div>

                          <div class="col-md-6">
                                <div class="form-group">
                                    <label>Linkedin</label>
                                    <input type="text" name="employee_linkedin" class="form-control" placeholder="Your Linkedin" value="<?php echo $employee_linkedin; ?>">
                                </div>
                            </div>
                            <div class="col-md-6">
                                <div class="form-group">
                                    <label>Twitter</label>
                                    <input type="text" name="employee_twitter" class="form-control" placeholder="Your Twitter" value="<?php echo $employee_twitter; ?>">
                                </div>
                            </div>
                            <div class="col-md-6">
                                <div class="form-group">
                                    <label>Facebook</label>
                                    <input type="text" name="employee_facebook" class="form-control" placeholder="Your Facebook" value="<?php echo $employee_facebook; ?>">
                                </div>
                            </div>
                           
                            <div class="col-md-12">
                                <button type="submit" name="Social" class="account-btn">Update</button>
                            </div>
                        </div>
                    </form>  
                            
                        </div>
                    </div>
            
        </div>
    </div>
</section>


<?php include "includes/footer.php"; ?>