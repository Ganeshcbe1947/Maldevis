<?php include 'includes/header.php'; ?>
<section class="page-title title-bg15">
    <div class="d-table">
        <div class="d-table-cell">
            <h2>404</h2>
            <ul>
                <li>
                    <a href="index.php">Home</a>
                </li>
                <li>404</li>
            </ul>
        </div>
    </div>  
</section>
<!-- Page Title End -->

<!-- Error Section Start -->
<div class="error-section ptb-100">
    <div class="container">
        <div class="row">
            <div class="col-md-8 offset-md-2">
                <div class="error-img">
                    <img src="images/404.png" alt="error image">
                    <div class="theme-btn text-center">
                        <a href="index.php" class="default-btn">Go To Home</a>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>
<!-- Error Section End -->
<?php include 'includes/footer.php'; ?>