<?php 
    include "includes/header.php"; 
    $employee_id = $_SESSION['employee_id'];
        
?>
 
<section class="page-title title-bg10">
    <div class="d-table">
        <div class="d-table-cell">
            <h2>Education Background</h2>
            <ul>
                <li>
                    <a href="index.php">Home</a>
                </li>
                <li>Education Background</li>
            </ul>
        </div>
    </div>   
</section>
<!-- Page Title End -->

<section class="account-section ptb-100">
    <div class="container">
        <div class="row">
            <?php include "includes/employee-sidebar.php"; ?>
            <div class="col-md-8">
                        <div class="resume-content education-text">
                                <h3>
                                    <i class='bx bx-book-reader'></i>
                                    Education Background - <a href="employee-education.php">Add Education</a>
                                </h3><hr>
                                <?php
                                $education_query = "select education_id,education_title,education_course,education_specialization,education_university,education_type,education_passed,education_status from employee_education where employee_id ='$employee_id' order by education_id desc";
                                $education_equery = mysqli_query($db_connection,$education_query);			
                                while($fet_education = mysqli_fetch_array($education_equery))
                                {
                                $education_id = $fet_education[0];
                                $education_title = $fet_education[1];
                                $education_course = $fet_education[2];
                                $education_specialization = $fet_education[3];
                                $education_university = $fet_education[4];
                                $education_type = $fet_education[5];
                                $education_passed = $fet_education[6];
                                ?>
                                <div class="education-info">
                                            <h5><?php echo $education_title." - ".$education_specialization; ?></h5>
                                            <h4><?php echo $education_university; ?></h4>
                                            <?php echo $education_type." - ".$education_passed; ?><hr>
                                </div>
                                <?php } ?>
                               
                   
                        </div>
                    </div>
            
        </div>
    </div>
</section>


<?php include "includes/footer.php"; ?>