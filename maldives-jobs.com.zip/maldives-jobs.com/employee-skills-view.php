<?php 
    include "includes/header.php"; 
    $employee_id = $_SESSION['employee_id'];
        
?>
 
<section class="page-title title-bg10">
    <div class="d-table">
        <div class="d-table-cell">
            <h2>Skills Background</h2>
            <ul>
                <li>
                    <a href="index.php">Home</a>
                </li>
                <li>Skills Background</li>
            </ul>
        </div>
    </div>   
</section>
<!-- Page Title End -->

<section class="account-section ptb-100">
    <div class="container">
        <div class="row">
            <?php include "includes/employee-sidebar.php"; ?>
            <div class="col-md-8">
                        <div class="resume-content skills-text">
                                <h3>
                                    <i class='bx bx-book-reader'></i>
                                    Skills Background
                                </h3>
                                <h5><a href="employee-skills.php">Add Skills</a></h5>
                                <?php
                                $skills_query = "select skills_id,skills_title,skills_experience,skills_status from employee_skills where employee_id ='$employee_id'";
                                $skills_equery = mysqli_query($db_connection,$skills_query);			
                                while($fet_skills = mysqli_fetch_array($skills_equery))
                                {
                                $skills_id = $fet_skills[0];
                                $skills_title = $fet_skills[1];
                                $skills_experience = $fet_skills[2];
                                ?>
                                <div class="skills-info">
                                            <h5><?php echo $skills_title." - ".$skills_experience." Years"; ?></h5>                                       
                                </div>
                                <?php } ?>
                               
                   
                        </div>
                    </div>
            
        </div>
    </div>
</section>


<?php include "includes/footer.php"; ?>