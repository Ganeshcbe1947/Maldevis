<?php
    include "includes/header.php"; 
    $employee_id = $_SESSION['employee_id'];
    $id = $_GET['jobs'];
    
    
    $query = "select jobs_id,jobs_name,category_id,jobs_employeers,jobs_email,jobs_location,jobs_type_id,jobs_experience,jobs_description,jobs_pdf,jobs_salary,createdatetime,jobs_status from  fn_jobs where jobs_id ='$id'";
    $equery = mysqli_query($db_connection,$query);			
    $fet_jobs = mysqli_fetch_array($equery);
    $jobs_id = $fet_jobs[0];
    $jobs_name = $fet_jobs[1];
    $category_name = $fet_jobs[2];
    $jobs_employeers = $fet_jobs[3];
    $jobs_email = $fet_jobs[4];
    $jobs_location = $fet_jobs[5];
    $jobs_type_name = $fet_jobs[6];
    $jobs_experience = $fet_jobs[7];
    $jobs_description = $fet_jobs[8];
    $jobs_pdf = $fet_jobs[9];
    $jobs_salary = $fet_jobs[10];
    $jobs_date = $fet_jobs[11];
    $now = time();
    $your_date = strtotime($jobs_date);
    $datediff = $now - $your_date;
    $days = round($datediff / (60 * 60 * 24));
    
    if(isset($_POST['Apply']))
    {
        if($employee_id == "")
        {
            echo "<script>window.location = 'employee-sign-in.php'</script>";
        } else {
            $insert_applied = "insert into jobs_applied(employee_id,employeers_id,jobs_id,applied_status,createdatetime) "
                . "value('$employee_id','$jobs_employeers','$id','1',current_timestamp())";
            $exe_query = mysqli_query($db_connection,$insert_applied);
            if($exe_query == true)
            {
                $success = "You have successfully applied";
            } else {
                echo "Try again";
            }
        }
    }
?>
<section class="page-title title-bg6">
    <div class="d-table">
        <div class="d-table-cell">
            <h2><?php echo $jobs_name; ?></h2>
            <ul>
                <li>
                    <a href="index.php">Home</a>
                </li>
                <li><?php echo $jobs_name; ?></li>
            </ul>
        </div>
    </div>  
</section>
<!-- Page Title End -->

<!-- Job Details Section Start -->
<section class="job-details ptb-100">
    <div class="container">
        <div class="row">
            <div class="col-lg-8">
                <div class="row">
                    <div class="col-lg-12">
                        <div class="job-details-text">
                            <div class="job-card">
                                <div class="row align-items-center">
                                    <div class="col-md-10">
                                        <span style="color:red;text-align: center"><?php echo $success; ?></span>
                                        <div class="job-info">
                                            <h3><?php echo $jobs_name; ?></h3>
                                            <ul>
                                                <li>
                                                    <i class='bx bx-location-plus'></i>
                                                    <?php echo $jobs_location; ?>
                                                </li>
                                            </ul>

                                            <span>
                                                <i class='bx bx-paper-plane' ></i>
                                                Posted on: <?php if($days == 0) { echo "Today"; } else { echo $days." days ago"; } ?>
                                            </span>
                                        </div>
                                    </div>
                                </div>
                            </div>

                            <div class="details-text">
                                <h3>Description</h3>
                                <?php echo $jobs_description; ?>
                            </div>
                            
                            <div class="details-text">
                                <b>Experience : </b> <?php echo $jobs_experience; ?>
                            </div>
                            <?php if($jobs_pdf != "") { ?>
                            <div class="theme-btn">
                                <a href="<?php echo $jobs_pdf; ?>" target="_blank" class="default-btn">Download Pdf</a>
                            </div>
                            <?php } 
                                $applied_query = "select applied_id,employee_id,jobs_id,applied_status from jobs_applied where employee_id = $employee_id and jobs_id = $id";
                                $applied_equery = mysqli_query($db_connection,$applied_query);			
                                $applied_jobs = mysqli_fetch_array($applied_equery);
                                $applied_id = $applied_jobs[0];
                                if($applied_id == "") {
                            ?>
                            <form class="basic-info" name="FormName" action="<?PHP $PHP_SELF ?>" method="post" enctype="multipart/form-data" >
                            <div class="theme-btn">
                                <input type="submit" name="Apply" value="Apply Now" class="default-btn">
                            </div>
                            </form>                    
                                <?php } else { ?>
                            <div class="theme-btn">
                                <button class="default-btn" style="background-color: green">Already Applied</button>                                
                            </div>
                                <?php } ?>
                            
                        </div>
                    </div>
                </div>
            </div>

            <div class="col-lg-4">
                <div class="job-sidebar">
                    
                    <h3>Posted on</h3>
                    <div class="posted-by">
                        <h4><?php if($days == 0) { echo "Today"; } else { echo $days." days ago"; } ?></h4>
                    </div>
                </div>
                
                
        </div>
    </div>
</section>

<!-- Subscribe Section Start -->
<section class="subscribe-section">
    <div class="container">
        <div class="row align-items-center">
            <div class="col-md-6">
                <div class="section-title">
                    <h2>Get New Job Notifications</h2>
                    <p>Subscribe & get all related jobs notification</p>
                </div>
            </div>

            <div class="col-md-6">
                <form class="newsletter-form" data-toggle="validator">
                    <input type="email" class="form-control" placeholder="Enter your email" name="EMAIL" required autocomplete="off">

                    <button class="default-btn sub-btn" type="submit">
                        Subscribe
                    </button>

                    <div id="validator-newsletter" class="form-result"></div>
                </form>
            </div>
        </div>
    </div>
</section>
<!-- Subscribe Section End -->
<?php include "includes/footer.php"; ?>