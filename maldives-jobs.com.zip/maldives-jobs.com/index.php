<?php 
    include "includes/header.php"; 
    
    if(isset($_POST['Submit']))
    {
        $jobs_name = $_POST['jobs_name'];
        $jobs_location = $_POST['jobs_location'];
        
        if($jobs_name !="" and $jobs_location != "")
        {
            echo "<script>window.location = 'jobs.php?title=$jobs_name&location=$jobs_location'</script>";
        } elseif($jobs_name !="")
        {
            echo "<script>window.location = 'jobs.php?title=$jobs_name'</script>";
        } elseif($jobs_location != "")
        {
            echo "<script>window.location = 'jobs.php?location=$jobs_location'</script>";
        } 
        
    }
?>
<div class="banner-section">
<div class="d-table">
    <div class="d-table-cell">
            <div class="container"> 
                    <div class="banner-content text-center">
                            <p>Find Jobs, Employment & Career Opportunities</p>
                            <h1>Drop Resume & Get Your Desire Job!</h1>

                            <form class="banner-form" name="FormName" action="<?PHP $PHP_SELF ?>" method="post" enctype="multipart/form-data" >
                                    <div class="row">
                                            <div class="col-md-4">
                                                    <div class="form-group">
                                                            <label for="exampleInputEmail1">Keyword:</label>
                                                            <input type="text" name="jobs_name" value="" class="form-control" id="exampleInputEmail1" placeholder="Job Title">
                                                    </div>
                                            </div>

                                            <div class="col-md-4">
                                                    <div class="form-group">
                                                            <label for="exampleInputEmail2">Location:</label>
                                                            <input type="text" name="jobs_location" value="" class="form-control" id="exampleInputEmail2" placeholder="City or State">
                                                    </div>
                                            </div>

                                            <div class="col-md-4">
                                                <button type="submit" name="Submit" class="find-btn">
                                                            Find A Job
                                                            <i class='bx bx-search'></i>
                                                    </button>
                                            </div>
                                    </div>
                            </form>

                            <ul class="keyword">
                                    <li>Trending Keywords:</li>
                                    <li><a href="#">Automotive,</a></li>
                                    <li><a href="#">Education,</a></li>
                                    <li><a href="#">Health</a></li>
                                    <li>and</li>
                                    <li><a href="#">Care Engineering</a></li>
                            </ul>
                    </div>
            </div>
    </div>
</div>
</div>
<script src="vendors/jquery.min.js"></script>
<script src="assets/owlcarousel/owl.carousel.js"></script>
<section class="categories-section pt-100 pb-70">
<div class="container">
        <div class="section-title text-center">
                <h2>Choose Your Category</h2>
        </div>

        <div class="row">
            <?php
                $category_query = "select category_id,category_name,category_icon, category_status from fn_category order by category_id desc";
                $category_equery = mysqli_query($db_connection,$category_query);
                while($category_fetchrow = mysqli_fetch_array($category_equery)) {
                    $category_id = $category_fetchrow[0];
                    $category_name = $category_fetchrow[1];
                    $category_icon = $category_fetchrow[2];
            ?> 
                <div class="col-lg-3 col-md-4 col-sm-6">
                        <a href="job-category.php?cat_id=<?php echo $category_id; ?>">
                                <div class="category-card">
                                        <i class='<?php echo $category_icon; ?>'></i>
                                        <h3><?php echo $category_name; ?></h3>
                                        <?php
                                        $cat_job = "select count(category_id) from fn_jobs where category_id = '$category_id' and jobs_status = 1";
                                        $cat_equery = mysqli_query($db_connection,$cat_job);
                                        $cat_fetchrow = mysqli_fetch_array($cat_equery);                                        
                                        ?>
                                        <p><?php echo $cat_fetchrow[0]; ?> open position</p>
                                </div>
                        </a>
                </div>
                <?php } ?>
        </div>
</div>
</section>
<!-- Category Section End -->

<!-- Jobs Section Start -->
<section class="job-section pb-70">
        <div class="container">
        <div class="section-title text-center">
                <h2>Jobs You May Be Interested In</h2>
        </div>

        <div class="row">
            <?php			
                $jobs_query = "select j.jobs_id,j.jobs_name,c.category_name,e.employeers_company,j.jobs_location,t.jobs_type_name,j.createdatetime from fn_jobs as j left outer join fn_category as c on c.category_id = j.category_id left outer join fn_employeers as e on e.employeers_id = j.jobs_employeers left outer join fn_jobs_type as t on t.jobs_type_id = j.jobs_type_id where j.jobs_status =1 order by j.jobs_id asc";
                $jobs_equery = mysqli_query($db_connection,$jobs_query);			
                while($fet_jobs = mysqli_fetch_array($jobs_equery)) {			
                $jobs_id = $fet_jobs[0];
                $jobs_name = $fet_jobs[1];
                $category_name = $fet_jobs[2];			
                $employeers_company = $fet_jobs[3];			
                $jobs_location = $fet_jobs[4];
                $jobs_type = $fet_jobs[5];
                $jobs_date = $fet_jobs[6];
                $now = time();
                $your_date = strtotime($jobs_date);
                $datediff = $now - $your_date;
                $days = round($datediff / (60 * 60 * 24));
                if($days <= 15)
                    {
            ?>
                <div class="col-sm-6">
                        <div class="job-card">
                                <div class="row align-items-center">
                                        
                                        <div class="col-lg-6">
                                                <div class="job-info">
                                                        <h3>
                                                                <a href="job-details.php?jobs=<?php echo $jobs_id; ?>"><?php echo $jobs_name; ?></a>
                                                        </h3>
                                                        <ul>
                                                                <li>Via <a href="#"><?php echo $employeers_company; ?></a></li>
                                                                <li>
                                                                        <i class='bx bx-location-plus'></i>
                                                                        <?php echo $jobs_location; ?>
                                                                </li>
                                                                <li>
                                                                        <i class='bx bx-filter-alt' ></i>
                                                                        <?php echo $category_name; ?>
                                                                </li>                                                               
                                                        </ul>
                                                </div>
                                        </div>

                                        <div class="col-lg-3">
                                                <div class="job-save">
                                                        <span><?php echo $jobs_type; ?></span>
                                                        <a href="#">
                                                                <i class='bx bx-heart'></i>
                                                        </a>
                                                        <p>
                                                                <i class='bx bx-stopwatch' ></i>
                                                                <?php echo $days; ?> days ago
                                                        </p>
                                                </div>
                                        </div>
                                </div>
                        </div>
                </div>
                <?php } } ?>
        </div>
        </div>
</section>
<!-- Jobs Section End -->

<!-- Way To Use Section Start -->
<section class="use-section" style="padding-top:25px">
        <div class="container">
                <div class="section-title text-center">
                        <h2>Easiest Way To Use</h2>
                </div>

                <div class="row">
                        <div class="col-md-4 col-sm-6">
                                <div class="use-text">
                                        <span>1</span>
                                        <i class='flaticon-website'></i>
                                        <h3>Browse Job</h3>
                                </div>
                        </div>

                        <div class="col-md-4 col-sm-6">
                                <div class="use-text">
                                        <span>2</span>
                                        <i class='flaticon-recruitment'></i>
                                        <h3>Find Your Vaccancy</h3>
                                </div>
                        </div>

                        <div class="col-md-4 col-sm-6 offset-sm-3 offset-md-0">
                                <div class="use-text">
                                        <span>3</span>
                                        <i class='flaticon-login'></i>
                                        <h3>Submit Resume</h3>
                                </div>
                        </div>
                </div>
        </div>
</section>
<!-- Way To Use Section End -->

<!-- Job Info Section Start -->
<div class="job-info pt-100 pb-70">
        <div class="container">
                <div class="row">
                        <div class="col-md-6">
                                <div class="looking-job">
                                        <div class="media">
                                                <i class='flaticon-group align-self-start mr-3'></i>
                                                <div class="media-body">
                                                        <h5 class="mt-0">Looking For a Job</h5>
                                                        <p>Your next role could be with one of these top leading organizations</p>

                                                        <a href="job-list.php">
                                                                Apply Now
                                                                <i class='bx bx-chevrons-right'></i>
                                                        </a>
                                                </div>
                                        </div>
                                </div>
                        </div>

                        <div class="col-md-6">
                                <div class="recruiting-card">
                                        <div class="media">
                                                <i class='flaticon-resume align-self-start mr-3'></i>
                                                <div class="media-body">
                                                        <h5 class="mt-0">Are You Recruiting?</h5>
                                                        <p>Your next role could be with one of these top leading organizations</p>

                                                        <a href="post-job.php">
                                                                Apply Now
                                                                <i class='bx bx-chevrons-right'></i>
                                                        </a>
                                                </div>
                                        </div>
                                </div>  
                        </div>
                </div>
        </div>
</div>
<section id="demos">
      <div class="row">
        <div class="large-12 columns">
          <div class="owl-carousel owl-theme">
              <?php
                $query = "select client_id,client_name,client_photo from fn_client order by client_id desc";
                $equery = mysqli_query($db_connection,$query);
                while($fetchrow = mysqli_fetch_array($equery)) {
                ?> 
            <div class="item">
                <img src="<?php echo $fetchrow[2]; ?>">
            </div>
               <?php } ?>
          </div>
          <script>
            $(document).ready(function() {
              var owl = $('.owl-carousel');
              owl.owlCarousel({
                items: 4,
                loop: true,
                margin: 10,
                autoplay: true,
                autoplayTimeout: 1000,
                autoplayHoverPause: true
              });
              $('.play').on('click', function() {
                owl.trigger('play.owl.autoplay', [1000])
              })
              $('.stop').on('click', function() {
                owl.trigger('stop.owl.autoplay')
              })
            })
          </script>
        </div>
      </div>
    </section>
<?php include "includes/footer.php"; ?>

