<section class="sidebar">
  <!-- Sidebar user panel -->
 <ul class="sidebar-menu">
	<li class="header">MAIN NAVIGATION</li>
	<li class="treeview">
	  <a href="index.php"><i class="fa fa-edit"></i> <span>Dashboard</span> </a>
	</li>
	<li class="treeview">
	  <a href="<?php echo $link; ?>" target="_blank"><i class="fa fa-edit"></i> <span>Website View</span> </a>
	</li>
	<li class="treeview">
	  <a href="information.php"><i class="fa fa-edit"></i> <span>Company Information</span> </a>
	</li>
	<!--<li class="treeview">
	  <a href="admin/changepassword"><i class="fa fa-edit"></i> <span>Change Password</span> </a>
	</li>
	<li class="treeview">
	  <a  href="frontslide-view.php"><i class="fa fa-edit"></i> <span>Slider</span> </a>
	</li>-->	
	<li class="treeview">
	  <a  href="category-view.php"><i class="fa fa-edit"></i> <span>Category</span> </a>
	</li>
        <li class="treeview">
	  <a  href="employee-view.php"><i class="fa fa-edit"></i> <span>Employee(Candidates)</span> </a>
	</li>
        <li class="treeview">
	  <a  href="employeers-view.php"><i class="fa fa-edit"></i> <span>Employeers</span> </a>
	</li>
        <li class="treeview">
	  <a  href="jobs-type-view.php"><i class="fa fa-edit"></i> <span>Jobs Type</span> </a>
	</li>
        <li class="treeview">
	  <a  href="jobs-view.php"><i class="fa fa-edit"></i> <span>Post Jobs</span> </a>
	</li>
	<li class="treeview">
	  <a  href="education-view.php"><i class="fa fa-edit"></i> <span>Education and training</span> </a>
	</li>	
	<li class="treeview">
	  <a  href="client-view.php"><i class="fa fa-edit"></i> <span>Client</span> </a>
	</li>	
	<li class="treeview">
	  <a  href="subscribition-view.php"><i class="fa fa-edit"></i> <span>Subscribition</span> </a>
	</li>	
	<li class="treeview">
	  <a  href="subscribition-emp-view.php"><i class="fa fa-edit"></i> <span>Employee Subscribition</span> </a>
	</li>	
	<li class="treeview">
	  <a href="#"><i class="fa fa-edit"></i> <span>Enquiry</span> </a>
	</li>		
  </ul>
</section>