<?php

	include("../../includes/config.php");


	if (isset($_GET['logout']) && $_GET['logout'] == "true") {
		session_destroy();
		$errormessage = "You are successfully logged out";
	}

	if (isset($_POST['btnLogin'])) {

		$query = "SELECT id, loginpassword, loginname, currentlogintime from fn_login 

			where (loginid = '".$_POST['txtLoginId']."' and loginstatus = 1)";
			

		$equery = mysqli_query($db_connection,$query) or die (mysqli_error());

		if(mysqli_num_rows($equery) > 0) {

			$fetchrow = mysqli_fetch_array($equery);

			if ($fetchrow[1] == md5($_POST['txtPassword'])) {

				$db_loginid = $fetchrow['id'];

				$db_previouslogintime = $fetchrow['currentlogintime'];

				$query = "update fn_login set previouslogintime = '".$db_previouslogintime."', currentlogintime = current_timestamp() where (id = ".$db_loginid.")";

				$equery = mysqli_query($db_connection,$query) or die (mysqli_error());

				

				//assigning session values

				$_SESSION['id'] = $db_loginid;
				$_SESSION[$loginid] = $fetchrow[0];
				$_SESSION['loginname'] = $fetchrow[2];
		
				echo "<script>window.location='../index.php'</script>";


			}

			else { $errormessage = "Invalid Password"; }

		}

		else { $errormessage = "Invalid Login Id"; }

	}

?>
<!DOCTYPE html>
<html>
  <head>
    <meta charset="UTF-8">
    <title><?PHP echo $projecttitle; ?> :: Login</title>
    <meta content='width=device-width, initial-scale=1, maximum-scale=1, user-scalable=no' name='viewport'>
    <!-- Bootstrap 3.3.4 -->
    <link href="../bootstrap/css/bootstrap.min.css" rel="stylesheet" type="text/css" />
    <!-- Font Awesome Icons -->
    <link href="https://maxcdn.bootstrapcdn.com/font-awesome/4.3.0/css/font-awesome.min.css" rel="stylesheet" type="text/css" />
    <!-- Theme style -->
    <link href="../dist/css/AdminLTE.min.css" rel="stylesheet" type="text/css" />
    <!-- iCheck -->
    <link href="../plugins/iCheck/square/blue.css" rel="stylesheet" type="text/css" />
  </head>
  <script language="javascript" type="text/javascript">

		function FocusToLoginId() { document.formlogin.txtLoginId.focus(); }



		function ValidateControls() {

			if(document.formlogin.txtLoginId.value == "") {

				alert("Enter Login Id");

				document.formlogin.txtLoginId.focus();

				return false;

			}

			if(document.formlogin.txtPassword.value == "") {

				alert("Enter Password");

				document.formlogin.txtPassword.focus();

				return false;

			}

			return true;

		}

	</script>

  <body class="login-page" onLoad="FocusToLoginId()">
    <div class="login-box">
      <div class="login-logo">
          <img src="../../images/logo.png" border="0" alt="<?php echo $projecttitle; ?>" style="height:150px;width:250px;">
      </div><!-- /.login-logo -->
      <div class="login-box-body">
	  <?PHP

			if (isset($_GET['Logout'])&& $_GET['Logout'] == "True") { echo("<font color='#FEFEFF'>You are now logged out.</font>"); }

			if ($errormessage != "") { echo("<font color='red'>".$errormessage."</font>"); }

		?>
       <form name="formlogin" method="post" action="login.php" onSubmit="return ValidateControls();">
          <div class="form-group has-feedback">
            <input type="text" class="form-control" name="txtLoginId" placeholder="Username"/>
            <span class="glyphicon glyphicon-envelope form-control-feedback"></span>
          </div>
          <div class="form-group has-feedback">
            <input type="password" class="form-control" placeholder="Password" name="txtPassword"/>
            <span class="glyphicon glyphicon-lock form-control-feedback"></span>
          </div>
          <div class="row">
            
            <div class="col-xs-4">
			<input type="submit" name="btnLogin" id="btnLogin" value="Login" class="btn btn-primary btn-block btn-flat">
            </div><!-- /.col -->
          </div>
        </form>

      </div><!-- /.login-box-body -->
    </div><!-- /.login-box -->

    <!-- jQuery 2.1.4 -->
    <script src="../plugins/jQuery/jQuery-2.1.4.min.js"></script>
    <!-- Bootstrap 3.3.2 JS -->
    <script src="../bootstrap/js/bootstrap.min.js" type="text/javascript"></script>
    <!-- iCheck -->
    <script src="../plugins/iCheck/icheck.min.js" type="text/javascript"></script>
    <script>
      $(function () {
        $('input').iCheck({
          checkboxClass: 'icheckbox_square-blue',
          radioClass: 'iradio_square-blue',
          increaseArea: '20%' // optional
        });
      });
    </script>
  </body>
</html>