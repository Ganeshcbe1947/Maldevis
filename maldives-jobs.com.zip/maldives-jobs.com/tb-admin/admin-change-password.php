<?PHP

	include("../includes/config.php");

	if($_SESSION[$loginid] == "") { header("location: pages/login.php?access=denied");  }

	$pagename = "Change Password";

	

	if (isset($_POST['submit']) == true) {

		$currentpassword = $_POST['currentpassword'];

		$newpassword = $_POST['newpassword'];

		$confirmpassword = $_POST['confirmpassword'];

		

		$query = "select loginpassword from fn_login where loginname = '$_SESSION[$loginid]'";

		$equery = mysqli_query($db_connection,$query);

		$fetchrow = mysqli_fetch_row($equery);

		$existingpassword = $fetchrow[0];

		

		if($existingpassword == md5($currentpassword)) {

			$query = "update fn_login set loginpassword = '".md5($newpassword)."' where (loginname = '$_SESSION[$loginid]')";

			$result = mysqli_query($db_connection,$query) or die($message = "<span class='errormessage'>".mysqli_error()."</span>");

			if ($result == true) {

				$message = "<span style='color:red'>Password changed successfully</span>";

			}

		}

		else {

			$message = "<span style='color:red'>Current password is not valid</span>";

		}		

	}

?>
<!DOCTYPE html>
<html>
  <head>
    <meta charset="UTF-8">
    <title><?php echo $projecttitle; ?></title>
    <meta content='width=device-width, initial-scale=1, maximum-scale=1, user-scalable=no' name='viewport'>
    <!-- Bootstrap 3.3.4 -->
    <link href="bootstrap/css/bootstrap.min.css" rel="stylesheet" type="text/css" />    
    <!-- FontAwesome 4.3.0 -->
    <link href="https://maxcdn.bootstrapcdn.com/font-awesome/4.3.0/css/font-awesome.min.css" rel="stylesheet" type="text/css" />
    <!-- Ionicons 2.0.0 -->
    <link href="https://code.ionicframework.com/ionicons/2.0.1/css/ionicons.min.css" rel="stylesheet" type="text/css" />    
    <!-- Theme style -->
    <link href="dist/css/AdminLTE.min.css" rel="stylesheet" type="text/css" />
    <!-- AdminLTE Skins. Choose a skin from the css/skins 
         folder instead of downloading all of them to reduce the load. -->
    <link href="dist/css/skins/_all-skins.min.css" rel="stylesheet" type="text/css" />
    <!-- iCheck -->
    <link href="plugins/iCheck/flat/blue.css" rel="stylesheet" type="text/css" />
    <!-- Morris chart -->
    <link href="plugins/morris/morris.css" rel="stylesheet" type="text/css" />
    <!-- jvectormap -->
    <link href="plugins/jvectormap/jquery-jvectormap-1.2.2.css" rel="stylesheet" type="text/css" />
    <!-- Date Picker -->
    <link href="plugins/datepicker/datepicker3.css" rel="stylesheet" type="text/css" />
    <!-- Daterange picker -->
    <link href="plugins/daterangepicker/daterangepicker-bs3.css" rel="stylesheet" type="text/css" />
    <!-- bootstrap wysihtml5 - text editor -->
    <link href="plugins/bootstrap-wysihtml5/bootstrap3-wysihtml5.min.css" rel="stylesheet" type="text/css" />
  </head><script language="JavaScript" type="text/javascript">

	function FormValidation(DocumentForm) {

		//DocumentForm.currentpassword.value = trim(DocumentForm.currentpassword);

		//DocumentForm.newpassword.value = trim(DocumentForm.newpassword);

		//DocumentForm.confirmpassword.value = trim(DocumentForm.confirmpassword);



		if(DocumentForm.currentpassword.value == "") {

			alert("Enter Current Password");

			DocumentForm.currentpassword.focus();

			return false;

		}		

		if(DocumentForm.newpassword.value == "") {

			alert("Enter New Password");

			DocumentForm.newpassword.focus();

			return false;

		}		

		if(DocumentForm.confirmpassword.value == "") {

			alert("Enter Confirm Password");

			DocumentForm.confirmpassword.focus();

			return false;

		}

		if(DocumentForm.newpassword.value != DocumentForm.confirmpassword.value) {

			alert("Entered passwords are mismatched");

			DocumentForm.confirmpassword.select();

			return false;

		}

		

		return true;

	}

</script>
  <body class="skin-blue sidebar-mini">
    <div class="wrapper">
      <?php include("../includes/admin-header.php"); ?>
     
      <!-- Left side column. contains the logo and sidebar -->
      <aside class="main-sidebar">
        <!-- sidebar: style can be found in sidebar.less -->
       <?php include("pages/sidebar.php"); ?>
        <!-- /.sidebar -->
      </aside>

      <!-- Content Wrapper. Contains page content -->
      <div class="content-wrapper">
        <!-- Content Header (Page header) -->
        <section class="content-header">
          <h1>Change Password</h1>
          <ol class="breadcrumb">
            <li><a href="index.php"><i class="fa fa-dashboard"></i> Home</a></li>
            <li class="active">Change Password</li>
          </ol>
        </section>

        <!-- Main content -->
        <section class="content">

          <!-- Default box -->
          <div class="box">
            <div class="box-header with-border">
              <h3 class="box-title">Change Password</h3>
              <div class="box-tools pull-right">
                <button class="btn btn-box-tool" data-widget="collapse" data-toggle="tooltip" title="Collapse"><i class="fa fa-minus"></i></button>
                <button class="btn btn-box-tool" data-widget="remove" data-toggle="tooltip" title="Remove"><i class="fa fa-times"></i></button>
              </div>
            </div>
            <div class="box-body">
			<?php if ($message != "") { echo "<tr><td colspan='2' style='color:red'>".$message."</td></tr>"; } ?>
              <form id="FormWelcome" name="FormWelcome" action="<?php $PHP_SELF ?>" method="post" onsubmit="return FormValidation(this);">
                  <div class="box-body">
                    <div class="form-group">
                      <label for="exampleInputEmail1">Current Password</label>
                      <input type="password" class="form-control" placeholder="Current Password" name="currentpassword">
                    </div>
                    <div class="form-group">
                      <label for="exampleInputPassword1">New Password</label>
                      <input type="password" class="form-control" id="exampleInputPassword1" placeholder="New Password" name="newpassword">
                    </div>
					<div class="form-group">
                      <label for="exampleInputPassword1">Confirm Password</label>
                      <input type="password" class="form-control" id="exampleInputPassword1" placeholder="Confirm Password" name="confirmpassword">
                    </div>
                   
                    
                  </div><!-- /.box-body -->

                  <div class="box-footer">
				  	<input type="submit" id="submit" name="submit" value="Submit" class="btn btn-primary" />
					<input type="reset" id="reset" name="reset" value="Reset" class="btn btn-primary">
                  </div>
                </form>
            </div><!-- /.box-body -->
            
          </div><!-- /.box -->

        </section><!-- /.content -->
      </div><!-- /.content-wrapper -->

        </section><!-- /.content -->
     
      <footer class="main-footer">
         <?php include("../includes/admin-footer.php"); ?>
      </footer>
      
     
      <!-- Add the sidebar's background. This div must be placed
           immediately after the control sidebar -->
      <div class='control-sidebar-bg'></div>
    </div><!-- ./wrapper -->

    <!-- jQuery 2.1.4 -->
    <script src="plugins/jQuery/jQuery-2.1.4.min.js"></script>
    <!-- jQuery UI 1.11.2 -->
    <script src="http://code.jquery.com/ui/1.11.2/jquery-ui.min.js" type="text/javascript"></script>
    <!-- Resolve conflict in jQuery UI tooltip with Bootstrap tooltip -->
    <script>
      $.widget.bridge('uibutton', $.ui.button);
    </script>
    <!-- Bootstrap 3.3.2 JS -->
    <script src="bootstrap/js/bootstrap.min.js" type="text/javascript"></script>    
    <!-- Morris.js charts -->
    <script src="http://cdnjs.cloudflare.com/ajax/libs/raphael/2.1.0/raphael-min.js"></script>
    <script src="plugins/morris/morris.min.js" type="text/javascript"></script>
    <!-- Sparkline -->
    <script src="plugins/sparkline/jquery.sparkline.min.js" type="text/javascript"></script>
    <!-- jvectormap -->
    <script src="plugins/jvectormap/jquery-jvectormap-1.2.2.min.js" type="text/javascript"></script>
    <script src="plugins/jvectormap/jquery-jvectormap-world-mill-en.js" type="text/javascript"></script>
    <!-- jQuery Knob Chart -->
    <script src="plugins/knob/jquery.knob.js" type="text/javascript"></script>
    <!-- daterangepicker -->
    <script src="https://cdnjs.cloudflare.com/ajax/libs/moment.js/2.10.2/moment.min.js" type="text/javascript"></script>
    <script src="plugins/daterangepicker/daterangepicker.js" type="text/javascript"></script>
    <!-- datepicker -->
    <script src="plugins/datepicker/bootstrap-datepicker.js" type="text/javascript"></script>
    <!-- Bootstrap WYSIHTML5 -->
    <script src="plugins/bootstrap-wysihtml5/bootstrap3-wysihtml5.all.min.js" type="text/javascript"></script>
    <!-- Slimscroll -->
    <script src="plugins/slimScroll/jquery.slimscroll.min.js" type="text/javascript"></script>
    <!-- FastClick -->
    <script src='plugins/fastclick/fastclick.min.js'></script>
    <!-- AdminLTE App -->
    <script src="dist/js/app.min.js" type="text/javascript"></script>    
    
    <!-- AdminLTE dashboard demo (This is only for demo purposes) -->
    <script src="dist/js/pages/dashboard.js" type="text/javascript"></script>    
  
  </body>
</html>