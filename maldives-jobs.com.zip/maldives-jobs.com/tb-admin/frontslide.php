<?PHP

	include("../includes/config.php");

	include("thumbnail.php");

	//if($_SESSION[$loginid] == "") { header("location: login.php?access=denied");  }

	$title = "Front Slide";
	$frontslider_name = $_POST['frontslider_name'];
	$frontslider_photo = $_POST['frontslider_photo'];
	//$frontslider_status = $_POST['frontslider_status'];
	$frontslider_status = "1";

	$frontslideimagedirectory = "../images/frontslider";
	if(is_dir($frontslideimagedirectory) == false){ mkdir($frontslideimagedirectory, 0777, true); }

	$frontslidethumbnailimagedirectory = $frontslideimagedirectory."/thumbnail";
	if(is_dir($frontslidethumbnailimagedirectory) == false){ mkdir($frontslidethumbnailimagedirectory, 0777, true); }	

	$frontslideoriginalimagedirectory = $frontslideimagedirectory."/original";
	if(is_dir($frontslideoriginalimagedirectory) == false){ mkdir($frontslideoriginalimagedirectory, 0777, true); }	

	if(isset($_POST['Submit'])) {
	
		if($_GET['id'] == "" ) 
		{ $query = "insert into frontslider (frontslider_name, frontslider_status, createdatetime) values('$frontslider_name','$frontslider_status', current_timestamp())";	
		} else {
		$query = "update frontslider set frontslider_name = '$frontslider_name', frontslider_status = '$frontslider_status', updateddatetime = current_timestamp() where frontslider_id = $_GET[id]";
		}
			$result = mysqli_query($db_connection,$query);	
			if ($result == true) {
		$filename = $_FILES['frontslider_photo']['name'];
			if ($filename != "") {
				if ($_GET['id'] == "") {
					$query = "select max(frontslider_id) from frontslider";
					$equery = mysqli_query($db_connection,$query);
					$fetchrow = mysqli_fetch_row($equery);
					$frontslider_id = $fetchrow[0];
				}

				else { $frontslider_id = $_GET['id']; }


				$fileextension = substr($filename, strlen($filename)-4, 4);
				$frontslideimagepath = $frontslideimagedirectory."/frontslide_".$frontslider_id.$fileextension;
				if (move_uploaded_file($_FILES['frontslider_photo']['tmp_name'], $frontslideimagepath)){
					chmod($frontslideimagepath,0777);	

					$width=200;
					$height=150;
					$frontslidethumbnailimagepath = $frontslidethumbnailimagedirectory."/thumbnail_".$frontslider_id.$fileextension;
					thumbnail($frontslideimagepath, $frontslidethumbnailimagepath, $width, $height);					

					$width=725;
					$height=520;
					$frontslideoriginalimagedirectory = $frontslideoriginalimagedirectory."/original_".$frontslider_id.$fileextension;
					original($frontslideimagepath, $frontslideoriginalimagedirectory, $width, $height);					
		

					$frontslidethumbnailimagepath = str_replace("../", "", $frontslidethumbnailimagepath);
					$frontslideoriginalimagedirectory = str_replace("../", "", $frontslideoriginalimagedirectory);	
					$frontslideimagepath = str_replace("../", "", $frontslideimagepath);					

					$query = "update frontslider set thumbfrontslideophoto = '".$frontslidethumbnailimagepath."', originalfrontslideophoto = '".$frontslideoriginalimagedirectory."', frontslider_photo = '".$frontslideimagepath."' where (frontslider_id = ".$frontslider_id.")";			

					$result = mysqli_query($db_connection,$query) or die(mysqli_error());				
				}
			}
			}
			header("location:frontslide-view.php");

		}
?>
<!DOCTYPE html>
<html>
  <head>
    <meta charset="UTF-8">
    <title><?PHP echo $projecttitle." :: ".$pagename; ?></title>
    <meta content='width=device-width, initial-scale=1, maximum-scale=1, user-scalable=no' name='viewport'>
    <!-- Bootstrap 3.3.4 -->
    <link href="bootstrap/css/bootstrap.min.css" rel="stylesheet" type="text/css" />    
    <!-- FontAwesome 4.3.0 -->
    <link href="https://maxcdn.bootstrapcdn.com/font-awesome/4.3.0/css/font-awesome.min.css" rel="stylesheet" type="text/css" />
    <!-- Ionicons 2.0.0 -->
    <link href="https://code.ionicframework.com/ionicons/2.0.1/css/ionicons.min.css" rel="stylesheet" type="text/css" />    
    <!-- Theme style -->
    <link href="dist/css/AdminLTE.min.css" rel="stylesheet" type="text/css" />
    <!-- AdminLTE Skins. Choose a skin from the css/skins 
         folder instead of downloading all of them to reduce the load. -->
    <link href="dist/css/skins/_all-skins.min.css" rel="stylesheet" type="text/css" />
    <!-- iCheck -->
    <link href="plugins/iCheck/flat/blue.css" rel="stylesheet" type="text/css" />
    <!-- Morris chart -->
    <link href="plugins/morris/morris.css" rel="stylesheet" type="text/css" />
    <!-- jvectormap -->
    <link href="plugins/jvectormap/jquery-jvectormap-1.2.2.css" rel="stylesheet" type="text/css" />
    <!-- Date Picker -->
    <link href="plugins/datepicker/datepicker3.css" rel="stylesheet" type="text/css" />
    <!-- Daterange picker -->
    <link href="plugins/daterangepicker/daterangepicker-bs3.css" rel="stylesheet" type="text/css" />
    <!-- bootstrap wysihtml5 - text editor -->
    <link href="plugins/bootstrap-wysihtml5/bootstrap3-wysihtml5.min.css" rel="stylesheet" type="text/css" />

  </head>
  <body class="skin-blue sidebar-mini">
    <div class="wrapper">
      <?php include("../includes/admin-header.php"); ?>
     
      <!-- Left side column. contains the logo and sidebar -->
      <aside class="main-sidebar">
        <!-- sidebar: style can be found in sidebar.less -->
       <?php include("pages/sidebar.php"); ?>
        <!-- /.sidebar -->
      </aside>

      <!-- Content Wrapper. Contains page content -->
      <div class="content-wrapper">
        <!-- Content Header (Page header) -->
          <!-- Main content -->
        <section class="content">

          <!-- Default box -->
          <div class="box">
            <div class="box-header with-border">
              <h3 class="box-title">Slider</h3>
              <div class="box-tools pull-right">
                <button class="btn btn-box-tool" data-widget="collapse" data-toggle="tooltip" title="Collapse"><i class="fa fa-minus"></i></button>
                <button class="btn btn-box-tool" data-widget="remove" data-toggle="tooltip" title="Remove"><i class="fa fa-times"></i></button>
              </div>
            </div>
             <div class="box-body">			
		    <form id="FormHome" name="FormName" action="<?PHP $PHP_SELF ?>" method="post" enctype="multipart/form-data" >
                  <div class="box-body">
                    <div class="form-group">
                      <label for="exampleInputEmail1">Title</label>
                      <input type="text" class="form-control" placeholder="Title" name="frontslider_name" id="frontslider_name" value="">
                    </div>
					<div class="form-group">
                      <label for="exampleInputPassword1">Upload</label>
                      <input type="file" id="exampleInputFile" name="frontslider_photo" >					
                    </div>                 
                    
                  </div><!-- /.box-body -->

                  <div class="box-footer">
				  	<input type="submit" id="submit" name="Submit" value="Submit" class="btn btn-primary" />
					<input type="reset" id="reset" name="reset" value="Reset" class="btn btn-primary">
                  </div>
                </form>
            </div><!-- /.box-body -->
            
          </div><!-- /.box -->

        </section><!-- /.content -->
      </div><!-- /.content-wrapper -->

        </section><!-- /.content -->
     
      <footer class="main-footer">
         <?php include("../includes/admin-footer.php"); ?>
      </footer>
      
     
      <!-- Add the sidebar's background. This div must be placed
           immediately after the control sidebar -->
      <div class='control-sidebar-bg'></div>
    </div><!-- ./wrapper -->

    <!-- jQuery 2.1.4 -->
    <script src="plugins/jQuery/jQuery-2.1.4.min.js"></script>
    <!-- jQuery UI 1.11.2 -->
    <script src="http://code.jquery.com/ui/1.11.2/jquery-ui.min.js" type="text/javascript"></script>
    <!-- Resolve conflict in jQuery UI tooltip with Bootstrap tooltip -->
    <script>
      $.widget.bridge('uibutton', $.ui.button);
    </script>
    <!-- Bootstrap 3.3.2 JS -->
    <script src="bootstrap/js/bootstrap.min.js" type="text/javascript"></script>    
    <!-- Morris.js charts -->
    <script src="http://cdnjs.cloudflare.com/ajax/libs/raphael/2.1.0/raphael-min.js"></script>
    <script src="plugins/morris/morris.min.js" type="text/javascript"></script>
    <!-- Sparkline -->
    <script src="plugins/sparkline/jquery.sparkline.min.js" type="text/javascript"></script>
    <!-- jvectormap -->
    <script src="plugins/jvectormap/jquery-jvectormap-1.2.2.min.js" type="text/javascript"></script>
    <script src="plugins/jvectormap/jquery-jvectormap-world-mill-en.js" type="text/javascript"></script>
    <!-- jQuery Knob Chart -->
    <script src="plugins/knob/jquery.knob.js" type="text/javascript"></script>
    <!-- daterangepicker -->
    <script src="https://cdnjs.cloudflare.com/ajax/libs/moment.js/2.10.2/moment.min.js" type="text/javascript"></script>
    <script src="plugins/daterangepicker/daterangepicker.js" type="text/javascript"></script>
    <!-- datepicker -->
    <script src="plugins/datepicker/bootstrap-datepicker.js" type="text/javascript"></script>
    <!-- Bootstrap WYSIHTML5 -->
    <script src="plugins/bootstrap-wysihtml5/bootstrap3-wysihtml5.all.min.js" type="text/javascript"></script>
    <!-- Slimscroll -->
    <script src="plugins/slimScroll/jquery.slimscroll.min.js" type="text/javascript"></script>
    <!-- FastClick -->
    <script src='plugins/fastclick/fastclick.min.js'></script>
    <!-- AdminLTE App -->
    <script src="dist/js/app.min.js" type="text/javascript"></script>    
    
    <!-- AdminLTE dashboard demo (This is only for demo purposes) -->
    <script src="dist/js/pages/dashboard.js" type="text/javascript"></script>    
  
  </body>
</html>