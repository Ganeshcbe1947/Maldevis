<?PHP
	include("../includes/config.php");
	include("thumbnail.php");
	//if($_SESSION[$loginid] == "") { header("location: login.php?access=denied");  }

	$pagename = "Jobs";
        
        $jobs_name = $_POST['jobs_name'];
        $category_id = $_POST['category_id'];	
	$jobs_employeers = $_POST['jobs_employeers'];
	$jobs_email = $_POST['jobs_email'];
	$jobs_location = $_POST['jobs_location'];
	$jobs_type_id = $_POST['jobs_type_id'];
	$jobs_experience = $_POST['jobs_experience'];
	$jobs_description = $_POST['jobs_description'];
	$jobs_pdf = $_POST['jobs_pdf'];
	$jobs_salary = $_POST['jobs_salary'];
	$jobs_status = $_POST['jobs_status'];

	
	if(isset($_POST['submit'])) {
	
		if($_GET['id'] == "" ) 
		{ $query = "insert into fn_jobs (jobs_name,category_id,jobs_employeers,jobs_email,jobs_location,jobs_type_id,jobs_experience,jobs_description,jobs_salary,jobs_status,createdatetime) "
                        . "values('$jobs_name','$category_id','$jobs_employeers','$jobs_email','$jobs_location','$jobs_type_id','$jobs_experience','$jobs_description','$jobs_salary','$jobs_status', current_timestamp())";	
		} else {
		$query = "update fn_jobs set jobs_name = '$jobs_name',category_id = '$category_id',jobs_employeers = '$jobs_employeers',jobs_email = '$jobs_email',jobs_location = '$jobs_location',"
                        . "jobs_type_id = '$jobs_type_id',jobs_experience = '$jobs_experience',jobs_description = '$jobs_description',jobs_salary = '$jobs_salary',jobs_status = '$jobs_status', updatedatetime = current_timestamp() where jobs_id = $_GET[id]";
		}
			//echo $query; exit;
                        $result = mysqli_query($db_connection,$query);	
                        if ($result == true) {
                            $jobsimagedirectory = "../images/jobs";
                            if(is_dir($jobsimagedirectory) == false){ mkdir($jobsimagedirectory, 0777, true); }
			$filename = $_FILES['jobs_pdf']['name'];
			if ($filename != "") {
				if ($_GET['id'] == "") {
					$jobs_query = "select max(jobs_id) from fn_jobs";
					$jobs_equery = mysqli_query($db_connection,$jobs_query);
					$fetchrow = mysqli_fetch_row($jobs_equery);
					$jobs_id = $fetchrow[0];
				}

				else { $jobs_id = $_GET['id']; }


				$fileextension = substr($filename, strlen($filename)-4, 4);
				$jobsimagepath = $jobsimagedirectory."/jobs_".$jobs_id.$fileextension;
				if (move_uploaded_file($_FILES['jobs_pdf']['tmp_name'], $jobsimagepath)){
					chmod($jobsimagepath,0777);	

					$jobsimagepath = str_replace("../", "", $jobsimagepath);					

					$query = "update fn_jobs set jobs_pdf = '".$jobsimagepath."' where (jobs_id = ".$jobs_id.")";			
					$result = mysqli_query($db_connection,$query) or die(mysqli_error());
				
				}
			}
			}
                        header("location:jobs-view.php");
		}
?>
<!DOCTYPE html>
<html>
  <head>
    <meta charset="UTF-8">
    <title><?PHP echo $projecttitle." :: ".$pagename; ?></title>
    <meta content='width=device-width, initial-scale=1, maximum-scale=1, user-scalable=no' name='viewport'>
    <!-- Bootstrap 3.3.4 -->
    <link href="bootstrap/css/bootstrap.min.css" rel="stylesheet" type="text/css" />    
    <!-- FontAwesome 4.3.0 -->
    <link href="https://maxcdn.bootstrapcdn.com/font-awesome/4.3.0/css/font-awesome.min.css" rel="stylesheet" type="text/css" />
    <!-- Ionicons 2.0.0 -->
    <link href="https://code.ionicframework.com/ionicons/2.0.1/css/ionicons.min.css" rel="stylesheet" type="text/css" />    
    <!-- Theme style -->
    <link href="dist/css/AdminLTE.min.css" rel="stylesheet" type="text/css" />
    <!-- AdminLTE Skins. Choose a skin from the css/skins 
         folder instead of downloading all of them to reduce the load. -->
    <link href="dist/css/skins/_all-skins.min.css" rel="stylesheet" type="text/css" />
    <!-- iCheck -->
    <link href="plugins/iCheck/flat/blue.css" rel="stylesheet" type="text/css" />
    <!-- Morris chart -->
    <link href="plugins/morris/morris.css" rel="stylesheet" type="text/css" />
    <!-- jvectormap -->
    <link href="plugins/jvectormap/jquery-jvectormap-1.2.2.css" rel="stylesheet" type="text/css" />
    <!-- Date Picker -->
    <link href="plugins/datepicker/datepicker3.css" rel="stylesheet" type="text/css" />
    <!-- Daterange picker -->
    <link href="plugins/daterangepicker/daterangepicker-bs3.css" rel="stylesheet" type="text/css" />
    <!-- bootstrap wysihtml5 - text editor -->
    <link href="plugins/bootstrap-wysihtml5/bootstrap3-wysihtml5.min.css" rel="stylesheet" type="text/css" />
    <script src="plugins/nicEdit/nicEdit.js" type="text/javascript"></script>
<script type="text/javascript">
bkLib.onDomLoaded(function() {
	new nicEditor().panelInstance('area1');
	new nicEditor({fullPanel : true}).panelInstance('area2');
	new nicEditor({iconsPath : 'plugins/nicEdit//nicEditorIcons.gif'}).panelInstance('area3');
	new nicEditor({buttonList : ['fontSize','bold','italic','underline','strikeThrough','subscript','superscript','html','image']}).panelInstance('area4');
	new nicEditor({maxHeight : 100}).panelInstance('area5');
});
</script>
    
 
  </head>
  <body class="skin-blue sidebar-mini">
    <div class="wrapper">
      <?php include("../includes/admin-header.php"); ?>
     
      <!-- Left side column. contains the logo and sidebar -->
      <aside class="main-sidebar">
        <!-- sidebar: style can be found in sidebar.less -->
       <?php include("pages/sidebar.php"); ?>
        <!-- /.sidebar -->
      </aside>

      <!-- Content Wrapper. Contains page content -->
      <div class="content-wrapper">
        <!-- Content Header (Page header) -->
	  <?php
			
			if($_GET['id'] != "") {
			$query = "select jobs_id,jobs_name,category_id,jobs_employeers,jobs_email,jobs_location,jobs_type_id,jobs_experience,jobs_description,jobs_pdf,jobs_salary,jobs_status from  fn_jobs where jobs_id ='$_GET[id]'";
			$equery = mysqli_query($db_connection,$query);			
			while($fet_jobs = mysqli_fetch_array($equery)) {			
			$jobs_id = $fet_jobs[0];
                        $jobs_name = $fet_jobs[1];
			$category_id = $fet_jobs[2];			
			$jobs_employeers = $fet_jobs[3];
			$jobs_email = $fet_jobs[4];
			$jobs_location = $fet_jobs[5];
			$jobs_type_id = $fet_jobs[6];
			$jobs_experience = $fet_jobs[7];
			$jobs_description = $fet_jobs[8];
			$jobs_pdf = "../".$fet_jobs[9];
			$jobs_salary = $fet_jobs[10];
			$jobs_status = $fet_jobs[11];
			}
			
			}
			
			
			?>
	 <section class="content-header">
      <?php if($_GET['id'] != "") { ?>
	  <h1>Edit <?php echo $pagename; ?></h1>
	  <?php } else { ?>
	  <h1>Add <?php echo $pagename; ?></h1>
	  <?php } ?>
      <ol class="breadcrumb">
        <li><a href="#"><i class="fa fa-dashboard"></i> Home</a></li>
        <li class="active">Dashboard</li>
      </ol>
    </section>
       <section class="content">
      <div class="row">
        <!-- left column -->
        <div class="col-md-8">
          <!-- general form elements -->
          <div class="box box-primary">
           <!-- /.box-header -->
            <!-- form start -->
		   
		    <form id="FormHome" name="FormName" action="<?PHP $PHP_SELF ?>" method="post" enctype="multipart/form-data" >
			
             <div class="form-group">
                  <label>Name</label>
                  <input type="text" class="form-control" name="jobs_name" placeholder="Enter name" value="<?php echo $jobs_name; ?>" >
              </div>
                        <div class="form-group">
                <label>Category</label>
				<select id="category_id" name="category_id" class="form-control">
					<option value="" selected="selected">--- Select ---</option>
					<?php
					$query = "select category_id,category_name from fn_category where category_status = '1' order by category_id asc";
					$equery = mysqli_query($db_connection,$query);
                                         while($fetcharray = mysqli_fetch_array($equery)) {
					if($category_id == $fetcharray[0]) {
					echo "<option value='".$fetcharray[0]."' selected='selected'>".$fetcharray[1]."</option>";
					}
					else {
					echo "<option value='".$fetcharray[0]."'>".$fetcharray[1]."</option>";
					}
					}
					?>
				</select>
              </div>
              <div class="form-group">
                  <label>Employeers</label>
                  <select id="jobs_employeers" name="jobs_employeers" class="form-control">
					<option value="" selected="selected">--- Select ---</option>
					<?php
					$employeers_query = "select employeers_id,employeers_name from fn_employeers where employeers_status = '1' order by employeers_id asc";
					$employeers_equery = mysqli_query($db_connection,$employeers_query);
                                         while($employeers_fetcharray = mysqli_fetch_array($employeers_equery)) {
					if($jobs_employeers == $employeers_fetcharray[0]) {
					echo "<option value='".$employeers_fetcharray[0]."' selected='selected'>".$employeers_fetcharray[1]."</option>";
					}
					else {
					echo "<option value='".$employeers_fetcharray[0]."'>".$employeers_fetcharray[1]."</option>";
					}
					}
					?>
                </select>
              </div>
              <div class="form-group">
                  <label>Email</label>
                  <input type="text" class="form-control" name="jobs_email" placeholder="Enter email" value="<?php echo $jobs_email; ?>" >
              </div>
              <div class="form-group">
                  <label>Location</label>
                  <input type="text" class="form-control" name="jobs_location" placeholder="Enter location" value="<?php echo $jobs_location; ?>" >
              </div>
              <div class="form-group">
                <label>Job Type</label>
				<select id="job_type_id" name="jobs_type_id" class="form-control">
					<option value="" selected="selected">--- Select ---</option>
					<?php
					$type_query = "select jobs_type_id,jobs_type_name from fn_jobs_type where jobs_type_status = '1' order by jobs_type_id asc";
					$type_equery = mysqli_query($db_connection,$type_query);
                                         while($type_fetcharray = mysqli_fetch_array($type_equery)) {
					if($jobs_type_id == $type_fetcharray[0]) {
					echo "<option value='".$type_fetcharray[0]."' selected='selected'>".$type_fetcharray[1]."</option>";
					}
					else {
					echo "<option value='".$type_fetcharray[0]."'>".$type_fetcharray[1]."</option>";
					}
					}
					?>
				</select>
              </div>
              <div class="form-group">
                  <label>Experience</label>
                  <input type="text" class="form-control" name="jobs_experience" placeholder="Enter experience" value="<?php echo $jobs_experience; ?>" >
              </div>
              <div class="form-group">
                  <label>Descripition</label>
				  <textarea id="area1" name="jobs_description" rows="10" cols="80"><?php echo $jobs_description; ?></textarea>
                </div> 
             <div class="form-group">
                  <label>Pdf</label>
                    <?php if($_GET['id'] != "") { ?>
                    <input type="file" id="exampleInputFile" name="jobs_pdf" value="<?php echo $jobs_pdf; ?>"  >
                    <a href="<?php echo $jobs_pdf; ?>" target="_blank">Download Pdf<a>
                    <?php } else { ?>
                     <input type="file" id="exampleInputFile" name="jobs_pdf" >	
                         <?php } ?>
              </div>
              <div class="form-group">
                  <label>Salary</label>
                  <input type="text" class="form-control" name="jobs_salary" placeholder="Enter salary" value="<?php echo $jobs_salary; ?>" >
              </div>
              <div class="form-group">
                  <label>Status</label>
                  <select id="jobs_status" name="jobs_status" class="form-control">
                        <option value="" selected="selected">--- Select ---</option>
                        <option value="1" <?php if($jobs_status == 1) { echo 'selected=selected'; } ?>>Active</option>
                        <option value="0" <?php if($jobs_status == 0) { echo 'selected=selected'; } ?>>InActive</option>
                </select>
              </div>
			  
			  <div class="box-footer">
       			<input type="submit" id="submit" name="submit" value="Submit" class="btn btn-primary" />
              </div>
            </form>
          </div>
          <!-- /.box -->
        </div>
        <!--/.col (left) -->
     
      </div>
      <!-- /.row -->
    </section>
      </div><!-- /.content-wrapper -->

        </section><!-- /.content -->
     
      <footer class="main-footer">
         <?php include("../includes/admin-footer.php"); ?>
      </footer>
      
     
      <!-- Add the sidebar's background. This div must be placed
           immediately after the control sidebar -->
      <div class='control-sidebar-bg'></div>
    </div><!-- ./wrapper -->

    <script src="plugins/jQuery/jQuery-2.1.4.min.js"></script>
    <!-- Bootstrap 3.3.2 JS -->
    <script src="bootstrap/js/bootstrap.min.js" type="text/javascript"></script>
    <!-- FastClick -->
    <script src='plugins/fastclick/fastclick.min.js'></script>
    <!-- AdminLTE App -->
    <script src="dist/js/app.min.js" type="text/javascript"></script>
    <!-- AdminLTE for demo purposes -->
    <script src="dist/js/demo.js" type="text/javascript"></script>
   
   
  
  </body>
</html>