<?PHP
	include("../includes/config.php");
	include("thumbnail.php");
	//if($_SESSION[$loginid] == "") { header("location: login.php?access=denied");  }

	$pagename = "Category";
        
        $country_id = $_POST['country_id'];
        $category_name = $_POST['category_name'];
	$category_icon = $_POST['category_icon'];	
	$category_status = $_POST['category_status'];	

	if(isset($_POST['submit'])) {
	
		if($_GET['id'] == "" ) 
		{ $query = "insert into fn_category (category_name,category_icon,category_status,createdatetime) "
                        . "values('$category_name','$category_icon','$category_status', current_timestamp())";	
		} else {
		$query = "update fn_category set category_name = '$category_name',category_icon = '$category_icon',category_status = '$category_status', updatedatetime = current_timestamp() where category_id = $_GET[id]";
		}
			//echo $query; exit;
			$result = mysqli_query($db_connection,$query);	
			header("location:category-view.php");

		}
?>
<!DOCTYPE html>
<html>
  <head>
    <meta charset="UTF-8">
    <title><?PHP echo $projecttitle." :: ".$pagename; ?></title>
    <meta content='width=device-width, initial-scale=1, maximum-scale=1, user-scalable=no' name='viewport'>
    <!-- Bootstrap 3.3.4 -->
    <link href="bootstrap/css/bootstrap.min.css" rel="stylesheet" type="text/css" />    
    <!-- FontAwesome 4.3.0 -->
    <link href="https://maxcdn.bootstrapcdn.com/font-awesome/4.3.0/css/font-awesome.min.css" rel="stylesheet" type="text/css" />
    <!-- Ionicons 2.0.0 -->
    <link href="https://code.ionicframework.com/ionicons/2.0.1/css/ionicons.min.css" rel="stylesheet" type="text/css" />    
    <!-- Theme style -->
    <link href="dist/css/AdminLTE.min.css" rel="stylesheet" type="text/css" />
    <!-- AdminLTE Skins. Choose a skin from the css/skins 
         folder instead of downloading all of them to reduce the load. -->
    <link href="dist/css/skins/_all-skins.min.css" rel="stylesheet" type="text/css" />
    <!-- iCheck -->
    <link href="plugins/iCheck/flat/blue.css" rel="stylesheet" type="text/css" />
    <!-- Morris chart -->
    <link href="plugins/morris/morris.css" rel="stylesheet" type="text/css" />
    <!-- jvectormap -->
    <link href="plugins/jvectormap/jquery-jvectormap-1.2.2.css" rel="stylesheet" type="text/css" />
    <!-- Date Picker -->
    <link href="plugins/datepicker/datepicker3.css" rel="stylesheet" type="text/css" />
    <!-- Daterange picker -->
    <link href="plugins/daterangepicker/daterangepicker-bs3.css" rel="stylesheet" type="text/css" />
    <!-- bootstrap wysihtml5 - text editor -->
    <link href="plugins/bootstrap-wysihtml5/bootstrap3-wysihtml5.min.css" rel="stylesheet" type="text/css" />
    <script src="plugins/nicEdit/nicEdit.js" type="text/javascript"></script>
<script type="text/javascript">
bkLib.onDomLoaded(function() {
	new nicEditor().panelInstance('area1');
	new nicEditor({fullPanel : true}).panelInstance('area2');
	new nicEditor({iconsPath : 'plugins/nicEdit//nicEditorIcons.gif'}).panelInstance('area3');
	new nicEditor({buttonList : ['fontSize','bold','italic','underline','strikeThrough','subscript','superscript','html','image']}).panelInstance('area4');
	new nicEditor({maxHeight : 100}).panelInstance('area5');
});
</script>
 
  </head>
  <body class="skin-blue sidebar-mini">
    <div class="wrapper">
      <?php include("../includes/admin-header.php"); ?>
     
      <!-- Left side column. contains the logo and sidebar -->
      <aside class="main-sidebar">
        <!-- sidebar: style can be found in sidebar.less -->
       <?php include("pages/sidebar.php"); ?>
        <!-- /.sidebar -->
      </aside>

      <!-- Content Wrapper. Contains page content -->
      <div class="content-wrapper">
        <!-- Content Header (Page header) -->
	  <?php
			
			if($_GET['id'] != "") {
			$query = "select category_id,category_name,category_icon,category_status from  fn_category where category_id ='$_GET[id]'";
			$equery = mysqli_query($db_connection,$query);			
			while($fet_category = mysqli_fetch_array($equery)) {			
			$category_id = $fet_category[0];
			$category_name = $fet_category[1];
			$category_icon = $fet_category[2];		
			$category_status = $fet_category[3];		
			}
			
			}
			
			
			?>
	 <section class="content-header">
      <?php if($_GET['id'] != "") { ?>
	  <h1>Edit <?php echo $pagename; ?></h1>
	  <?php } else { ?>
	  <h1>Add <?php echo $pagename; ?></h1>
	  <?php } ?>
      <ol class="breadcrumb">
        <li><a href="#"><i class="fa fa-dashboard"></i> Home</a></li>
        <li class="active">Dashboard</li>
      </ol>
    </section>
       <section class="content">
      <div class="row">
        <!-- left column -->
        <div class="col-md-8">
          <!-- general form elements -->
          <div class="box box-primary">
           <!-- /.box-header -->
            <!-- form start -->
		   
		    <form id="FormHome" name="FormName" action="<?PHP $PHP_SELF ?>" method="post" enctype="multipart/form-data" >
			
             <div class="form-group">
                  <label>Name</label>
                  <input type="text" class="form-control" name="category_name" placeholder="Enter name" value="<?php echo $category_name; ?>" >
              </div>                        
             <div class="form-group">
                  <label>Icon Name</label>
                  <input type="text" class="form-control" name="category_icon" placeholder="Enter icon name" value="<?php echo $category_icon; ?>" >
              </div> 
            <div class="form-group">
                  <label>Status</label>
                  <select id="jobs_status" name="category_status" class="form-control">
                        <option value="" selected="selected">--- Select ---</option>
                        <option value="1" <?php if($category_status == 1) { echo 'selected=selected'; } ?>>Active</option>
                        <option value="0" <?php if($category_status == 0) { echo 'selected=selected'; } ?>>InActive</option>
                </select>
              </div>
            			 
			  <div class="box-footer">
       			<input type="submit" id="submit" name="submit" value="Submit" class="btn btn-primary" />
              </div>
            </form>
          </div>
          <!-- /.box -->
        </div>
        <!--/.col (left) -->
     
      </div>
      <!-- /.row -->
    </section>
      </div><!-- /.content-wrapper -->

        </section><!-- /.content -->
     
      <footer class="main-footer">
         <?php include("../includes/admin-footer.php"); ?>
      </footer>
      
     
      <!-- Add the sidebar's background. This div must be placed
           immediately after the control sidebar -->
      <div class='control-sidebar-bg'></div>
    </div><!-- ./wrapper -->

    <script src="plugins/jQuery/jQuery-2.1.4.min.js"></script>
    <!-- Bootstrap 3.3.2 JS -->
    <script src="bootstrap/js/bootstrap.min.js" type="text/javascript"></script>
    <!-- FastClick -->
    <script src='plugins/fastclick/fastclick.min.js'></script>
    <!-- AdminLTE App -->
    <script src="dist/js/app.min.js" type="text/javascript"></script>
    <!-- AdminLTE for demo purposes -->
    <script src="dist/js/demo.js" type="text/javascript"></script>
   
  
  </body>
</html>