<?PHP

	include("../includes/config.php");

	//if($_SESSION[$loginid] == "") { header("location: pages/login.php?access=denied");  }

	$pagename = "Contact Information";

	

	if (isset($_POST['submit']) == true) {

		$company_name = $_POST['company_name'];
		$company_firstname = $_POST['company_firstname'];
		$company_lastname = $_POST['company_lastname'];
		$company_addr = $_POST['company_addr'];
		$company_pincode = $_POST['company_pincode'];
		$company_contact = $_POST['company_contact'];
		$company_mobile = $_POST['company_mobile'];
		$company_email = $_POST['company_email'];
		$company_facebook = $_POST['company_facebook'];
		$company_twitter = $_POST['company_twitter'];
		$company_youtube = $_POST['company_youtube'];
		$company_status = '1';
		
		$query = "update company_information set company_name = '$company_name', company_firstname = '$company_firstname', company_lastname = '$company_lastname', company_addr = '$company_addr', company_pincode = '$company_pincode', company_contact = '$company_contact', company_mobile = '$company_mobile',company_email = '$company_email', company_facebook = '$company_facebook', company_twitter = '$company_twitter', company_youtube = '$company_youtube', company_status = '$company_status', updatedatetime = current_timestamp() where company_status = '1'";

			$result = mysqli_query($db_connection,$query) or die($message = "<span class='errormessage'>".mysqli_error()."</span>");

			if ($result == true) {

				$message = "<span style='color:red'>Updated successfully</span>";			

		}

		

	}

?>
<!DOCTYPE html>
<html>
  <head>
    <meta charset="UTF-8">
    <title><?php echo $projecttitle." : ".$pagename; ?></title>
    <meta content='width=device-width, initial-scale=1, maximum-scale=1, user-scalable=no' name='viewport'>
    <!-- Bootstrap 3.3.4 -->
    <link href="bootstrap/css/bootstrap.min.css" rel="stylesheet" type="text/css" />    
    <!-- FontAwesome 4.3.0 -->
    <link href="https://maxcdn.bootstrapcdn.com/font-awesome/4.3.0/css/font-awesome.min.css" rel="stylesheet" type="text/css" />
    <!-- Ionicons 2.0.0 -->
    <link href="https://code.ionicframework.com/ionicons/2.0.1/css/ionicons.min.css" rel="stylesheet" type="text/css" />    
    <!-- Theme style -->
    <link href="dist/css/AdminLTE.min.css" rel="stylesheet" type="text/css" />
    <!-- AdminLTE Skins. Choose a skin from the css/skins 
         folder instead of downloading all of them to reduce the load. -->
    <link href="dist/css/skins/_all-skins.min.css" rel="stylesheet" type="text/css" />
    <!-- iCheck -->
    <link href="plugins/iCheck/flat/blue.css" rel="stylesheet" type="text/css" />
    <!-- Morris chart -->
    <link href="plugins/morris/morris.css" rel="stylesheet" type="text/css" />
    <!-- jvectormap -->
    <link href="plugins/jvectormap/jquery-jvectormap-1.2.2.css" rel="stylesheet" type="text/css" />
    <!-- Date Picker -->
    <link href="plugins/datepicker/datepicker3.css" rel="stylesheet" type="text/css" />
    <!-- Daterange picker -->
    <link href="plugins/daterangepicker/daterangepicker-bs3.css" rel="stylesheet" type="text/css" />
    <!-- bootstrap wysihtml5 - text editor -->
    <link href="plugins/bootstrap-wysihtml5/bootstrap3-wysihtml5.min.css" rel="stylesheet" type="text/css" />
    <script src="plugins/nicEdit/nicEdit.js" type="text/javascript"></script>
<script type="text/javascript">
bkLib.onDomLoaded(function() {
	new nicEditor().panelInstance('area1');
	new nicEditor({fullPanel : true}).panelInstance('area2');
	new nicEditor({iconsPath : 'plugins/nicEdit//nicEditorIcons.gif'}).panelInstance('area3');
	new nicEditor({buttonList : ['fontSize','bold','italic','underline','strikeThrough','subscript','superscript','html','image']}).panelInstance('area4');
	new nicEditor({maxHeight : 100}).panelInstance('area5');
});
</script>
  </head>
  <body class="skin-blue sidebar-mini">
    <div class="wrapper">
      <?php include("../includes/admin-header.php"); ?>
     
      <!-- Left side column. contains the logo and sidebar -->
      <aside class="main-sidebar">
        <!-- sidebar: style can be found in sidebar.less -->
       <?php include("pages/sidebar.php"); ?>
        <!-- /.sidebar -->
      </aside>

      <!-- Content Wrapper. Contains page content -->
      <div class="content-wrapper">
        <!-- Content Header (Page header) -->
        <section class="content-header">
          <h1><?php echo $pagename; ?></h1>
          <ol class="breadcrumb">
            <li><a href="index.php"><i class="fa fa-dashboard"></i> Home</a></li>
            <li class="active"><?php echo $pagename; ?></li>
          </ol>
        </section>

        <!-- Main content -->
        <section class="content">

          <!-- Default box -->
          <div class="box">
            <div class="box-body">
			<?php if ($message != "") { echo "<tr><td colspan='2' style='color:red'>".$message."</td></tr>"; } ?>
			<?php
			
			$query = "select company_id,company_name,company_firstname,company_lastname,company_addr,company_pincode,company_contact,company_mobile,company_email,company_status,createdatetime,updatedatetime from company_information where company_id ='1'";	
			$equery = mysqli_query($db_connection,$query);			
			$fetchrow = mysqli_fetch_array($equery);	
			$company_name = $fetchrow[1];
			$company_firstname = $fetchrow[2];
			$company_lastname = $fetchrow[3];
			$company_addr = $fetchrow[4];		
			$company_pincode = $fetchrow[5];	
			$company_contact = $fetchrow[6];
			$company_mobile = $fetchrow[7];	
			$company_email = $fetchrow[8];	
			$company_status = $fetchrow[9];	
			
			
			?>
              <form id="FormWelcome" name="FormWelcome" action="<?php $PHP_SELF ?>" method="post">			  
                  <div class="box-body">
                    <div class="form-group">
                      <label for="exampleInputEmail1">Contact Name </label>
                      <input type="text" class="form-control" placeholder="Contact Name" name="company_name" value="<?php echo $company_name; ?>">
                    </div>
					<div class="form-group">
                      <label for="exampleInputEmail1">First Name </label>
                      <input type="text" class="form-control" placeholder="First Name" name="company_firstname" value="<?php echo $company_firstname; ?>">
                    </div>
					<div class="form-group">
                      <label for="exampleInputEmail1">Last Name </label>
                      <input type="text" class="form-control" placeholder="Last Name" name="company_lastname" value="<?php echo $company_lastname; ?>">
                    </div>
                    <div class="form-group">
                      <label for="exampleInputEmail1">Address</label>
                      <input type="text" class="form-control" placeholder="Address" name="company_addr" value="<?php echo $company_addr; ?>">
                    </div>
                    <div class="form-group">
                      <label for="exampleInputEmail1">Pincode</label>
                      <input type="text" class="form-control" placeholder="Pincode" name="company_pincode" value="<?php echo $company_pincode; ?>">
                    </div>
                    <div class="form-group">
                      <label for="exampleInputEmail1">Contact</label>
                      <input type="text" class="form-control" placeholder="State" name="company_contact" value="<?php echo $company_contact; ?>">
                    </div>
                    <div class="form-group">
                      <label for="exampleInputEmail1">Mobile</label>
                      <input type="text" class="form-control" placeholder="Country" name="company_mobile" value="<?php echo $company_mobile; ?>">
                    </div>
                    <div class="form-group">
                      <label for="exampleInputtext1">Email </label>
                      <input type="text" class="form-control" id="exampleInputtext1" placeholder="Email" name="company_email" value="<?php echo $company_email; ?>">
                    </div>
                    <div class="form-group">
                      <label for="exampleInputtext1">Facebook </label>
                      <input type="text" class="form-control" id="exampleInputtext1" placeholder="Facebook" name="company_facebook" value="<?php echo $company_facebook; ?>">
                    </div>
                    <div class="form-group">
                      <label for="exampleInputtext1">Instagram </label>
                      <input type="text" class="form-control" id="exampleInputtext1" placeholder="Instagram" name="company_twitter" value="<?php echo $company_twitter; ?>">
                    </div>
                    <div class="form-group">
                      <label for="exampleInputtext1">Youtube </label>
                      <input type="text" class="form-control" id="exampleInputtext1" placeholder="Youtube" name="company_youtube" value="<?php echo $company_youtube; ?>">
                    </div>
                    
                  </div><!-- /.box-body -->

                  <div class="box-footer">
				  	<input type="submit" id="submit" name="submit" value="Submit" class="btn btn-primary" />
					<input type="reset" id="reset" name="reset" value="Reset" class="btn btn-primary">
                  </div>
                </form>
            </div><!-- /.box-body -->
            
          </div><!-- /.box -->

        </section><!-- /.content -->
      </div><!-- /.content-wrapper -->

        </section><!-- /.content -->
     
      <footer class="main-footer">
         <?php include("../includes/admin-footer.php"); ?>
      </footer>
      
     
      <!-- Add the sidebar's background. This div must be placed
           immediately after the control sidebar -->
      <div class='control-sidebar-bg'></div>
    </div><!-- ./wrapper -->

    <!-- jQuery 2.1.4 -->
    <script src="plugins/jQuery/jQuery-2.1.4.min.js"></script>
    <!-- jQuery UI 1.11.2 -->
    <script src="http://code.jquery.com/ui/1.11.2/jquery-ui.min.js" type="text/javascript"></script>
    <!-- Resolve conflict in jQuery UI tooltip with Bootstrap tooltip -->
    <script>
      $.widget.bridge('uibutton', $.ui.button);
    </script>
    <!-- Bootstrap 3.3.2 JS -->
    <script src="bootstrap/js/bootstrap.min.js" type="text/javascript"></script>    
    <!-- Morris.js charts -->
    <script src="http://cdnjs.cloudflare.com/ajax/libs/raphael/2.1.0/raphael-min.js"></script>
    <script src="plugins/morris/morris.min.js" type="text/javascript"></script>
    <!-- Sparkline -->
    <script src="plugins/sparkline/jquery.sparkline.min.js" type="text/javascript"></script>
    <!-- jvectormap -->
    <script src="plugins/jvectormap/jquery-jvectormap-1.2.2.min.js" type="text/javascript"></script>
    <script src="plugins/jvectormap/jquery-jvectormap-world-mill-en.js" type="text/javascript"></script>
    <!-- jQuery Knob Chart -->
    <script src="plugins/knob/jquery.knob.js" type="text/javascript"></script>
    <!-- daterangepicker -->
    <script src="https://cdnjs.cloudflare.com/ajax/libs/moment.js/2.10.2/moment.min.js" type="text/javascript"></script>
    <script src="plugins/daterangepicker/daterangepicker.js" type="text/javascript"></script>
    <!-- datepicker -->
    <script src="plugins/datepicker/bootstrap-datepicker.js" type="text/javascript"></script>
    <!-- Bootstrap WYSIHTML5 -->
    <script src="plugins/bootstrap-wysihtml5/bootstrap3-wysihtml5.all.min.js" type="text/javascript"></script>
    <!-- Slimscroll -->
    <script src="plugins/slimScroll/jquery.slimscroll.min.js" type="text/javascript"></script>
    <!-- FastClick -->
    <script src='plugins/fastclick/fastclick.min.js'></script>
    <!-- AdminLTE App -->
    <script src="dist/js/app.min.js" type="text/javascript"></script>    
    
    <!-- AdminLTE dashboard demo (This is only for demo purposes) -->
    <script src="dist/js/pages/dashboard.js" type="text/javascript"></script>    
  
  </body>
</html>