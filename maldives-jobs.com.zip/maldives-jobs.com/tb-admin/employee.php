<?PHP
	include("../includes/config.php");
	include("thumbnail.php");
	//if($_SESSION[$loginid] == "") { header("location: login.php?access=denied");  }

	$pagename = "Employee";
        
        $employee_name = $_POST['employee_name'];
        $employee_email = $_POST['employee_email'];
        $employee_contact = $_POST['employee_contact'];
        $employee_address = $_POST['employee_address'];
        $employee_pincode = $_POST['employee_pincode'];
        $employee_photo = $_POST['employee_photo'];	
        $employee_status = $_POST['employee_status'];	

	$employeeimagedirectory = "../images/employee";
	if(is_dir($employeeimagedirectory) == false){ mkdir($employeeimagedirectory, 0777, true); }

	
	if(isset($_POST['submit'])) {
	
		if($_GET['id'] == "" ) 
		{ $query = "insert into fn_employee (employee_name,employee_email,employee_contact,employee_address,employee_pincode,employee_status,createdatetime) "
                        . "values('$employee_name','$employee_email','$employee_contact','$employee_address','$employee_pincode','$employee_status', current_timestamp())";	
		} else {
		$query = "update fn_employee set employee_name = '$employee_name',employee_email = '$employee_email',employee_contact = '$employee_contact',employee_address = '$employee_address',employee_pincode = '$employee_pincode', employee_status = '$employee_status', updatedatetime = current_timestamp() where employee_id = $_GET[id]";
		}
			//echo $query; exit;
			$result = mysqli_query($db_connection,$query);	
			if ($result == true) {
			$filename = $_FILES['employee_photo']['name'];
			if ($filename != "") {
				if ($_GET['id'] == "") {
					$query = "select max(employee_id) from fn_employee";
					$equery = mysqli_query($db_connection,$query);
					$fetchrow = mysqli_fetch_row($equery);
					$employee_id = $fetchrow[0];
				}

				else { $employee_id = $_GET['id']; }


				$fileextension = substr($filename, strlen($filename)-4, 4);
				$employeeimagepath = $employeeimagedirectory."/employee_".$employee_id.$fileextension;
				if (move_uploaded_file($_FILES['employee_photo']['tmp_name'], $employeeimagepath)){
					chmod($employeeimagepath,0777);	

					$employeeimagepath = str_replace("../", "", $employeeimagepath);					

					$query = "update fn_employee set employee_photo = '".$employeeimagepath."' where (employee_id = ".$employee_id.")";			
					$result = mysqli_query($db_connection,$query) or die(mysqli_error());
				
				}
			}
			}
                       header("location:employee-view.php");

		}
?>
<!DOCTYPE html>
<html>
  <head>
    <meta charset="UTF-8">
    <title><?PHP echo $projecttitle." :: ".$pagename; ?></title>
    <meta content='width=device-width, initial-scale=1, maximum-scale=1, user-scalable=no' name='viewport'>
    <!-- Bootstrap 3.3.4 -->
    <link href="bootstrap/css/bootstrap.min.css" rel="stylesheet" type="text/css" />    
    <!-- FontAwesome 4.3.0 -->
    <link href="https://maxcdn.bootstrapcdn.com/font-awesome/4.3.0/css/font-awesome.min.css" rel="stylesheet" type="text/css" />
    <!-- Ionicons 2.0.0 -->
    <link href="https://code.ionicframework.com/ionicons/2.0.1/css/ionicons.min.css" rel="stylesheet" type="text/css" />    
    <!-- Theme style -->
    <link href="dist/css/AdminLTE.min.css" rel="stylesheet" type="text/css" />
    <!-- AdminLTE Skins. Choose a skin from the css/skins 
         folder instead of downloading all of them to reduce the load. -->
    <link href="dist/css/skins/_all-skins.min.css" rel="stylesheet" type="text/css" />
    <!-- iCheck -->
    <link href="plugins/iCheck/flat/blue.css" rel="stylesheet" type="text/css" />
    <!-- Morris chart -->
    <link href="plugins/morris/morris.css" rel="stylesheet" type="text/css" />
    <!-- jvectormap -->
    <link href="plugins/jvectormap/jquery-jvectormap-1.2.2.css" rel="stylesheet" type="text/css" />
    <!-- Date Picker -->
    <link href="plugins/datepicker/datepicker3.css" rel="stylesheet" type="text/css" />
    <!-- Daterange picker -->
    <link href="plugins/daterangepicker/daterangepicker-bs3.css" rel="stylesheet" type="text/css" />
    <!-- bootstrap wysihtml5 - text editor -->
    <link href="plugins/bootstrap-wysihtml5/bootstrap3-wysihtml5.min.css" rel="stylesheet" type="text/css" />
    <script src="plugins/nicEdit/nicEdit.js" type="text/javascript"></script>
<script type="text/javascript">
bkLib.onDomLoaded(function() {
	new nicEditor().panelInstance('area1');
	new nicEditor({fullPanel : true}).panelInstance('area2');
	new nicEditor({iconsPath : 'plugins/nicEdit//nicEditorIcons.gif'}).panelInstance('area3');
	new nicEditor({buttonList : ['fontSize','bold','italic','underline','strikeThrough','subscript','superscript','html','image']}).panelInstance('area4');
	new nicEditor({maxHeight : 100}).panelInstance('area5');
});
</script>
    
 
  </head>
  <body class="skin-blue sidebar-mini">
    <div class="wrapper">
      <?php include("../includes/admin-header.php"); ?>
     
      <!-- Left side column. contains the logo and sidebar -->
      <aside class="main-sidebar">
        <!-- sidebar: style can be found in sidebar.less -->
       <?php include("pages/sidebar.php"); ?>
        <!-- /.sidebar -->
      </aside>

      <!-- Content Wrapper. Contains page content -->
      <div class="content-wrapper">
        <!-- Content Header (Page header) -->
	  <?php
			
			if($_GET['id'] != "") {
			$query = "select employee_id,employee_name,employee_email,employee_contact,employee_address,employee_pincode,employee_photo,employee_status from  fn_employee where employee_id ='$_GET[id]'";
			$equery = mysqli_query($db_connection,$query);			
			while($fet_employee = mysqli_fetch_array($equery)) {			
			$employee_id = $fet_employee[0];
			$employee_name = $fet_employee[1];
			$employee_email = $fet_employee[2];
			$employee_contact = $fet_employee[3];
			$employee_address = $fet_employee[4];
			$employee_pincode = $fet_employee[5];
			$employee_photo = "../".$fet_employee[6];		
			$employee_status = $fet_employee[7];		
			}
			
			}
			
			
			?>
	 <section class="content-header">
      <?php if($_GET['id'] != "") { ?>
	  <h1>Edit <?php echo $pagename; ?></h1>
	  <?php } else { ?>
	  <h1>Add <?php echo $pagename; ?></h1>
	  <?php } ?>
      <ol class="breadcrumb">
        <li><a href="#"><i class="fa fa-dashboard"></i> Home</a></li>
        <li class="active">Dashboard</li>
      </ol>
    </section>
       <section class="content">
      <div class="row">
        <!-- left column -->
        <div class="col-md-8">
          <!-- general form elements -->
          <div class="box box-primary">
           <!-- /.box-header -->
            <!-- form start -->
		   
		    <form id="FormHome" name="FormName" action="<?PHP $PHP_SELF ?>" method="post" enctype="multipart/form-data" >
			
             <div class="form-group">
                  <label>Name</label>
                  <input type="text" class="form-control" name="employee_name" placeholder="Enter name" value="<?php echo $employee_name; ?>" >
              </div>
            <div class="form-group">
                  <label>Email</label>
                  <input type="text" class="form-control" name="employee_email" placeholder="Enter email" value="<?php echo $employee_email; ?>" >
              </div>
             <div class="form-group">
                  <label>Contact</label>
                  <input type="text" class="form-control" name="employee_contact" placeholder="Enter contact" value="<?php echo $employee_contact; ?>" >
              </div>
             <div class="form-group">
                  <label>Address</label>
                  <input type="text" class="form-control" name="employee_address" placeholder="Enter address" value="<?php echo $employee_address; ?>" >
              </div>
             <div class="form-group">
                  <label>Pincode</label>
                  <input type="text" class="form-control" name="employee_pincode" placeholder="Enter pincode" value="<?php echo $employee_pincode; ?>" >
              </div>
                        
            <div class="form-group">
                  <label>Photo</label>
				   <?php if($_GET['id'] != "") { ?>
                  <input type="file" id="exampleInputFile" name="employee_photo" value="<?php echo $employee_photo; ?>"  >	
				   <img src="<?php echo $employee_photo; ?>" style="height:150px;width:150px;"	>
				   <?php } else { ?>
				    <input type="file" id="exampleInputFile" name="employee_photo" >	
					<?php } ?>
              </div>
            <div class="form-group">
                  <label>Status</label>
                  <select id="jobs_status" name="employee_status" class="form-control">
                        <option value="" selected="selected">--- Select ---</option>
                        <option value="1" <?php if($employee_status == 1) { echo 'selected=selected'; } ?>>Active</option>
                        <option value="0" <?php if($employee_status == 0) { echo 'selected=selected'; } ?>>InActive</option>
                </select>
              </div>
			   
			  <div class="box-footer">
       			<input type="submit" id="submit" name="submit" value="Submit" class="btn btn-primary" />
              </div>
            </form>
          </div>
          <!-- /.box -->
        </div>
        <!--/.col (left) -->
     
      </div>
      <!-- /.row -->
    </section>
      </div><!-- /.content-wrapper -->

        </section><!-- /.content -->
     
      <footer class="main-footer">
         <?php include("../includes/admin-footer.php"); ?>
      </footer>
      
     
      <!-- Add the sidebar's background. This div must be placed
           immediately after the control sidebar -->
      <div class='control-sidebar-bg'></div>
    </div><!-- ./wrapper -->

    <script src="plugins/jQuery/jQuery-2.1.4.min.js"></script>
    <!-- Bootstrap 3.3.2 JS -->
    <script src="bootstrap/js/bootstrap.min.js" type="text/javascript"></script>
    <!-- FastClick -->
    <script src='plugins/fastclick/fastclick.min.js'></script>
    <!-- AdminLTE App -->
    <script src="dist/js/app.min.js" type="text/javascript"></script>
    <!-- AdminLTE for demo purposes -->
    <script src="dist/js/demo.js" type="text/javascript"></script>
    <!-- CK Editor -->
    <script src="https://cdn.ckeditor.com/4.4.3/standard/ckeditor.js"></script>
    <script type="text/javascript">
      $(function () {
        // Replace the <textarea id="about_desc"> with a CKEditor
        // instance, using default configuration.
        CKEDITOR.replace('employee_inclusion');
        CKEDITOR.replace('employee_exclusion');
        //bootstrap WYSIHTML5 - text editor
        $(".textarea").wysihtml5();
      });	  
	  
    </script>
   
  
  </body>
</html>