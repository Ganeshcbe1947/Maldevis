<?PHP

	include("../includes/config.php");

	include("thumbnail.php");

	//if($_SESSION[$loginid] == "") { header("location: login.php?access=denied");  }
	$pagename = "Enquiry";	
	if(isset($_POST['submit'])) { header("location:enquiry-view.php"); }
	
?>

<!DOCTYPE html>
<html>
  <head>
    <meta charset="UTF-8">
    <title><?PHP echo $projecttitle." :: ".$pagename; ?></title>
    <meta content='width=device-width, initial-scale=1, maximum-scale=1, user-scalable=no' name='viewport'>
   <!-- Bootstrap 3.3.4 -->
    <link href="bootstrap/css/bootstrap.min.css" rel="stylesheet" type="text/css" />
    <!-- Font Awesome Icons -->
    <link href="https://maxcdn.bootstrapcdn.com/font-awesome/4.3.0/css/font-awesome.min.css" rel="stylesheet" type="text/css" />
    <!-- Ionicons -->
    <link href="https://code.ionicframework.com/ionicons/2.0.1/css/ionicons.min.css" rel="stylesheet" type="text/css" />
    <!-- Theme style -->
    <link href="dist/css/AdminLTE.min.css" rel="stylesheet" type="text/css" />
    <!-- AdminLTE Skins. Choose a skin from the css/skins
         folder instead of downloading all of them to reduce the load. -->
    <link href="dist/css/skins/_all-skins.min.css" rel="stylesheet" type="text/css" />
    <!-- bootstrap wysihtml5 - text editor -->
    <link href="plugins/bootstrap-wysihtml5/bootstrap3-wysihtml5.min.css" rel="stylesheet" type="text/css" />
  </head>
  <body class="skin-blue sidebar-mini">
    <div class="wrapper">
      <?php include("../includes/admin-header.php"); ?>
     
      <!-- Left side column. contains the logo and sidebar -->
      <aside class="main-sidebar">
        <!-- sidebar: style can be found in sidebar.less -->
       <?php include("pages/sidebar.php"); ?>
        <!-- /.sidebar -->
      </aside>

      <!-- Content Wrapper. Contains page content -->
      <div class="content-wrapper">
        <!-- Content Header (Page header) -->
          <!-- Main content -->
        <section class="content">

          <!-- Default box -->
          <div class="box">
            <div class="box-header with-border">
              <div class="box-tools pull-right">
                <button class="btn btn-box-tool" data-widget="collapse" data-toggle="tooltip" title="Collapse"><i class="fa fa-minus"></i></button>
                <button class="btn btn-box-tool" data-widget="remove" data-toggle="tooltip" title="Remove"><i class="fa fa-times"></i></button>
              </div>
            </div>
             <div class="box-body">
			<?php
			
			if($_GET['id'] != "") {
						
			$query = "select enquiry_id, enquiry_firstname, enquiry_email, enquiry_subject, enquiry_msg from enquiry_information where enquiry_id ='$_GET[id]'";
			
			$equery = mysqli_query($db_connection,$query);			
			while($fetchrow = mysqli_fetch_array($equery)) {			
			$enquiry_name = $fetchrow[1];
			$enquiry_email = $fetchrow[2];
			$enquiry_subject = $fetchrow[3];
			$enquiry_msg = $fetchrow[4];
			}
			
			}
			
			
			?>
		    <form id="FormHome" name="FormName" action="<?PHP $PHP_SELF ?>" method="post" enctype="multipart/form-data" >
                  <div class="box-body">				  
						<div class="form-group"><label for="exampleInputEmail1">Name : </label><?php echo $enquiry_name; ?></div>
						<div class="form-group"><label for="exampleInputEmail1">Email : </label><?php echo $enquiry_email; ?></div>
						<div class="form-group"><label for="exampleInputEmail1">Subject : </label><?php echo $enquiry_subject; ?></div>
						<div class="form-group"><label for="exampleInputEmail1">Message : </label><?php echo $enquiry_msg; ?></div>
                  </div><!-- /.box-body -->

                  <div class="box-footer">
				  	<input type="submit" id="submit" name="submit" value="Back" class="btn btn-primary" />
                  </div>
                </form>
            </div><!-- /.box-body -->
            
          </div><!-- /.box -->

        </section><!-- /.content -->
      </div><!-- /.content-wrapper -->

        </section><!-- /.content -->
     
      <footer class="main-footer">
         <?php include("../includes/admin-footer.php"); ?>
      </footer>
      
     
      <!-- Add the sidebar's background. This div must be placed
           immediately after the control sidebar -->
      <div class='control-sidebar-bg'></div>
    </div><!-- ./wrapper -->
  <!-- jQuery 2.1.4 -->
    <script src="plugins/jQuery/jQuery-2.1.4.min.js"></script>
    <!-- Bootstrap 3.3.2 JS -->
    <script src="bootstrap/js/bootstrap.min.js" type="text/javascript"></script>
    <!-- FastClick -->
    <script src='plugins/fastclick/fastclick.min.js'></script>
    <!-- AdminLTE App -->
    <script src="dist/js/app.min.js" type="text/javascript"></script>
    <!-- AdminLTE for demo purposes -->
    <script src="dist/js/demo.js" type="text/javascript"></script>
    <!-- CK Editor -->
    <script src="https://cdn.ckeditor.com/4.4.3/standard/ckeditor.js"></script>
    <!-- Bootstrap WYSIHTML5 -->
    
    <script type="text/javascript">
      $(function () {
        // Replace the <textarea id="event_desc"> with a CKEditor
        // instance, using default configuration.
        CKEDITOR.replace('event_desc');
        //bootstrap WYSIHTML5 - text editor
        $(".textarea").wysihtml5();
      });
    </script>
  
  </body>
</html>