<?php 
    include "includes/header.php"; 
    $employee_id = $_SESSION['employee_id'];
    
    $employee_query = "select employee_id,employee_name,employee_email,employee_cv,employee_contact,employee_address,employee_pincode,employee_photo,employee_videocv,employee_status from  fn_employee where employee_id ='$employee_id'";
    $employee_equery = mysqli_query($db_connection,$employee_query);			
    $fet_employee = mysqli_fetch_array($employee_equery);
    $employee_id = $fet_employee[0];
    $employee_name = $fet_employee[1];
    $employee_email = $fet_employee[2];
    $employee_cv = $fet_employee[3];
    $employee_contact = $fet_employee[4];
    $employee_address = $fet_employee[5];
    $employee_pincode = $fet_employee[6];
    $employee_photo = $fet_employee[7];
    $employee_videocv = $fet_employee[8];
    
    if(isset($_POST['Update'])) {
        $employee_name = $_POST['employee_name'];
        $employee_contact = $_POST['employee_contact'];
        $employee_address = $_POST['employee_address'];
        $employee_pincode = $_POST['employee_pincode'];
        $employee_photo = $_POST['employee_photo'];
        
        $employeeimagedirectory = "images/employee";
	if(is_dir($employeeimagedirectory) == false){ mkdir($employeeimagedirectory, 0777, true); }
        
        $update_query = "update fn_employee set employee_name = '$employee_name',employee_contact = '$employee_contact',employee_address = '$employee_address',employee_pincode = '$employee_pincode', updatedatetime = current_timestamp() where employee_id = $employee_id";
	//echo $update_query; exit;
	$update_result = mysqli_query($db_connection,$update_query);	
        if($update_result == TRUE)
        {
            if ($result == true) {
                $filename = $_FILES['employee_photo']['name'];
                if ($filename != "") {
                        if ($_GET['id'] == "") {
                                $query = "select max(employee_id) from fn_employee";
                                $equery = mysqli_query($db_connection,$query);
                                $fetchrow = mysqli_fetch_row($equery);
                                $employee_id = $fetchrow[0];
                        }

                        else { $employee_id = $_GET['id']; }


                        $fileextension = substr($filename, strlen($filename)-4, 4);
                        $employeeimagepath = $employeeimagedirectory."/employee_".$employee_id.$fileextension;
                        if (move_uploaded_file($_FILES['employee_photo']['tmp_name'], $employeeimagepath)){
                                chmod($employeeimagepath,0777);	

                                $employeeimagepath = str_replace("../", "", $employeeimagepath);					

                                echo $query = "update fn_employee set employee_photo = '".$employeeimagepath."' where (employee_id = ".$employee_id.")";			
                                $result = mysqli_query($db_connection,$query) or die(mysqli_error());
                                //$update_message = "Your profile updated successfully";
                        }
                }
                }
            
        }
	//header("location:employee-dashboard.php");
    }
    
    if(isset($_POST['CV']))
    {
        $employee_cv = $_POST['employee_cv'];
        //echo $employee_id;
        $employeecvdirectory = "images/employeecv";
	if(is_dir($employeecvdirectory) == false){ mkdir($employeecvdirectory, 0777, true); }
        
        $filename = $_FILES['employee_cv']['name'];
        if ($filename != "") {                
            $fileextension = substr($filename, strlen($filename)-4, 4);
            $employeecvpath = $employeecvdirectory."/employee_".$employee_id.$fileextension;
            if (move_uploaded_file($_FILES['employee_cv']['tmp_name'], $employeecvpath)){
                    chmod($employeecvpath,0777);
                    $employeecvpath = str_replace("../", "", $employeecvpath);					

                    $cv_query = "update fn_employee set employee_cv = '".$employeecvpath."' where (employee_id = ".$employee_id.")";			
                    $cv_result = mysqli_query($db_connection,$cv_query) or die(mysqli_error());
                    if($cv_result == true)
                    {
                        $cv_msg = "Resume Updated Successfully";
                    } else {
                        $cv_msg = "Try again later";
                    }

            }
        }
        
    }
    
    if(isset($_POST['VideoCV']))
    {
        $employee_cv = $_POST['employee_cv'];
        //echo $employee_id;
        $employeevideocvdirectory = "images/employeevideocv";
	if(is_dir($employeevideocvdirectory) == false){ mkdir($employeevideocvdirectory, 0777, true); }
        
        $filename = $_FILES['employee_videocv']['name'];
        if ($filename != "") {                
            $fileextension = substr($filename, strlen($filename)-4, 4);
            $employeevideocvpath = $employeevideocvdirectory."/employee_".$employee_id.$fileextension;
            if (move_uploaded_file($_FILES['employee_videocv']['tmp_name'], $employeevideocvpath)){
                    chmod($employeevideocvpath,0777);
                    $employeevideocvpath = str_replace("../", "", $employeevideocvpath);					

                    $videocv_query = "update fn_employee set employee_videocv = '".$employeevideocvpath."' where (employee_id = ".$employee_id.")";			
                    $videocv_result = mysqli_query($db_connection,$videocv_query) or die(mysqli_error());
                    if($videocv_result == true)
                    {
                        $videocv_msg = "Video Updated Successfully";
                    } else {
                        $videocv_msg = "Try again later";
                    }

            }
        }
        
    }
    
?>
<section class="page-title title-bg10">
    <div class="d-table">
        <div class="d-table-cell">
            <h2>Dashboard</h2>
            <ul>
                <li>
                    <a href="index.php">Home</a>
                </li>
                <li>Dashboard</li>
            </ul>
        </div>
    </div>   
</section>
<!-- Page Title End -->

<section class="account-section ptb-100">
    <div class="container">
        <div class="row">
            <?php include "includes/employee-sidebar.php"; ?>
            <div class="col-md-8">
                        <div class="account-details">
                            <h3>Basic Information</h3>
                            <h5 style="color:red;text-align: center"><?php echo $update_message; ?></h5>
                            <form class="basic-info" name="FormName" action="<?PHP $PHP_SELF ?>" method="post" enctype="multipart/form-data" >
                        <div class="row">
                            <div class="col-md-6">
                                <div class="form-group">
                                    <label>Name</label>
                                    <input type="text" name="employee_name" class="form-control" placeholder="Your Name" value="<?php echo $employee_name; ?>">
                                </div>
                            </div>

                          <div class="col-md-6">
                                <div class="form-group">
                                    <label>Address</label>
                                    <input type="text" name="employee_address" class="form-control" placeholder="Your Address" value="<?php echo $employee_address; ?>">
                                </div>
                            </div>
                            <div class="col-md-6">
                                <div class="form-group">
                                    <label>Pincode</label>
                                    <input type="text" name="employee_pincode" class="form-control" placeholder="Your Pincode" value="<?php echo $employee_pincode; ?>">
                                </div>
                            </div>
                            <div class="col-md-6">
                                <div class="form-group">
                                    <label>Contact</label>
                                    <input type="text" name="employee_contact" class="form-control" placeholder="Your Phone" value="<?php echo $employee_contact; ?>">
                                </div>
                            </div>
                            <div class="col-md-6">
                                <div class="form-group">
                                    <label>Photo</label>
				    <input type="file" id="exampleInputFile" name="employee_photo" >	
                                </div>
                            </div>
                           
                            <div class="col-md-12">
                                <button type="submit" name="Update" class="account-btn">Update</button>
                            </div>
                        </div>
                    </form>  

                            <h3>Resume</h3>
                            <h5 style="color:red;text-align: center"><?php echo $cv_msg; ?></h5>
                            
                            <form class="basic-info" name="FormName" action="<?PHP $PHP_SELF ?>" method="post" enctype="multipart/form-data" >
                                <div class="form-group">
                                <?php if($employee_cv != "") { ?>
                                <input type="file" id="exampleInputFile" name="employee_cv" value="<?php echo $employee_cv; ?>"  >	
                                <a href="<?php echo $employee_cv; ?>" target="_blank" class="account-btn">Download Resume</a>
                 		   <?php } else { ?>
				    <input type="file" id="exampleInputFile" name="employee_cv" >	
					<?php } ?>
                                </div>
                                <div class="col-md-12">
                                <button type="submit" name="CV" class="account-btn">Update Resume</button>
                                
                            </div>
                            </form>
                            <h3>Video Resume</h3>
                            <h5 style="color:red;text-align: center"><?php echo $videocv_msg; ?></h5>
                            
                            <form class="basic-info" name="FormName" action="<?PHP $PHP_SELF ?>" method="post" enctype="multipart/form-data" >
                                <div class="form-group">
                                <?php if($employee_videocv != "") { ?>
                                <input type="file" id="exampleInputFile" name="employee_videocv" value="<?php echo $employee_videocv; ?>"  >	
                                <a href="<?php echo $employee_videocv; ?>" target="_blank" class="account-btn">Download Video</a>
                 		   <?php } else { ?>
				    <input type="file" id="exampleInputFile" name="employee_videocv" >	
					<?php } ?>
                                </div>
                                <div class="col-md-12">
                                <button type="submit" name="VideoCV" class="account-btn">Update Video</button>
                                
                            </div>
                            </form>
                            
                        </div>
                    </div>
            
        </div>
    </div>
</section>


<?php include "includes/footer.php"; ?>