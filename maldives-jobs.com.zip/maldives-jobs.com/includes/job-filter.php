<?php

    $category_id = $_POST['category_id'];
    $jobs_employee = $_POST['jobs_employee'];
    $jobs_location = $_POST['jobs_location'];
    $jobs_salary = $_POST['jobs_salary'];
    $jobs_type_id = $_POST['jobs_type_id'];
    $jobs_status = $_POST['jobs_status'];

    if(isset($_POST['search']))
    {
     if($category_id != "")
     {
         echo "<script>window.location = 'jobs.php?cat=$category_id'</script>";
     } elseif($jobs_employee != "") {
         echo "<script>window.location = 'jobs.php?emp=$jobs_employee'</script>";
     } elseif($jobs_location != "") {
         echo "<script>window.location = 'jobs.php?location=$jobs_location'</script>";
     } elseif($jobs_salary != "") {         
         echo "<script>window.location = 'jobs.php?sal=$jobs_salary'</script>";
     } elseif($jobs_type_id != "") {
         echo "<script>window.location = 'jobs.php?type=$jobs_type_id'</script>";         
     } 
    } 

?>

<style>
#country-list {
    float: left;
    list-style: none;
    margin-top: -3px;
    padding: 0;
    width: 190px;
    position: absolute;
}

#country-list li {
    padding: 10px;
    background: #f0f0f0;
    border-bottom: #bbb9b9 1px solid;
}

#country-list li:hover {
    background: #ece3d2;
    cursor: pointer;
}


</style>
<script src="https://code.jquery.com/jquery-2.1.1.min.js"
    type="text/javascript"></script>
<script>
$(document).ready(function() {
    $("#search-box").keyup(function() {
        $.ajax({
            type: "POST",
            url: "fetchData.php",
            data: 'keyword=' + $(this).val(),
            beforeSend: function() {
                $("#search-box").css("background", "#FFF url(LoaderIcon.gif) no-repeat 165px");
            },
            success: function(data) {
                $("#suggesstion-box").show();
                $("#suggesstion-box").html(data);
                $("#search-box").css("background", "#FFF");
            }
        });
    });
});
function selectCountry(val) {
    $("#search-box").val(val);
    $("#suggesstion-box").hide();
}
</script>
<form class="job-post-from" id="FormHome" name="FormName" action="<?PHP $PHP_SELF ?>" method="post" enctype="multipart/form-data" >
           
                
                <div class="col-md-12">
                    <div class="form-group">
                        <label>Industry</label>
                        <select id="category_id" name="category_id" class="category">
					<option value="" selected="selected">--- Select ---</option>
					<?php
					$query = "select category_id,category_name from fn_category where category_status = '1' order by category_id asc";
					$equery = mysqli_query($db_connection,$query);
                                         while($fetcharray = mysqli_fetch_array($equery)) {
					if($category_id == $fetcharray[0]) {
					echo "<option value='".$fetcharray[0]."' selected='selected'>".$fetcharray[1]."</option>";
					}
					else {
					echo "<option value='".$fetcharray[0]."'>".$fetcharray[1]."</option>";
					}
					}
					?>
				</select>
                    </div>
                </div>

                <div class="col-md-12">
                    <div class="form-group">
                        <label>Company</label>
                        <div class="frmSearch">
                        <input type="text" name="jobs_employee" class="form-control" id="search-box"  placeholder="e.g. Name" value="" >
                        <div id="suggesstion-box"></div>
    </div>
                    </div>
                </div>
                <div class="col-md-12">
                    <div class="form-group">
                        <label>Employment Location</label>
                        <input type="text" name="jobs_location" class="form-control" id="exampleInput5" placeholder="e.g. Location" value="" >
                    </div>
                </div>
              
                <div class="col-md-12">
                    <div class="form-group">
                        <label>Expected Salary </label>
                        <input type="text" name="jobs_salary" value="" class="form-control" id="exampleInput7" placeholder="e.g. 20000">
                    </div>
                </div>
                <div class="col-md-12">
                    <div class="form-group">
                        <label>Employement Type</label>
                        <select id="category_id" name="jobs_type_id" class="category">
					<option value="" selected="selected">--- Select ---</option>
					<?php
					$query = "select jobs_type_id,jobs_type_name from fn_jobs_type where jobs_type_status = '1' order by jobs_type_id asc";
					$equery = mysqli_query($db_connection,$query);
                                         while($fetcharray = mysqli_fetch_array($equery)) {
					if($jobs_type_id == $fetcharray[0]) {
					echo "<option value='".$fetcharray[0]."' selected='selected'>".$fetcharray[1]."</option>";
					}
					else {
					echo "<option value='".$fetcharray[0]."'>".$fetcharray[1]."</option>";
					}
					}
					?>
				</select>
                    </div>
                </div>
                <!-- <div class="col-md-12">
                    <div class="form-group">
                        <label>Job Status</label>
                        <select id="jobs_id" name="jobs_status" class="category">
					<option value="" selected="selected">--- Select ---</option>
					<option value="1">Active</option>
					<option value="0">Expired</option>
				</select>
                    </div>
                </div> -->

                
                <div class="col-md-12 text-center">
                    <button type="submit" name="search" value="Submit" class="post-btn">
                        Search
                    </button>
                </div>
         
        </form>
    