<?php
	//Project title
	$projecttitle = "Maldives Jobs";
	$link = "http://localhost/project/maldives-careers.com/";
	
	$db_hostname = "localhost";
	$db_database = "maldives-careers";
	$db_username = "root";
	$db_password = "";
	
		
	//$db_connection = mysql_connect($db_hostname, $db_username, $db_password) or die( header("location: ".$configpath.$configfilename) );
	$db_connection = mysqli_connect($db_hostname, $db_username, $db_password) or die( mysql_error() );
	//mysql_select_db($db_database, $db_connection) or die( header("location: ".$configpath.$configfilename) );
	mysqli_select_db($db_connection,$db_database) or die( mysqli_error() );
	
	session_start();
	error_reporting(0);
	
	$sql = "select company_id,company_name,company_firstname,company_lastname,company_addr,company_addr1,company_pincode,company_contact,company_mobile,company_email,company_facebook,company_twitter,company_youtube from company_information where company_status = '1'";
	$query = mysqli_query($db_connection,$sql);
	$row = mysqli_fetch_array($query);
	$company_name = $row ['company_name'];
	$company_firstname = $row ['company_firstname'];
	$company_lastname = $row ['company_lastname'];
	$company_addr = $row ['company_addr'];
	$company_addr1 = $row ['company_addr1'];
	$company_pincode = $row ['company_pincode'];
	$company_contact = $row ['company_contact'];
	$company_mobile = $row ['company_mobile'];
	$company_email = $row ['company_email'];
	$company_facebook = $row ['company_facebook'];
	$company_twitter = $row ['company_twitter'];
	$company_youtube = $row ['company_youtube'];


?>