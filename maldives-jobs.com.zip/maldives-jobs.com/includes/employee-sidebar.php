<?php 
    $employee_id = $_SESSION['employee_id'];
    $employee_email = $_SESSION['employee_email'];
    if($employee_id == "") { header("location: index.php");  }
    
    $employee_query = "select employee_id,employee_name,employee_email,employee_contact,employee_address,employee_pincode,employee_photo,employee_status from  fn_employee where employee_id ='$employee_id'";
    $employee_equery = mysqli_query($db_connection,$employee_query);			
    $fet_employee = mysqli_fetch_array($employee_equery);
    $employee_id = $fet_employee[0];
    $employee_name = $fet_employee[1];
    $employee_email = $fet_employee[2];
    $employee_contact = $fet_employee[3];
    $employee_address = $fet_employee[4];
    $employee_pincode = $fet_employee[5];
    $employee_photo = $fet_employee[6];
?>
<div class="col-md-4">
<div class="account-information">
    <div class="profile-thumb">
        <img src="<?php echo $employee_photo; ?>" alt="<?php echo $employee_name; ?>">
        <h3><?php echo $employee_name; ?></h3>
    </div>

    <ul>
        <li>
            <a href="employee-dashboard.php">
                <i class='bx bx-user'></i>
                My Profile
            </a>
        </li>
        <li>
            <a href="about-me.php">
                <i class='bx bxs-file-doc'></i>
                About Me
            </a>
        </li>
        <li>
            <a href="employee-education-view.php">
                <i class='bx bxs-file-doc'></i>
                Education
            </a>
        </li>
        <li>
            <a href="employee-experience-view.php">
                <i class='bx bxs-file-doc'></i>
                Experience
            </a>
        </li>
        <li>
            <a href="employee-skills-view.php">
                <i class='bx bxs-file-doc'></i>
                Skills
            </a>
        </li>
        <li>
            <a href="social-links.php">
                <i class='bx bx-briefcase'></i>
                Social links
            </a>
        </li>                        
        <li>
            <a href="applied-jobs.php">
                <i class='bx bx-briefcase'></i>
                Applied Job
            </a>
        </li>                        
        <li>
            <a href="#">
                <i class='bx bx-lock-alt' ></i>
                Change Password
            </a>
        </li>                       
        <li>
            <a href="employee-sign-in.php?logout=true">
                <i class='bx bx-lock-alt' ></i>
                Logout
            </a>
        </li>                       
    </ul>
</div>
</div>