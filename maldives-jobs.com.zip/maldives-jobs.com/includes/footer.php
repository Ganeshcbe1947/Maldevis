<div class="copyright-text text-center">
        <p>Copyright @2023 <?php echo $projecttitle; ?>. Developed By <a href="https://www.techbuddy.in/" target="_blank">Techbuddy</a></p>
</div>
<!-- Footer Section End -->

<!-- Back To Top Start -->
<div class="top-btn">
        <i class='bx bx-chevrons-up bx-fade-up'></i>
</div>
<!-- Back To Top End -->

<!-- jQuery first, then Bootstrap JS -->
<script src="js/jquery.min.js"></script>
<script src="js/bootstrap.bundle.min.js"></script>
<!-- Owl Carousel JS -->
<script src="js/owl.carousel.min.js"></script>
<!-- Nice Select JS -->
<script src="js/jquery.nice-select.min.js"></script>
<!-- Magnific Popup JS -->
<script src="js/jquery.magnific-popup.min.js"></script>
<!-- Subscriber Form JS -->
<script src="js/jquery.ajaxchimp.min.js"></script>
<!-- Form Velidation JS -->
<script src="js/form-validator.min.js"></script>
<!-- Contact Form -->
<script src="js/contact-form-script.js"></script>
<!-- Meanmenu JS -->
<script src="js/meanmenu.js"></script>
<!-- Custom JS -->
<script src="js/custom.js"></script>
</body>
</html>