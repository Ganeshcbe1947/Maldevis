<?php 
    $employeers_id = $_SESSION['employeers_id'];
    $employeers_email = $_SESSION['employeers_email'];
    if($employeers_id == "") { header("location: index.php");  }
    
    $employeers_query = "select employeers_id,employeers_name,employeers_company,employeers_email,employeers_contact,employeers_address,employeers_pincode,employeers_photo,employeers_status from  fn_employeers where employeers_id ='$employeers_id'";
    $employeers_equery = mysqli_query($db_connection,$employeers_query);			
    $fet_employeers = mysqli_fetch_array($employeers_equery);
    $employeers_id = $fet_employeers[0];
    $employeers_name = $fet_employeers[1];
    $employeers_company = $fet_employeers[2];
    $employeers_email = $fet_employeers[3];
    $employeers_contact = $fet_employeers[4];
    $employeers_address = $fet_employeers[5];
    $employeers_pincode = $fet_employeers[6];
    $employeers_photo = $fet_employeers[7];
?>
<div class="col-md-4">
<div class="account-information">
    <div class="profile-thumb">
        <img src="<?php echo $employeers_photo; ?>" alt="<?php echo $employeers_name; ?>">
        <h3><?php echo $employeers_name; ?></h3>
        <p><?php echo $employeers_company; ?></p>
    </div>

    <ul>
        <li>
            <a href="employeer-dashboard.php">
                <i class='bx bx-user'></i>
                My Profile
            </a>
        </li>
        <?php 
            $query = "SELECT count(jobs_id),jobs_employeers FROM fn_jobs WHERE jobs_employeers = $employeers_id";
            $result = mysqli_query($db_connection,$query);
            $fet_query = mysqli_fetch_array($result);
            $emp_query = "SELECT createdatetime FROM fn_employeers where employeers_id = 4";
            $emp_result = mysqli_query($db_connection,$emp_query);
            $fet_emp = mysqli_fetch_array($emp_result);
            $date_query = "SELECT DATEDIFF('$fet_emp[0]','2023-02-13 17:15:28')";
            $date_result = mysqli_query($db_connection,$date_query);
            $fet_date = mysqli_fetch_array($date_result);
            $date = $fet_date[0];
            
            if(($fet_query[0] <=15) and ($date <=90)) 
            {
        ?>
        <li>
            <a href="post-job.php">
                <i class='bx bxs-file-doc'></i>
                Post Job (<?php echo $fet_query[0]; ?>)
            </a>
        </li>
            <?php } ?>
        <li>
            <a href="job-list.php">
                <i class='bx bx-briefcase'></i>
                Job List
            </a>
        </li>                        
        <li>
            <a href="upgrade.php">
                <i class='bx bx-stopwatch'></i>
                Subscription Upgrade
            </a>
        </li>                        
        <li>
            <a href="#">
                <i class='bx bx-lock-alt' ></i>
                Change Password
            </a>
        </li>                       
        <li>
            <a href="employeer-sign-in.php?logout=true">
                <i class='bx bx-lock-alt' ></i>
                Logout
            </a>
        </li>                       
    </ul>
</div>
</div>