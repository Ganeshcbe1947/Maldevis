<?php include "includes/config.php"; ?>
<!doctype html>
<html lang="en">
    <head>
        <!-- Required meta tags -->
        <meta charset="utf-8">
        <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
        <!-- Bootstrap CSS -->
        <link rel="stylesheet" href="css/bootstrap.min.css">
        <!-- Owl Carousel CSS -->
        <link rel="stylesheet" href="css/owl.carousel.min.css">
        <!-- Owl Carousel Theme Default CSS -->
        <link rel="stylesheet" href="css/owl.theme.default.min.css">
        <!-- Box Icon CSS-->
        <link rel="stylesheet" href="css/boxicon.min.css">
        <!-- Flaticon CSS-->
        <link rel="stylesheet" href="fonts/flaticon/flaticon.css">
        <!-- Meanmenu CSS -->
        <link rel="stylesheet" href="css/meanmenu.css">
        <!-- Nice Select CSS -->
        <link rel="stylesheet" href="css/nice-select.css">
        <!-- Style CSS -->
        <link rel="stylesheet" href="css/style.css">
		<!-- Responsive CSS -->
        <link rel="stylesheet" href="css/responsive.css">
        <!-- Title CSS -->
        <title><?php echo $projecttitle; ?></title>
        </head>
	
  	<body>
		
		<!-- Pre-loader Start -->
		<div class="loader-content">
            <div class="d-table">
                <div class="d-table-cell">
					<div class="sk-circle">
						<div class="sk-circle1 sk-child"></div>
						<div class="sk-circle2 sk-child"></div>
						<div class="sk-circle3 sk-child"></div>
						<div class="sk-circle4 sk-child"></div>
						<div class="sk-circle5 sk-child"></div>
						<div class="sk-circle6 sk-child"></div>
						<div class="sk-circle7 sk-child"></div>
						<div class="sk-circle8 sk-child"></div>
						<div class="sk-circle9 sk-child"></div>
						<div class="sk-circle10 sk-child"></div>
						<div class="sk-circle11 sk-child"></div>
						<div class="sk-circle12 sk-child"></div>
					</div>
				</div>
			</div>
		</div>
		<!-- Pre-loader End -->

		<!-- Navbar Area Start -->
		<div class="navbar-area">
			<!-- Menu For Mobile Device -->
			<div class="mobile-nav">
				<a href="index.php" class="logo">
                                    <img src="images/logo.png" alt="<?php echo $projecttitle; ?>" style="height:40px">
				</a>
			</div>
		
			<!-- Menu For Desktop Device -->
			<div class="main-nav">
				<div class="container">
					<nav class="navbar navbar-expand-lg navbar-light">
						<a class="navbar-brand" href="index.php">
							<img src="images/logo.png" alt="<?php echo $projecttitle; ?>" style="height:75px">
						</a>
						<div class="collapse navbar-collapse mean-menu" id="navbarSupportedContent">
							<ul class="navbar-nav m-auto">
								<li class="nav-item"><a href="index.php" class="nav-link">Home</a></li>
								<li class="nav-item"><a href="jobs.php" class="nav-link">Jobs</a></li>
                                                                <?php if($_SESSION['employeers_id'] == "" and $_SESSION['employee_id'] == "") { ?>
								<li class="nav-item"><a href="employee-sign-in.php" class="nav-link">Job Seekers</a></li>
                                                                <?php } elseif($_SESSION['employee_id'] != "") { ?>
                                                                <li class="nav-item"><a href="employee-dashboard.php" class="nav-link">Dashboard</a></li>
                                                                <?php } ?>
								<li class="nav-item"><a href="courses.php" class="nav-link">Education and Training</a></li>
							</ul>
                                                        <?php if($_SESSION['employeers_id'] != "") { ?>
							<div class="other-option">
								<a href="employeer-dashboard.php" class="signin-btn">Dashboard</a>
								<a href="employeer-sign-in.php?logout=true" class="signin-btn">Logout</a>
							</div>
                                                        <?php } elseif($_SESSION['employee_id'] == "") { ?>
							<div class="other-option">
								<a href="employeer-sign-in.php" class="signin-btn">Employers Login</a>
							</div>
                                                        <?php } elseif($_SESSION['employee_id'] != "") { ?> 
                                                        <div class="other-option">
								<a href="employee-dashboard.php" class="signin-btn">Dashboard</a>
								<a href="employee-sign-in.php?logout=true" class="signin-btn">Logout</a>
							</div>
                                                    
                                                        <?php } ?>
						</div>
					</nav>
				</div>
			</div>
		</div>
		<!-- Navbar Area End -->
