<?php
    include "includes/header.php"; 
    
    $id = $_GET['courses'];
    $query = "select education_id,education_name,education_level,education_duration,education_location,education_desc,education_fee,education_seats,education_requirements,education_type,education_start,education_expiry,education_photo,createdatetime,education_status from  fn_education where education_id = $id";
    $equery = mysqli_query($db_connection,$query);			
    $fet_education = mysqli_fetch_array($equery);
    $education_id = $fet_education[0];
    $education_name = $fet_education[1];
    $education_level = $fet_education[2];
    $education_duration = $fet_education[3];
    $education_location = $fet_education[4];
    $education_desc = $fet_education[5];
    $education_fee = $fet_education[6];
    $education_seats = $fet_education[7];
    $education_requirements = $fet_education[8];
    $education_type = $fet_education[9];
    $education_start = $fet_education[10];
    $education_expiry = $fet_education[11];
    $education_photo = $fet_education[12];
    $published_date = date("d-m-Y", strtotime($fet_education[13]));
?>
<section class="page-title title-bg6">
    <div class="d-table">
        <div class="d-table-cell">
            <h2><?php echo $education_name; ?></h2>
            <ul>
                <li>
                    <a href="index.php">Home</a>
                </li>
                <li><?php echo $education_name; ?></li>
            </ul>
        </div>
    </div>  
</section>
<!-- Page Title End -->

<!-- Job Details Section Start -->
<section class="job-details ptb-100">
    <div class="container">
        <div class="row">
            <div class="col-lg-8">
                <div class="row">
                    <div class="col-lg-12">
                        <div class="job-details-text">
                            <div class="job-card">
                                <div class="row align-items-center">
                                    <div class="col-md-10">
                                        <div class="job-info">
                                            <h3><?php echo $education_name; ?></h3><hr style="color:#EF3159">
                                            <ul>
                                                <li>
                                                    <h5>Level</h5>
                                                    <?php echo $education_level; ?>
                                                </li>
                                                <li>
                                                    <h5>Duration</h5>
                                                    <?php echo $education_duration; ?>
                                                </li>                                                
                                                <li>
                                                    <h5>Location</h5>
                                                    <?php echo $education_location; ?>
                                                </li>                                                
                                            </ul>
                                        </div>
                                    </div>
                                </div>
                            </div>

                            <div class="details-text">
                                <h3>Details</h3>
                                <?php echo $education_desc; ?>
                            </div>
                            <div class="details-text">
                                <h3>Course Fee</h3>
                                <?php echo $education_fee; ?>
                            </div>
                            <div class="details-text">
                                <h3>Course Location</h3>
                                <?php echo $education_location; ?>
                            </div>
                            <div class="details-text">
                                <h2>Requirements</h2><hr style="color:#EF3159">
                                <?php echo $education_requirements; ?>
                            </div>
                            <div class="details-text">
                                <h2> Other Information </h2><hr style="color:#EF3159">
                                <b>Mode of Study : </b><?php echo $education_type; ?>
                            </div>
                           
                        </div>
                    </div>
                </div>
            </div>

            <div class="col-lg-4">
                <div class="job-sidebar">
                    <h3>Published Date</h3>
                    <div class="posted-by">
                        <?php echo $published_date; ?>
                    </div>
                </div>
                
                <div class="job-sidebar">
                    <h3>Course Starts</h3>
                    <div class="posted-by">
                        <?php echo $education_start; ?>
                    </div>
                </div>
                
                <div class="job-sidebar">
                    <h3>Expiry Date</h3>
                    <div class="posted-by">
                        <?php echo $education_expiry; ?>
                    </div>
                </div>
                
                
        </div>
    </div>
</section>

<!-- Subscribe Section Start -->
<section class="subscribe-section">
    <div class="container">
        <div class="row align-items-center">
            <div class="col-md-6">
                <div class="section-title">
                    <h2>Get New Job Notifications</h2>
                    <p>Subscribe & get all related jobs notification</p>
                </div>
            </div>

            <div class="col-md-6">
                <form class="newsletter-form" data-toggle="validator">
                    <input type="email" class="form-control" placeholder="Enter your email" name="EMAIL" required autocomplete="off">

                    <button class="default-btn sub-btn" type="submit">
                        Subscribe
                    </button>

                    <div id="validator-newsletter" class="form-result"></div>
                </form>
            </div>
        </div>
    </div>
</section>
<!-- Subscribe Section End -->
<?php include "includes/footer.php"; ?>