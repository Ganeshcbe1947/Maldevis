<?php 
    include "includes/header.php"; 
    $employee_id = $_SESSION['employee_id'];
    
    
    if(isset($_POST['Skills'])) {
        $skills_title = $_POST['skills_title'];
        $skills_experience = $_POST['skills_experience'];
        
        
        $query = "insert into employee_skills (employee_id,skills_title,skills_experience,skills_status,createdatetime) "
                    . "values('$employee_id','$skills_title','$skills_experience','1', current_timestamp())";	
        $result = mysqli_query($db_connection,$query);	
      
        if($result == TRUE)
        {
            $update_message = "Your profile updated successfully";
            header("location:employee-skills-view.php");
        } else {
            $update_message = "Try later";
        }
	
    }
    
    
?>
 
<section class="page-title title-bg10">
    <div class="d-table">
        <div class="d-table-cell">
            <h2>Add Skills</h2>
            <ul>
                <li>
                    <a href="index.php">Home</a>
                </li>
                <li>Add Skills</li>
            </ul>
        </div>
    </div>   
</section>
<!-- Page Title End -->
<section class="account-section ptb-100">
    <div class="container">
        <div class="row">
            <?php include "includes/employee-sidebar.php"; ?>
            <div class="col-md-8">
                        <div class="account-details">
                            <h3>Add Skills</h3>
                            <h5 style="color:red;text-align: center"><?php echo $update_message; ?></h5>
                            <form class="basic-info" name="FormName" action="<?PHP $PHP_SELF ?>" method="post" enctype="multipart/form-data" >
                        <div class="row">
                            <div class="col-md-8">
                                <div class="form-group">
                                    <label>Skills</label>
                                    <input type="text" name="skills_title" class="form-control" placeholder="Your Skills" value="<?php echo $skills_title; ?>">
                                </div>
                            </div>
                            <div class="col-md-8">
                                <div class="form-group">
                                    <label>Experience</label>
                                    <input type="text" name="skills_experience" class="form-control" placeholder="Your experience" value="<?php echo $skills_experience; ?>">
                                </div>
                            </div>
                           
                            <div class="col-md-12">
                                <button type="submit" name="Skills" class="account-btn">Add Skills</button>
                            </div>
                        </div>
                    </form>  

                        </div>
                    </div>
            
        </div>
    </div>
</section>

<?php include "includes/footer.php"; ?>